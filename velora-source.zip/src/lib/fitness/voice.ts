let lastSpoken = "";
let lastAt = 0;

export function speakCue(text: string, enabled: boolean) {
  if (!enabled) return;
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
  const now = Date.now();
  if (text === lastSpoken && now - lastAt < 6000) return;
  lastSpoken = text;
  lastAt = now;
  try {
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.rate = 1.02;
    u.pitch = 0.95;
    u.volume = 0.9;
    const voices = window.speechSynthesis.getVoices();
    const pick =
      voices.find((v) => /en-GB|en-US/i.test(v.lang) && /female|samantha|google/i.test(v.name)) ??
      voices.find((v) => /en/i.test(v.lang));
    if (pick) u.voice = pick;
    window.speechSynthesis.speak(u);
  } catch {
    /* voice is optional */
  }
}

export function hushVoice() {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
  try {
    window.speechSynthesis.cancel();
  } catch {
    /* ignore */
  }
}
