export type FitnessLevel = "beginner" | "intermediate" | "advanced";
export type Sex = "male" | "female" | "other";
export type ThemeMode = "dark" | "light";
export type ResistanceMode = "manual" | "electronic" | "unknown";
export type WorkoutKind =
  | "free"
  | "endurance"
  | "tempo"
  | "threshold"
  | "hiit"
  | "recovery"
  | "ftp"
  | "custom";
export type IntervalKind =
  | "warmup"
  | "endurance"
  | "tempo"
  | "threshold"
  | "interval"
  | "recovery"
  | "cooldown"
  | "free";
export type SessionStatus = "idle" | "active" | "paused" | "complete";
export type ConnectionState =
  | "disconnected"
  | "scanning"
  | "connecting"
  | "connected";
export type TrainingLabel =
  | "productive"
  | "maintaining"
  | "fresh"
  | "peaking"
  | "overreaching"
  | "untrained";

export interface UserProfile {
  name: string;
  sex: Sex;
  dob: string;
  heightCm: number;
  weightKg: number;
  fitnessLevel: FitnessLevel;
  restingHr: number;
  maxHr: number;
  ftp: number;
  ftpEstimated: boolean;
  units: "metric";
}

export interface Goals {
  targetWeightKg: number;
  weeklyWorkouts: number;
  dailySteps: number;
  focus: "ftp" | "endurance" | "weight" | "consistency";
}

export interface BodyMeasurement {
  id: string;
  date: string;
  weightKg: number;
}

export interface PowerRange {
  min: number;
  max: number;
}

export interface CadenceRange {
  min: number;
  max: number;
}

export interface WorkoutInterval {
  durationSec: number;
  type: IntervalKind;
  /** Absolute watts after FTP scaling. Absent until FTP is known. */
  targetPower?: PowerRange;
  /** Coggan %FTP (0.55 = 55%). Source of truth for library plans. */
  targetFtpPct?: PowerRange;
  targetCadence?: CadenceRange;
  label?: string;
}

export interface WorkoutPlan {
  id: string;
  name: string;
  description: string;
  kind: WorkoutKind;
  durationSec: number;
  intervals: WorkoutInterval[];
  source: "library" | "ai" | "custom";
}

export interface TelemetrySample {
  t: number;
  power: number;
  cadence: number;
  speed: number;
  distance: number;
  heartRate: number;
  calories: number;
  resistance: number;
  battery: number;
}

export interface WorkoutSummary {
  avgPower: number;
  maxPower: number;
  np: number;
  if_: number;
  tss: number;
  avgCadence: number;
  maxCadence: number;
  avgSpeed: number;
  maxSpeed: number;
  avgHeartRate: number;
  maxHeartRate: number;
  calories: number;
  distanceKm: number;
  durationSec: number;
  trainingLoad: number;
  zoneHr: [number, number, number, number, number];
  zonePower: [number, number, number, number, number, number, number];
  hrCaptured: boolean;
}

export interface WorkoutEvent {
  t: number;
  kind: "cue" | "interval" | "pr" | "pause" | "resume" | "complete";
  text: string;
}

export interface Workout {
  id: string;
  planId: string;
  name: string;
  kind: WorkoutKind;
  startTime: string;
  endTime: string;
  summary: WorkoutSummary;
  series: TelemetrySample[];
  events: WorkoutEvent[];
  notes?: string;
}

export interface DailyActivity {
  date: string;
  steps: number;
  walkMeters: number;
  cycleMin: number;
  cycleKm: number;
  cycleKcal: number;
  otherKcal: number;
}

export interface PersonalRecord {
  id: string;
  metric: string;
  label: string;
  value: number;
  unit: string;
  workoutId: string;
  date: string;
  previous?: number;
}

export interface Achievement {
  id: string;
  title: string;
  detail: string;
  earnedAt: string;
}

export interface DeviceInfo {
  name: string;
  manufacturer: string;
  model: string;
  hardware: string;
  software: string;
  batteryPercent: number;
  resistanceMode: ResistanceMode;
}

export interface LiveSession {
  workoutId: string;
  plan: WorkoutPlan;
  status: SessionStatus;
  startedAt: number;
  elapsedSec: number;
  pausedAt: number | null;
  accumulatedPauseMs: number;
  intervalIndex: number;
  /** Rider-logged knob position. RPM600 does not report resistance on 0x2AD2 flags 0x0954. */
  resistance: number;
  telemetry: TelemetrySample;
  series: TelemetrySample[];
  events: WorkoutEvent[];
  lastCueAt: number;
  lastCue: string;
  battery: number;
  source: "ble" | "waiting";
  hrSource: "none" | "ble" | "strap";
  bleOrigin?: { distance?: number; calories?: number };
}

export interface ChatMessage {
  id: string;
  role: "user" | "coach";
  content: string;
  createdAt: string;
}

export interface AIInsight {
  id: string;
  workoutId?: string;
  title: string;
  body: string;
  createdAt: string;
}

export interface CoachingCue {
  text: string;
  speak: boolean;
  urgency: "info" | "action" | "success";
}
