import type {
  PersonalRecord,
  TelemetrySample,
  TrainingLabel,
  UserProfile,
  Workout,
  WorkoutSummary,
} from "./types";
import { hasHr } from "./hr";
import { hrZones, powerZones, zoneForHr, zoneForPower } from "./zones";

function mean(xs: number[]) {
  if (!xs.length) return 0;
  return xs.reduce((a, b) => a + b, 0) / xs.length;
}

function maxOf(xs: number[]) {
  let m = 0;
  for (const x of xs) if (x > m) m = x;
  return m;
}

function rollingMeanMax(values: number[], dt: number, windowSec: number) {
  if (!values.length) return 0;
  const n = Math.max(1, Math.round(windowSec / Math.max(dt, 1)));
  if (values.length < n) {
    return mean(values);
  }
  let sum = 0;
  for (let i = 0; i < n; i++) sum += values[i];
  let best = sum / n;
  for (let i = n; i < values.length; i++) {
    sum += values[i] - values[i - n];
    const avg = sum / n;
    if (avg > best) best = avg;
  }
  return best;
}

function normalizedPower(powers: number[], dt: number) {
  if (powers.length < 2) return mean(powers);
  const window = Math.max(1, Math.round(30 / Math.max(dt, 1)));
  const rolling: number[] = [];
  let sum = 0;
  for (let i = 0; i < powers.length; i++) {
    sum += powers[i];
    if (i >= window) sum -= powers[i - window];
    if (i >= window - 1) {
      const avg = sum / window;
      rolling.push(avg * avg * avg * avg);
    }
  }
  if (!rolling.length) return mean(powers);
  return Math.pow(mean(rolling), 0.25);
}

export function summarizeSeries(
  series: TelemetrySample[],
  durationSec: number,
  profile: UserProfile,
): WorkoutSummary {
  const hz = hrZones(profile);
  const pz = powerZones(profile.ftp);
  const powers = series.map((s) => s.power);
  const hrs = series.filter(hasHr).map((s) => s.heartRate);
  const cads = series.map((s) => s.cadence);
  const spds = series.map((s) => s.speed);
  const dt =
    series.length > 1
      ? Math.max(1, (series[series.length - 1].t - series[0].t) / (series.length - 1))
      : 5;
  const last = series[series.length - 1];
  const np = normalizedPower(powers, dt);
  const if_ = profile.ftp > 0 ? np / profile.ftp : 0;
  const hours = durationSec / 3600;
  const tss = hours * if_ * if_ * 100;
  const zoneHr: WorkoutSummary["zoneHr"] = [0, 0, 0, 0, 0];
  const zonePower: WorkoutSummary["zonePower"] = [0, 0, 0, 0, 0, 0, 0];
  for (const s of series) {
    const hid = zoneForHr(s.heartRate, hz);
    if (hid >= 1) zoneHr[hid - 1] += dt;
    const pid = zoneForPower(s.power, pz);
    if (pid >= 1) zonePower[pid - 1] += dt;
  }
  return {
    avgPower: Math.round(mean(powers)),
    maxPower: Math.round(maxOf(powers)),
    np: Math.round(np),
    if_: Math.round(if_ * 100) / 100,
    tss: Math.round(tss),
    avgCadence: Math.round(mean(cads)),
    maxCadence: Math.round(maxOf(cads)),
    avgSpeed: Math.round(mean(spds) * 10) / 10,
    maxSpeed: Math.round(maxOf(spds) * 10) / 10,
    avgHeartRate: hrs.length ? Math.round(mean(hrs)) : 0,
    maxHeartRate: hrs.length ? Math.round(maxOf(hrs)) : 0,
    calories: Math.round(last?.calories ?? 0),
    distanceKm: Math.round((last?.distance ?? 0) / 100) / 10,
    durationSec: Math.round(durationSec),
    trainingLoad: Math.round(tss),
    zoneHr,
    zonePower,
    hrCaptured: hrs.length >= 5,
  };
}

export function powerCurve(series: TelemetrySample[]) {
  if (!series.length) return [];
  const powers = series.map((s) => s.power);
  const dt =
    series.length > 1
      ? Math.max(1, (series[series.length - 1].t - series[0].t) / (series.length - 1))
      : 5;
  const duration = series.length > 1 ? series[series.length - 1].t - series[0].t : 0;
  const windows = [
    { key: "1s", sec: 1 },
    { key: "5s", sec: 5 },
    { key: "10s", sec: 10 },
    { key: "30s", sec: 30 },
    { key: "1min", sec: 60 },
    { key: "3min", sec: 180 },
    { key: "5min", sec: 300 },
    { key: "12min", sec: 720 },
    { key: "20min", sec: 1200 },
  ];
  return windows.map((w) => ({
    key: w.key,
    sec: w.sec,
    watts: duration + 1 >= w.sec ? Math.round(rollingMeanMax(powers, dt, w.sec)) : 0,
  }));
}

export interface LoadPoint {
  date: string;
  tss: number;
  ctl: number;
  atl: number;
  tsb: number;
}

export function trainingLoadSeries(workouts: Workout[]): LoadPoint[] {
  if (!workouts.length) return [];
  const byDay = new Map<string, number>();
  for (const w of workouts) {
    const day = w.startTime.slice(0, 10);
    byDay.set(day, (byDay.get(day) ?? 0) + w.summary.tss);
  }
  const sorted = [...workouts].sort((a, b) => +new Date(a.startTime) - +new Date(b.startTime));
  const end = new Date();
  end.setHours(12, 0, 0, 0);
  const first = new Date(sorted[0].startTime);
  first.setHours(12, 0, 0, 0);
  first.setDate(first.getDate() - 7);
  const earliest = new Date(end);
  earliest.setDate(earliest.getDate() - 89);
  const start = first < earliest ? earliest : first;
  const days: string[] = [];
  for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
    days.push(d.toISOString().slice(0, 10));
  }
  let ctl = 0;
  let atl = 0;
  const out: LoadPoint[] = [];
  for (const date of days) {
    const tss = byDay.get(date) ?? 0;
    ctl = ctl + (tss - ctl) / 42;
    atl = atl + (tss - atl) / 7;
    out.push({
      date,
      tss,
      ctl: Math.round(ctl * 10) / 10,
      atl: Math.round(atl * 10) / 10,
      tsb: Math.round((ctl - atl) * 10) / 10,
    });
  }
  return out;
}

export function trainingStatus(points: LoadPoint[]): {
  fitness: number;
  consistency: number;
  recovery: number;
  label: TrainingLabel;
  ctl: number;
  atl: number;
  tsb: number;
} {
  const last = points[points.length - 1];
  if (!last) {
    return {
      fitness: 0,
      consistency: 0,
      recovery: 0,
      label: "untrained",
      ctl: 0,
      atl: 0,
      tsb: 0,
    };
  }
  const ctl = last?.ctl ?? 0;
  const atl = last?.atl ?? 0;
  const tsb = last?.tsb ?? 0;
  const fitness = Math.round(Math.min(100, (1 - Math.exp(-ctl / 16)) * 100));
  const recovery = Math.round(Math.min(100, Math.max(0, 58 + tsb * 2.4)));
  const last7 = points.slice(-7);
  const ridden = last7.filter((p) => p.tss > 0).length;
  const consistency = Math.round(Math.min(100, (ridden / 4) * 88));
  let label: TrainingLabel = "maintaining";
  if (ctl < 6) label = "untrained";
  else if (tsb > 12 && ctl > 22) label = "fresh";
  else if (tsb > 6 && ctl > 32) label = "peaking";
  else if (tsb < -14) label = "overreaching";
  else if (tsb >= -8) label = "productive";
  return {
    fitness: Math.min(100, fitness),
    consistency: Math.min(100, consistency),
    recovery: Math.min(100, recovery),
    label,
    ctl,
    atl,
    tsb,
  };
}

export function weeklyAvgPower(workouts: Workout[]) {
  if (!workouts.length) return [];
  const weeks: { label: string; watts: number }[] = [];
  const now = new Date();
  for (let w = 3; w >= 0; w--) {
    const start = new Date(now);
    start.setDate(start.getDate() - (w + 1) * 7);
    const end = new Date(now);
    end.setDate(end.getDate() - w * 7);
    const set = workouts.filter((x) => {
      const t = new Date(x.startTime).getTime();
      return t >= start.getTime() && t < end.getTime();
    });
    weeks.push({
      label: `Week ${4 - w}`,
      watts: set.length ? Math.round(mean(set.map((s) => s.summary.avgPower))) : 0,
    });
  }
  return weeks;
}

export function detectRecords(
  workout: Workout,
  existing: PersonalRecord[],
): PersonalRecord[] {
  const curve = powerCurve(workout.series);
  const candidates: Omit<PersonalRecord, "id" | "previous">[] = [
    ...curve.map((c) => ({
      metric: `power_${c.key}`,
      label: `Highest ${c.key} power`,
      value: c.watts,
      unit: "W",
      workoutId: workout.id,
      date: workout.startTime,
    })),
    {
      metric: "distance",
      label: "Longest distance",
      value: workout.summary.distanceKm,
      unit: "km",
      workoutId: workout.id,
      date: workout.startTime,
    },
    {
      metric: "duration",
      label: "Longest workout",
      value: workout.summary.durationSec,
      unit: "s",
      workoutId: workout.id,
      date: workout.startTime,
    },
    {
      metric: "calories",
      label: "Most calories",
      value: workout.summary.calories,
      unit: "kcal",
      workoutId: workout.id,
      date: workout.startTime,
    },
    {
      metric: "cadence",
      label: "Highest cadence",
      value: workout.summary.maxCadence,
      unit: "rpm",
      workoutId: workout.id,
      date: workout.startTime,
    },
    {
      metric: "speed",
      label: "Highest speed",
      value: workout.summary.maxSpeed,
      unit: "km/h",
      workoutId: workout.id,
      date: workout.startTime,
    },
  ];
  const next: PersonalRecord[] = [];
  for (const c of candidates) {
    if (!c.value) continue;
    const prev = existing.find((p) => p.metric === c.metric);
    if (!prev || c.value > prev.value + 0.05) {
      next.push({
        id: `${c.metric}_${workout.id}`,
        ...c,
        previous: prev?.value,
      });
    }
  }
  return next;
}

export function mergeRecords(
  existing: PersonalRecord[],
  incoming: PersonalRecord[],
) {
  const map = new Map(existing.map((r) => [r.metric, r]));
  for (const r of incoming) map.set(r.metric, r);
  return [...map.values()];
}

export function trendDelta(workouts: Workout[]) {
  const sorted = [...workouts].sort(
    (a, b) => +new Date(a.startTime) - +new Date(b.startTime),
  );
  if (sorted.length < 4) return 0;
  const first = mean(sorted.slice(0, 3).map((w) => w.summary.avgPower));
  const last = mean(sorted.slice(-3).map((w) => w.summary.avgPower));
  if (first <= 0) return 0;
  return (last - first) / first;
}
