import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type {
  AIInsight,
  BodyMeasurement,
  ChatMessage,
  ConnectionState,
  DailyActivity,
  Goals,
  LiveSession,
  PersonalRecord,
  ThemeMode,
  UserProfile,
  Workout,
  WorkoutPlan,
} from "./types";
import { detectRecords, mergeRecords, summarizeSeries } from "./analytics";
import { extraRecords } from "./advanced";
import { nid, todayKey } from "./format";
import { DEFAULT_GOALS, DEFAULT_PROFILE } from "./seed";
import { tickSession } from "./telemetry";
import { scalePlanToFtp } from "./workouts";
import { hushVoice, speakCue } from "./voice";
import {
  bleAvailable,
  connectBike,
  connectHrStrap,
  disconnectCurrentBike,
  disconnectCurrentStrap,
  getLastBikeSample,
  getLinkedBike,
  getLinkedStrap,
  isBikeFresh,
  isHrFresh,
  onBikeDisconnect,
  onBikeSample,
} from "./ble";
import { healthPush, healthRequest, healthStatus } from "./health";

let persistWrites = true;

const storage = createJSONStorage(() => ({
  getItem: (name: string) => localStorage.getItem(name),
  setItem: (name: string, value: string) => {
    if (!persistWrites) return;
    localStorage.setItem(name, value);
  },
  removeItem: (name: string) => localStorage.removeItem(name),
}));

const emptyTelemetry = {
  t: 0,
  power: 0,
  cadence: 0,
  speed: 0,
  distance: 0,
  heartRate: 0,
  calories: 0,
  resistance: 0,
  battery: 0,
};

export interface FitnessState {
  hydrated: boolean;
  theme: ThemeMode;
  onboardingComplete: boolean;
  voiceEnabled: boolean;
  healthSyncEnabled: boolean;
  lastHealthSync: string | null;
  healthDetail: string | null;
  historyNotice: string | null;
  profile: UserProfile;
  goals: Goals;
  bodyHistory: BodyMeasurement[];
  workouts: Workout[];
  activity: DailyActivity[];
  records: PersonalRecord[];
  achievements: { id: string; title: string; detail: string; earnedAt: string }[];
  customPlans: WorkoutPlan[];
  insights: AIInsight[];
  chat: ChatMessage[];
  connection: ConnectionState;
  deviceBattery: number;
  deviceHr: number;
  deviceName: string;
  bikeHasHr: boolean;
  hrStreaming: boolean;
  hrConnection: ConnectionState;
  hrDeviceName: string;
  bleError: string | null;
  session: LiveSession | null;
  lastNewRecords: PersonalRecord[];

  setHydrated: (v: boolean) => void;
  setTheme: (t: ThemeMode) => void;
  setVoice: (v: boolean) => void;
  setHealthSync: (v: boolean) => void;
  completeOnboarding: (profile: UserProfile, goals: Goals) => void;
  updateProfile: (patch: Partial<UserProfile>) => void;
  updateGoals: (patch: Partial<Goals>) => void;
  logWeight: (weightKg: number) => void;
  setConnection: (c: ConnectionState) => void;
  startScan: () => void;
  connectDevice: (opts?: { deviceId?: string; name?: string; acceptAll?: boolean }) => Promise<void>;
  connectHr: (opts: { deviceId: string; name?: string }) => Promise<void>;
  disconnectHr: () => void;
  disconnectDevice: () => void;
  startWorkout: (plan: WorkoutPlan) => boolean;
  pauseWorkout: () => void;
  resumeWorkout: () => void;
  setResistance: (n: number) => void;
  tick: (dt: number) => void;
  finishWorkout: () => string | null;
  discardWorkout: () => void;
  addPlan: (plan: WorkoutPlan) => void;
  addChat: (role: ChatMessage["role"], content: string) => void;
  addInsight: (insight: Omit<AIInsight, "id" | "createdAt">) => void;
  clearHistory: () => void;
  syncHealth: () => Promise<void>;
}

export const useFitnessStore = create<FitnessState>()(
  persist(
    (set, get) => ({
      hydrated: false,
      theme: "dark",
      onboardingComplete: false,
      voiceEnabled: true,
      healthSyncEnabled: false,
      lastHealthSync: null,
      healthDetail: null,
      historyNotice: null,
      profile: DEFAULT_PROFILE,
      goals: DEFAULT_GOALS,
      bodyHistory: [],
      workouts: [],
      activity: [],
      records: [],
      achievements: [],
      customPlans: [],
      insights: [],
      chat: [],
      connection: "disconnected",
      deviceBattery: 0,
      deviceHr: 0,
      deviceName: "",
      bikeHasHr: false,
      hrStreaming: false,
      hrConnection: "disconnected",
      hrDeviceName: "",
      bleError: null,
      session: null,
      lastNewRecords: [],

      setHydrated: (v) => set({ hydrated: v }),
      setTheme: (theme) => set({ theme }),
      setVoice: (voiceEnabled) => set({ voiceEnabled }),
      setHealthSync: (healthSyncEnabled) => set({ healthSyncEnabled }),

      completeOnboarding: (profile, goals) => {
        set({
          profile,
          goals: {
            ...goals,
            targetWeightKg: goals.targetWeightKg || profile.weightKg,
          },
          onboardingComplete: true,
          workouts: [],
          activity: [],
          records: [],
          achievements: [],
          insights: [],
          chat: [],
          customPlans: [],
          bodyHistory:
            profile.weightKg > 0
              ? [{ id: nid(), date: new Date().toISOString(), weightKg: profile.weightKg }]
              : [],
        });
      },

      updateProfile: (patch) =>
        set((s) => {
          const profile = { ...s.profile, ...patch };
          if (patch.weightKg && patch.weightKg !== s.profile.weightKg) {
            return {
              profile,
              bodyHistory: [
                ...s.bodyHistory,
                { id: nid(), date: new Date().toISOString(), weightKg: patch.weightKg },
              ],
            };
          }
          return { profile };
        }),

      updateGoals: (patch) => set((s) => ({ goals: { ...s.goals, ...patch } })),

      logWeight: (weightKg) =>
        set((s) => ({
          profile: { ...s.profile, weightKg },
          bodyHistory: [...s.bodyHistory, { id: nid(), date: new Date().toISOString(), weightKg }],
        })),

      setConnection: (connection) => set({ connection }),

      startScan: () => {
        set({ connection: "scanning", bleError: null });
      },

      connectDevice: async (opts) => {
        set({ connection: "connecting", bleError: null });
        try {
          if (!bleAvailable()) {
            throw new Error(
              "Bluetooth is not available here. Install the Velora APK on your phone, or open this studio in Chrome on Android.",
            );
          }
          const bike = await connectBike(opts);
          const linked = getLinkedBike();
          const sample = getLastBikeSample().sample;
          set({
            connection: "connected",
            deviceName: bike.name || linked?.name || "FS-583ADC",
            bikeHasHr: !!(bike.hasHr || linked?.hasHr || sample.heartRate != null),
            hrStreaming: sample.heartRate != null,
            deviceHr: sample.heartRate ?? 0,
            deviceBattery: sample.battery ?? get().deviceBattery,
            bleError: null,
          });
        } catch (err) {
          const msg = err instanceof Error ? err.message : "Could not connect";
          const cancelled = /cancel|chooser|user/i.test(msg);
          set({
            connection: "disconnected",
            bleError: cancelled ? null : msg,
          });
        }
      },

      disconnectDevice: () => {
        disconnectCurrentBike();
        set({
          connection: "disconnected",
          bikeHasHr: false,
          hrStreaming: false,
          deviceHr: 0,
          deviceBattery: 0,
        });
      },

      connectHr: async (opts) => {
        set({ hrConnection: "connecting", bleError: null });
        try {
          const strap = await connectHrStrap(opts);
          set({
            hrConnection: "connected",
            hrDeviceName: strap.name,
            bleError: null,
          });
        } catch (err) {
          const msg = err instanceof Error ? err.message : "Could not connect HR";
          set({ hrConnection: "disconnected", bleError: msg });
        }
      },

      disconnectHr: () => {
        disconnectCurrentStrap();
        set({ hrConnection: "disconnected", hrDeviceName: "" });
      },

      startWorkout: (rawPlan) => {
        if (!getLinkedBike()) {
          set({ bleError: "Connect the RPM600 before starting a ride." });
          return false;
        }
        const plan = scalePlanToFtp(rawPlan, get().profile.ftp);
        const workoutId = nid();
        persistWrites = false;
        set({
          lastNewRecords: [],
          bleError: null,
          session: {
            workoutId,
            plan,
            status: "active",
            startedAt: Date.now(),
            elapsedSec: 0,
            pausedAt: null,
            accumulatedPauseMs: 0,
            intervalIndex: 0,
            resistance: 0,
            telemetry: { ...emptyTelemetry, battery: get().deviceBattery },
            series: [],
            events: [{ t: 0, kind: "interval", text: plan.intervals[0]?.label ?? "Start" }],
            lastCueAt: -20,
            lastCue: "Waiting for Indoor Bike Data.",
            battery: get().deviceBattery,
            source: "waiting",
            hrSource: getLinkedStrap() ? "strap" : get().bikeHasHr || getLinkedBike()?.hasHr ? "ble" : "none",
            bleOrigin: undefined,
          },
        });
        speakCue("Let's ride.", get().voiceEnabled);
        return true;
      },

      pauseWorkout: () => {
        const session = get().session;
        if (!session || session.status !== "active") return;
        hushVoice();
        set({
          session: {
            ...session,
            status: "paused",
            pausedAt: Date.now(),
            events: [
              ...session.events,
              { t: session.elapsedSec, kind: "pause", text: "Paused" },
            ],
          },
        });
      },

      resumeWorkout: () => {
        const session = get().session;
        if (!session || session.status !== "paused") return;
        const pausedAt = session.pausedAt ?? Date.now();
        set({
          session: {
            ...session,
            status: "active",
            pausedAt: null,
            accumulatedPauseMs: session.accumulatedPauseMs + (Date.now() - pausedAt),
            events: [
              ...session.events,
              { t: session.elapsedSec, kind: "resume", text: "Resumed" },
            ],
          },
        });
      },

      setResistance: (n) => {
        const session = get().session;
        if (!session) return;
        set({ session: { ...session, resistance: Math.min(20, Math.max(0, n)) } });
      },

      tick: (dt) => {
        const session = get().session;
        if (!session || session.status !== "active") return;
        const fresh = isBikeFresh();
        const live = fresh ? getLastBikeSample().sample : null;
        const hrLive = isHrFresh() ? getLastBikeSample().sample.heartRate : live?.heartRate;
        const { session: next, cue } = tickSession(
          {
            ...session,
            hrSource: getLinkedStrap() ? "strap" : get().bikeHasHr || getLinkedBike()?.hasHr ? "ble" : session.hrSource,
          },
          dt,
          get().profile,
          live ? { ...live, heartRate: hrLive } : null,
        );
        if (cue) speakCue(cue.text, get().voiceEnabled);
        const timedOut =
          next.plan.kind !== "free" && next.elapsedSec >= next.plan.durationSec;
        set({
          session: next,
          deviceBattery: next.battery,
          deviceHr: isHrFresh() ? (getLastBikeSample().sample.heartRate ?? next.telemetry.heartRate) : get().deviceHr,
          hrStreaming: isHrFresh() || get().hrStreaming,
          bikeHasHr: get().bikeHasHr || next.hrSource === "ble" || next.hrSource === "strap",
        });
        if (timedOut) get().finishWorkout();
      },

      finishWorkout: () => {
        const session = get().session;
        if (!session) return null;
        hushVoice();
        const liveSamples = session.series.filter(
          (s) => s.power > 0 || s.cadence > 0 || s.speed > 0,
        );
        if (session.elapsedSec < 10 || liveSamples.length < 5) {
          persistWrites = true;
          set({
            session: null,
            bleError:
              liveSamples.length < 5
                ? "No FTMS data received. Ride not saved."
                : null,
          });
          return null;
        }
        const profile = get().profile;
        const durationSec = Math.max(1, Math.round(session.elapsedSec));
        const summary = summarizeSeries(session.series, durationSec, profile);
        const workout: Workout = {
          id: session.workoutId,
          planId: session.plan.id,
          name: session.plan.name,
          kind: session.plan.kind,
          startTime: new Date(session.startedAt).toISOString(),
          endTime: new Date().toISOString(),
          summary,
          series: session.series,
          events: [
            ...session.events,
            { t: durationSec, kind: "complete", text: "Workout complete" },
          ],
        };
        if (session.plan.kind === "ftp" && summary.avgPower > 80) {
          const testSlice = session.series.filter((s) => s.t >= 720 && s.t <= 1920);
          const avg =
            testSlice.reduce((a, s) => a + s.power, 0) / Math.max(1, testSlice.length);
          const ftp = Math.round(avg * 0.95);
          if (ftp > 80) {
            set({ profile: { ...profile, ftp, ftpEstimated: false } });
          }
        }
        const incoming = [
          ...detectRecords(workout, get().records),
          ...extraRecords(workout, get().records),
        ];
        const key = todayKey();
        const activity = get().activity.map((d) =>
          d.date === key
            ? {
                ...d,
                cycleMin: d.cycleMin + summary.durationSec / 60,
                cycleKm: Math.round((d.cycleKm + summary.distanceKm) * 10) / 10,
                cycleKcal: d.cycleKcal + summary.calories,
              }
            : d,
        );
        const hasToday = activity.some((d) => d.date === key);
        const nextActivity = hasToday
          ? activity
          : [
              ...activity,
              {
                date: key,
                steps: 0,
                walkMeters: 0,
                cycleMin: summary.durationSec / 60,
                cycleKm: summary.distanceKm,
                cycleKcal: summary.calories,
                otherKcal: 0,
              },
            ];
        const achievements = [...get().achievements];
        if (get().workouts.length === 0) {
          achievements.push({
            id: nid(),
            title: "First connection",
            detail: "You finished a session on the RPM600.",
            earnedAt: workout.startTime,
          });
        }
        persistWrites = true;
        set({
          session: null,
          workouts: [...get().workouts, workout],
          records: mergeRecords(get().records, incoming),
          lastNewRecords: incoming,
          activity: nextActivity,
          achievements,
          deviceBattery: session.battery,
        });
        speakCue("Workout complete. Nice work.", get().voiceEnabled);
        if (get().healthSyncEnabled) {
          void get().syncHealth();
        }
        return workout.id;
      },

      discardWorkout: () => {
        hushVoice();
        set({ session: null });
        persistWrites = true;
      },

      addPlan: (plan) => set((s) => ({ customPlans: [plan, ...s.customPlans] })),

      addChat: (role, content) =>
        set((s) => ({
          chat: [
            ...s.chat,
            { id: nid(), role, content, createdAt: new Date().toISOString() },
          ],
        })),

      addInsight: (insight) =>
        set((s) => ({
          insights: [
            {
              ...insight,
              id: nid(),
              createdAt: new Date().toISOString(),
            },
            ...s.insights,
          ].slice(0, 40),
        })),

      clearHistory: () => {
        persistWrites = true;
        const n = get().workouts.length;
        set({
          workouts: [],
          activity: [],
          records: [],
          achievements: [],
          insights: [],
          chat: [],
          customPlans: [],
          session: null,
          lastNewRecords: [],
          historyNotice: n ? `Cleared ${n} rides` : "History already empty",
        });
      },

      syncHealth: async () => {
        persistWrites = true;
        const status = await healthStatus();
        if (!status.available) {
          set({
            healthSyncEnabled: false,
            healthDetail: status.reason,
          });
          return;
        }
        const access = await healthRequest();
        if (!access.granted) {
          set({
            healthSyncEnabled: false,
            healthDetail: access.detail,
          });
          return;
        }
        const s = get();
        const result = await healthPush({
          workouts: s.workouts,
          activity: s.activity,
          profile: s.profile,
        });
        let activity = s.activity;
        const stepDays = result.stepsDays ?? [];
        if (result.ok && (result.stepsRead > 0 || stepDays.length)) {
          const apply = (date: string, steps: number) => {
            const has = activity.some((d) => d.date === date);
            if (has) {
              activity = activity.map((d) => (d.date === date ? { ...d, steps: Math.max(d.steps, steps) } : d));
            } else {
              activity = [
                ...activity,
                {
                  date,
                  steps,
                  walkMeters: 0,
                  cycleMin: 0,
                  cycleKm: 0,
                  cycleKcal: 0,
                  otherKcal: 0,
                },
              ];
            }
          };
          if (stepDays.length) {
            for (const d of stepDays) if (d.count > 0) apply(d.date, d.count);
          } else if (result.stepsRead > 0) {
            apply(todayKey(), result.stepsRead);
          }
        }
        set({
          activity,
          healthSyncEnabled: result.ok,
          lastHealthSync: result.ok ? new Date().toISOString() : s.lastHealthSync,
          healthDetail: result.detail,
        });
      },
    }),
    {
      name: "velora-v3",
      storage,
      skipHydration: true,
      partialize: (s) => {
        const {
          hydrated: _h,
          session: _session,
          lastNewRecords: _n,
          bleError: _e,
          connection: _c,
          hrConnection: _hc,
          historyNotice: _hn,
          deviceHr: _hr,
          bikeHasHr: _bh,
          hrStreaming: _hs,
          deviceBattery: _bat,
          hrDeviceName: _hdn,
          ...rest
        } = s;
        return rest;
      },
    },
  ),
);

if (typeof window !== "undefined") {
  onBikeSample((sample) => {
    const patch: Partial<FitnessState> = {};
    if (sample.battery != null) patch.deviceBattery = sample.battery;
    if (sample.heartRate != null && sample.heartRate >= 0 && sample.heartRate <= 240) {
      patch.deviceHr = sample.heartRate;
      patch.bikeHasHr = true;
      patch.hrStreaming = true;
    }
    if (Object.keys(patch).length) useFitnessStore.setState(patch);
  });
  onBikeDisconnect(() => {
    useFitnessStore.setState({
      connection: "disconnected",
      bikeHasHr: false,
      hrStreaming: false,
      deviceHr: 0,
    });
  });
}
