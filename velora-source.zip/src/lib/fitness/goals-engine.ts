import type { DailyActivity, Goals, UserProfile, Workout } from "./types";
import { ageFromDob } from "./format";

/** Mifflin–St Jeor resting energy, kcal/day. 0 if profile is incomplete. */
export function mifflinStJeor(profile: UserProfile) {
  if (profile.weightKg < 30 || profile.heightCm < 120) return 0;
  const age = ageFromDob(profile.dob);
  if (age < 12) return 0;
  const s = profile.sex === "female" ? -161 : 5;
  return Math.round(10 * profile.weightKg + 6.25 * profile.heightCm - 5 * age + s);
}

export function tdeeKcal(profile: UserProfile) {
  const bmr = mifflinStJeor(profile);
  if (!bmr) return 0;
  const pal =
    profile.fitnessLevel === "advanced" ? 1.55 : profile.fitnessLevel === "beginner" ? 1.4 : 1.5;
  return Math.round(bmr * pal);
}

export interface WeightPlan {
  remainingKg: number;
  direction: "lose" | "gain" | "hold";
  weeklyKg: number;
  dailyKcalDelta: number;
  tdee: number;
  weekCycleKcal: number;
  note: string;
}

export function weightPlan(
  profile: UserProfile,
  goals: Goals,
  workouts: Workout[],
  activity: DailyActivity[],
): WeightPlan | null {
  if (profile.weightKg < 30 || goals.targetWeightKg < 30) return null;
  const remainingKg = Math.round((profile.weightKg - goals.targetWeightKg) * 10) / 10;
  const direction: WeightPlan["direction"] =
    remainingKg > 0.3 ? "lose" : remainingKg < -0.3 ? "gain" : "hold";
  const weekCycleKcal = workouts
    .filter((w) => Date.now() - +new Date(w.startTime) < 7 * 86400000)
    .reduce((a, w) => a + w.summary.calories, 0);
  const weekSteps = activity
    .filter((d) => Date.now() - +new Date(d.date) < 8 * 86400000)
    .reduce((a, d) => a + d.steps, 0);
  const tdee = tdeeKcal(profile);
  // ~7700 kcal per kg fat mass — planning figure, not a lab measurement.
  const weeklyKg = direction === "lose" ? 0.4 : direction === "gain" ? 0.25 : 0;
  const dailyKcalDelta =
    direction === "lose" ? Math.round((weeklyKg * 7700) / 7) : direction === "gain" ? Math.round((weeklyKg * 7700) / 7) : 0;
  let note: string;
  if (direction === "hold") {
    note = "At target. Log weight in Profile if it changes.";
  } else if (direction === "lose") {
    note = tdee
      ? `${remainingKg.toFixed(1)} kg to ${goals.targetWeightKg} kg. About ${dailyKcalDelta} kcal/day below estimated TDEE (${tdee}). Indoor rides this week: ${Math.round(weekCycleKcal)} kcal. Food is not logged here.`
      : `${remainingKg.toFixed(1)} kg to lose. Add age, height, and weight for a TDEE estimate. Food is not logged.`;
  } else {
    note = `${Math.abs(remainingKg).toFixed(1)} kg to gain. This app does not prescribe a surplus diet.`;
  }
  if (weekSteps) note += ` Steps this week: ${weekSteps.toLocaleString()}.`;
  return { remainingKg, direction, weeklyKg, dailyKcalDelta, tdee, weekCycleKcal, note };
}
