import type { WorkoutInterval, WorkoutKind, WorkoutPlan } from "./types";
import { nid } from "./format";

function iv(
  durationSec: number,
  type: WorkoutInterval["type"],
  ftpLo?: number,
  ftpHi?: number,
  cmin = 75,
  cmax = 90,
  label?: string,
): WorkoutInterval {
  return {
    durationSec,
    type,
    label,
    targetCadence: { min: cmin, max: cmax },
    targetFtpPct:
      ftpLo !== undefined && ftpHi !== undefined
        ? { min: ftpLo, max: ftpHi }
        : undefined,
  };
}

export function planDuration(intervals: WorkoutInterval[]) {
  return intervals.reduce((s, i) => i.durationSec + s, 0);
}

export function makePlan(
  name: string,
  description: string,
  kind: WorkoutKind,
  intervals: WorkoutInterval[],
  source: WorkoutPlan["source"] = "library",
): WorkoutPlan {
  return {
    id: nid(),
    name,
    description,
    kind,
    durationSec: planDuration(intervals),
    intervals,
    source,
  };
}

/** Library stored as Coggan %FTP. Watts appear only after scalePlanToFtp with a real FTP. */
export const LIBRARY: WorkoutPlan[] = [
  makePlan(
    "Free ride",
    "Open-ended spin. Turn the physical knob. No watt window until you set FTP.",
    "free",
    [iv(3600, "free", undefined, undefined, 70, 95, "Free ride")],
  ),
  makePlan(
    "40 min endurance",
    "Aerobic base with a short tempo lift. Manual resistance — stay in the watt window.",
    "endurance",
    [
      iv(300, "warmup", 0.5, 0.6, 75, 85, "Warm-up"),
      iv(600, "endurance", 0.56, 0.75, 75, 85, "Zone 2"),
      iv(300, "tempo", 0.76, 0.9, 80, 90, "Tempo"),
      iv(180, "recovery", 0.4, 0.55, 70, 80, "Recovery"),
      iv(600, "endurance", 0.56, 0.75, 75, 85, "Zone 2"),
      iv(420, "cooldown", 0.4, 0.5, 70, 80, "Cooldown"),
    ],
  ),
  makePlan(
    "Sweet spot 3×8",
    "Three eight-minute efforts just below threshold. The fastest way to move FTP.",
    "threshold",
    [
      iv(300, "warmup", 0.5, 0.6, 75, 85, "Warm-up"),
      iv(480, "threshold", 0.88, 0.94, 80, 92, "Sweet spot 1"),
      iv(180, "recovery", 0.45, 0.55, 70, 80, "Recover"),
      iv(480, "threshold", 0.88, 0.94, 80, 92, "Sweet spot 2"),
      iv(180, "recovery", 0.45, 0.55, 70, 80, "Recover"),
      iv(480, "threshold", 0.88, 0.94, 80, 92, "Sweet spot 3"),
      iv(300, "cooldown", 0.4, 0.5, 70, 80, "Cooldown"),
    ],
  ),
  makePlan(
    "30/30 VO2",
    "Twelve rounds of 30 seconds on, 30 seconds off. Keep cadence high when it bites.",
    "hiit",
    [
      iv(300, "warmup", 0.5, 0.6, 80, 90, "Warm-up"),
      ...Array.from({ length: 12 }, (_, i) => [
        iv(30, "interval", 1.1, 1.2, 90, 105, `On ${i + 1}`),
        iv(30, "recovery", 0.4, 0.5, 70, 80, `Off ${i + 1}`),
      ]).flat(),
      iv(240, "cooldown", 0.4, 0.5, 70, 80, "Cooldown"),
    ],
  ),
  makePlan(
    "Tempo builder",
    "Sustained tempo with a short threshold spike. Hold form when the legs get heavy.",
    "tempo",
    [
      iv(240, "warmup", 0.5, 0.6, 75, 85, "Warm-up"),
      iv(720, "tempo", 0.76, 0.9, 80, 90, "Tempo"),
      iv(180, "recovery", 0.45, 0.55, 70, 80, "Recover"),
      iv(300, "threshold", 0.95, 1.05, 82, 92, "Threshold"),
      iv(240, "tempo", 0.76, 0.88, 80, 88, "Tempo"),
      iv(240, "cooldown", 0.4, 0.5, 70, 80, "Cooldown"),
    ],
  ),
  makePlan(
    "Recovery spin",
    "Easy spin. Low resistance, nasal breathing, shake out yesterday.",
    "recovery",
    [
      iv(300, "warmup", 0.4, 0.5, 70, 80, "Ease in"),
      iv(1200, "recovery", 0.4, 0.55, 70, 80, "Easy"),
      iv(300, "cooldown", 0.35, 0.45, 65, 75, "Ease out"),
    ],
  ),
  makePlan(
    "20 min FTP test",
    "Standard Coggan 20-minute all-out after a primer. FTP is 95% of average power in the test block.",
    "ftp",
    [
      iv(300, "warmup", 0.5, 0.6, 75, 85, "Warm-up"),
      iv(180, "tempo", 0.76, 0.9, 80, 90, "Opener"),
      iv(60, "interval", 1.1, 1.2, 90, 100, "Spike"),
      iv(180, "recovery", 0.4, 0.55, 70, 80, "Settle"),
      iv(1200, "threshold", 0.95, 1.25, 80, 95, "20-min test"),
      iv(300, "cooldown", 0.4, 0.5, 70, 80, "Cooldown"),
    ],
  ),
];

export function intervalAt(plan: WorkoutPlan, elapsedSec: number) {
  let cursor = 0;
  for (let i = 0; i < plan.intervals.length; i++) {
    const next = cursor + plan.intervals[i].durationSec;
    if (elapsedSec < next || i === plan.intervals.length - 1) {
      return {
        index: i,
        interval: plan.intervals[i],
        start: cursor,
        end: next,
        remaining: Math.max(0, next - elapsedSec),
      };
    }
    cursor = next;
  }
  const last = plan.intervals[plan.intervals.length - 1];
  const start = plan.durationSec - last.durationSec;
  return {
    index: plan.intervals.length - 1,
    interval: last,
    start,
    end: plan.durationSec,
    remaining: 0,
  };
}

/** Apply rider FTP. Library uses %FTP. If FTP is 0, watt windows stay empty. */
export function scalePlanToFtp(plan: WorkoutPlan, ftp: number): WorkoutPlan {
  const intervals = plan.intervals.map((ivl) => {
    if (ivl.targetFtpPct && ftp > 0) {
      return {
        ...ivl,
        targetPower: {
          min: Math.round(ftp * ivl.targetFtpPct.min),
          max: Math.round(ftp * ivl.targetFtpPct.max),
        },
      };
    }
    if (ftp <= 0) {
      return { ...ivl, targetPower: undefined };
    }
    return ivl;
  });
  return { ...plan, id: nid(), intervals };
}

export function validatePlan(input: unknown): WorkoutPlan | null {
  if (!input || typeof input !== "object") return null;
  const raw = input as Record<string, unknown>;
  const name = String(raw.name ?? "Custom workout").slice(0, 60);
  const description = String(raw.description ?? "").slice(0, 240);
  const intervalsIn = Array.isArray(raw.intervals) ? raw.intervals : [];
  const intervals: WorkoutInterval[] = [];
  for (const item of intervalsIn) {
    if (!item || typeof item !== "object") continue;
    const it = item as Record<string, unknown>;
    const durationSec = Math.round(Number(it.duration) || Number(it.durationSec) || 0);
    if (durationSec < 10 || durationSec > 3600) continue;
    const type = String(it.type ?? "endurance").toLowerCase() as WorkoutInterval["type"];
    const allowed: WorkoutInterval["type"][] = [
      "warmup",
      "endurance",
      "tempo",
      "threshold",
      "interval",
      "recovery",
      "cooldown",
      "free",
    ];
    const safeType = allowed.includes(type) ? type : "endurance";
    let targetPower: WorkoutInterval["targetPower"];
    let targetFtpPct: WorkoutInterval["targetFtpPct"];
    const tp = it.targetPower;
    const pct = it.targetFtpPct;
    if (Array.isArray(pct) && pct.length === 2) {
      const min = Number(pct[0]);
      const max = Number(pct[1]);
      if (min > 0 && max > 0) targetFtpPct = { min, max };
    } else if (pct && typeof pct === "object") {
      const o = pct as { min?: number; max?: number };
      const min = Number(o.min);
      const max = Number(o.max);
      if (min > 0 && max > 0) targetFtpPct = { min, max };
    }
    if (Array.isArray(tp) && tp.length === 2) {
      const min = clampW(Number(tp[0]));
      const max = clampW(Number(tp[1]));
      if (min && max) targetPower = { min: Math.min(min, max), max: Math.max(min, max) };
    } else if (tp && typeof tp === "object") {
      const o = tp as { min?: number; max?: number };
      const min = clampW(Number(o.min));
      const max = clampW(Number(o.max));
      if (min && max) targetPower = { min: Math.min(min, max), max: Math.max(min, max) };
    }
    intervals.push({
      durationSec,
      type: safeType,
      targetPower,
      targetFtpPct,
      targetCadence: { min: 70, max: 95 },
      label: String(it.label ?? it.type ?? "Interval").slice(0, 32),
    });
  }
  if (!intervals.length) return null;
  const durationSec = planDuration(intervals);
  if (durationSec < 180 || durationSec > 3 * 3600) return null;
  const kind = (
    ["free", "endurance", "tempo", "threshold", "hiit", "recovery", "ftp", "custom"] as WorkoutKind[]
  ).includes(raw.kind as WorkoutKind)
    ? (raw.kind as WorkoutKind)
    : "custom";
  return {
    id: nid(),
    name,
    description: description || "AI-built session",
    kind,
    durationSec,
    intervals,
    source: "ai",
  };
}

function clampW(n: number) {
  if (!Number.isFinite(n) || n <= 0) return 0;
  return Math.round(Math.min(500, Math.max(40, n)));
}
