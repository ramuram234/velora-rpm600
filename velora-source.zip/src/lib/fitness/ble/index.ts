import { canUseWebBluetooth, connectWebBluetooth } from "./web";
import { connectNativeBike, connectNativeHr, isNativeApp, scanNativeBikes } from "./native";
import {
  disconnectBike,
  disconnectStrap,
  getLastBikeSample,
  getLinkedBike,
  getLinkedStrap,
  isBikeFresh,
  isHrFresh,
  onBikeDisconnect,
  onBikeSample,
} from "./runtime";

export {
  disconnectBike,
  disconnectStrap,
  getLastBikeSample,
  getLinkedBike,
  getLinkedStrap,
  isBikeFresh,
  isHrFresh,
  onBikeDisconnect,
  onBikeSample,
  isNativeApp,
  canUseWebBluetooth,
};

export interface ScannedBike {
  id: string;
  name: string;
}

export interface ConnectedBike {
  id: string;
  name: string;
  hasHr?: boolean;
  hasBattery?: boolean;
  manufacturer?: string;
  model?: string;
  hardware?: string;
  software?: string;
}

export function bleAvailable() {
  return isNativeApp() || canUseWebBluetooth();
}

export async function scanBikes(): Promise<ScannedBike[]> {
  if (isNativeApp()) return scanNativeBikes();
  return [];
}

export async function connectBike(opts?: {
  deviceId?: string;
  name?: string;
  acceptAll?: boolean;
}): Promise<ConnectedBike> {
  if (isNativeApp()) {
    if (!opts?.deviceId) throw new Error("Pick a bike from the scan list");
    return connectNativeBike(opts.deviceId, opts.name || "Indoor bike");
  }
  return connectWebBluetooth(opts?.acceptAll);
}

export async function connectHrStrap(opts: { deviceId: string; name?: string }) {
  if (!isNativeApp()) {
    throw new Error("A second heart-rate device can be paired in the Android app.");
  }
  return connectNativeHr(opts.deviceId, opts.name || "HR strap");
}

export async function disconnectCurrentBike() {
  disconnectBike();
}

export async function disconnectCurrentStrap() {
  disconnectStrap();
}

export function looksLikeHr(name: string) {
  return /polar|garmin|wahoo|tickr|hrm|heart|coospo|magene|igpsport|strap/i.test(name);
}
