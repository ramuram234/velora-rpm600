import type { BikeSample } from "./ftms";

export type LinkKind = "none" | "web" | "native";

export interface LinkedBike {
  id: string;
  name: string;
  kind: Exclude<LinkKind, "none">;
  hasHr?: boolean;
  hasBattery?: boolean;
}

type Listener = (sample: BikeSample) => void;

let link: LinkedBike | null = null;
let strap: LinkedBike | null = null;
let last: BikeSample = {};
let lastAt = 0;
let lastHrAt = 0;
const listeners = new Set<Listener>();
const disconnectListeners = new Set<() => void>();
let stopFn: (() => void) | null = null;
let strapStopFn: (() => void) | null = null;

export function getLinkedBike() {
  return link;
}

export function getLinkedStrap() {
  return strap;
}

export function getLastBikeSample() {
  return { sample: last, at: lastAt, hrAt: lastHrAt };
}

export function isBikeFresh(ms = 4000) {
  return lastAt > 0 && Date.now() - lastAt < ms;
}

export function isHrFresh(ms = 8000) {
  return lastHrAt > 0 && Date.now() - lastHrAt < ms;
}

export function onBikeSample(fn: Listener) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function pushBikeSample(partial: BikeSample) {
  last = { ...last, ...partial };
  lastAt = Date.now();
  if (partial.heartRate != null && partial.heartRate >= 0 && partial.heartRate <= 240) {
    lastHrAt = Date.now();
    if (link && !link.hasHr) link = { ...link, hasHr: true };
  }
  listeners.forEach((fn) => fn(last));
}

export function onBikeDisconnect(fn: () => void) {
  disconnectListeners.add(fn);
  return () => disconnectListeners.delete(fn);
}

export function setLinkedBike(next: LinkedBike | null, stop?: () => void) {
  stopFn?.();
  stopFn = stop ?? null;
  const had = !!link;
  link = next;
  if (!next) {
    last = strap ? { heartRate: last.heartRate } : {};
    lastAt = strap ? lastAt : 0;
    lastHrAt = strap ? lastHrAt : 0;
    if (had) disconnectListeners.forEach((fn) => fn());
  }
}

export function setLinkedStrap(next: LinkedBike | null, stop?: () => void) {
  strapStopFn?.();
  strapStopFn = stop ?? null;
  strap = next;
  if (!next && last.heartRate != null && !link?.hasHr) {
    const { heartRate: _hr, ...rest } = last;
    last = rest;
    lastHrAt = 0;
  }
}

export function disconnectBike() {
  setLinkedBike(null);
}

export function disconnectStrap() {
  setLinkedStrap(null);
}
