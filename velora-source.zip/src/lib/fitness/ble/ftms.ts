export interface BikeSample {
  power?: number;
  cadence?: number;
  speed?: number;
  distanceM?: number;
  heartRate?: number;
  calories?: number;
  resistance?: number;
  battery?: number;
}

function u16(v: DataView, o: number) {
  return v.getUint16(o, true);
}
function s16(v: DataView, o: number) {
  return v.getInt16(o, true);
}
function u24(v: DataView, o: number) {
  return v.getUint8(o) | (v.getUint8(o + 1) << 8) | (v.getUint8(o + 2) << 16);
}

function plausibleHr(n: number) {
  // 0 bpm is valid: nRF on FS-583ADC shows 0 at rest, ~95 while pedaling.
  // Sensor Contact is not supported on this bike, so 0 means idle, not "disconnected".
  return Number.isFinite(n) && n >= 0 && n <= 240;
}

/** FTMS Indoor Bike Data (0x2AD2) */
export function parseIndoorBikeData(data: DataView): BikeSample {
  if (data.byteLength < 2) return {};
  const flags = u16(data, 0);
  let o = 2;
  const out: BikeSample = {};
  // Bit 0 more-data is inverted: 0 means instantaneous speed present
  if ((flags & 0x0001) === 0 && o + 2 <= data.byteLength) {
    out.speed = u16(data, o) / 100;
    o += 2;
  }
  if (flags & 0x0002 && o + 2 <= data.byteLength) o += 2; // avg speed
  if (flags & 0x0004 && o + 2 <= data.byteLength) {
    out.cadence = u16(data, o) / 2;
    o += 2;
  }
  if (flags & 0x0008 && o + 2 <= data.byteLength) o += 2; // avg cadence
  if (flags & 0x0010 && o + 3 <= data.byteLength) {
    out.distanceM = u24(data, o);
    o += 3;
  }
  if (flags & 0x0020 && o + 2 <= data.byteLength) {
    out.resistance = s16(data, o);
    o += 2;
  }
  if (flags & 0x0040 && o + 2 <= data.byteLength) {
    out.power = s16(data, o);
    o += 2;
  }
  if (flags & 0x0080 && o + 2 <= data.byteLength) o += 2; // avg power
  if (flags & 0x0100 && o + 5 <= data.byteLength) {
    out.calories = u16(data, o);
    o += 5;
  }
  if (flags & 0x0200 && o + 1 <= data.byteLength) {
    const hr = data.getUint8(o);
    if (plausibleHr(hr)) out.heartRate = hr;
  }
  return out;
}

/**
 * Heart Rate Measurement (0x2A37) on service 0x180D.
 * FS-583ADC: Properties NOTIFY + READ. nRF: "0 bpm" at rest, "95 bpm" while cycling,
 * "Sensor Contact Not Supported". Flags bit 0 = 0 → uint8 BPM at offset 1.
 */
export function parseHeartRate(data: DataView): BikeSample {
  if (data.byteLength < 1) return {};
  let hr: number;
  if (data.byteLength === 1) {
    hr = data.getUint8(0);
  } else {
    const flags = data.getUint8(0);
    if (flags & 0x01) {
      hr = data.byteLength >= 3 ? u16(data, 1) : data.getUint8(1);
    } else {
      hr = data.getUint8(1);
    }
  }
  if (!plausibleHr(hr)) return {};
  return { heartRate: hr };
}

/** Cycling Power Measurement (0x2A63) */
export function parseCyclingPower(data: DataView): BikeSample {
  if (data.byteLength < 4) return {};
  return { power: s16(data, 2) };
}

export function parseBattery(data: DataView): BikeSample {
  if (data.byteLength < 1) return {};
  return { battery: data.getUint8(0) };
}

export function bufferToView(value: DataView | ArrayBuffer | Uint8Array | string): DataView {
  if (value instanceof DataView) return value;
  if (typeof value === "string") {
    const hex = value.replace(/^0x/i, "").replace(/[\s:-]/g, "");
    const bytes = new Uint8Array(hex.length / 2);
    for (let i = 0; i < bytes.length; i++) bytes[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
    return new DataView(bytes.buffer);
  }
  if (value instanceof Uint8Array) {
    return new DataView(value.buffer, value.byteOffset, value.byteLength);
  }
  return new DataView(value);
}
