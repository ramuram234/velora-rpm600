import {
  BATTERY_LEVEL,
  BATTERY_SERVICE,
  CPS,
  CPS_MEASUREMENT,
  DIS,
  FIRMWARE_REV,
  FTMS,
  HARDWARE_REV,
  HR_MEASUREMENT,
  HR_SERVICE,
  INDOOR_BIKE_DATA,
  MANUFACTURER_NAME,
  MODEL_NUMBER,
  OPTIONAL_SERVICES,
} from "./uuids";
import {
  bufferToView,
  parseBattery,
  parseCyclingPower,
  parseHeartRate,
  parseIndoorBikeData,
} from "./ftms";
import { pushBikeSample, setLinkedBike } from "./runtime";

export function canUseWebBluetooth() {
  return typeof navigator !== "undefined" && !!navigator.bluetooth;
}

async function notify(
  server: BluetoothRemoteGATTServer,
  serviceId: string,
  charId: string,
  parse: (v: DataView) => ReturnType<typeof parseIndoorBikeData>,
): Promise<{ stop: () => void; ok: boolean }> {
  try {
    const service = await server.getPrimaryService(serviceId);
    const char = await service.getCharacteristic(charId);
    await char.startNotifications();
    const on = (ev: Event) => {
      const value = (ev.target as BluetoothRemoteGATTCharacteristic).value;
      if (value) pushBikeSample(parse(value));
    };
    char.addEventListener("characteristicvaluechanged", on);
    try {
      const initial = await char.readValue();
      pushBikeSample(parse(bufferToView(initial)));
    } catch {
      /* Heart Rate Measurement on the RPM600 is notify-only */
    }
    return {
      ok: true,
      stop: () => {
        char.removeEventListener("characteristicvaluechanged", on);
        void char.stopNotifications().catch(() => undefined);
      },
    };
  } catch {
    return { ok: false, stop: () => undefined };
  }
}

async function readString(server: BluetoothRemoteGATTServer, uuid: string) {
  try {
    const service = await server.getPrimaryService(DIS);
    const char = await service.getCharacteristic(uuid);
    const v = await char.readValue();
    return new TextDecoder().decode(v).replace(/\0/g, "").trim();
  } catch {
    return "";
  }
}

export async function connectWebBluetooth(acceptAll = false) {
  if (!canUseWebBluetooth()) {
    throw new Error("This browser cannot talk to Bluetooth. Use Chrome on Android or the Velora APK.");
  }
  const device = await navigator.bluetooth.requestDevice(
    acceptAll
      ? { acceptAllDevices: true, optionalServices: OPTIONAL_SERVICES }
      : {
          filters: [
            { namePrefix: "FS-" },
            { namePrefix: "JJ" },
            { namePrefix: "JIANJIA" },
            { namePrefix: "RPM" },
            { namePrefix: "ICG" },
            { namePrefix: "SPIN" },
            { services: [FTMS] },
            { services: [CPS] },
            { services: [HR_SERVICE] },
          ],
          optionalServices: OPTIONAL_SERVICES,
        },
  );
  const server = await device.gatt?.connect();
  if (!server) throw new Error("GATT connect failed");

  const ftms = await notify(server, FTMS, INDOOR_BIKE_DATA, parseIndoorBikeData);
  const hr = await notify(server, HR_SERVICE, HR_MEASUREMENT, parseHeartRate);
  const bat = await notify(server, BATTERY_SERVICE, BATTERY_LEVEL, parseBattery);
  const cps = await notify(server, CPS, CPS_MEASUREMENT, parseCyclingPower);
  const stops = [ftms.stop, hr.stop, bat.stop, cps.stop];

  const manufacturer = await readString(server, MANUFACTURER_NAME);
  const model = await readString(server, MODEL_NUMBER);
  const hardware = await readString(server, HARDWARE_REV);
  const software = await readString(server, FIRMWARE_REV);

  const onLost = () => {
    setLinkedBike(null);
  };
  device.addEventListener("gattserverdisconnected", onLost);

  const stop = () => {
    device.removeEventListener("gattserverdisconnected", onLost);
    stops.forEach((s) => s());
    device.gatt?.disconnect();
  };

  setLinkedBike(
    {
      id: device.id,
      name: device.name || "Indoor bike",
      kind: "web",
      hasHr: hr.ok,
      hasBattery: bat.ok,
    },
    stop,
  );

  return {
    id: device.id,
    name: device.name || "Indoor bike",
    manufacturer: manufacturer || "Unknown",
    model: model || "",
    hardware: hardware || "",
    software: software || "",
    hasHr: hr.ok,
    hasBattery: bat.ok,
    hasFtms: ftms.ok,
  };
}
