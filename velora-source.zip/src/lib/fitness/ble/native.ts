import {
  BATTERY_LEVEL,
  BATTERY_SERVICE,
  CPS,
  CPS_MEASUREMENT,
  FTMS,
  HR_MEASUREMENT,
  HR_SERVICE,
  INDOOR_BIKE_DATA,
} from "./uuids";
import { bufferToView, parseBattery, parseCyclingPower, parseHeartRate, parseIndoorBikeData } from "./ftms";
import { pushBikeSample, setLinkedBike, setLinkedStrap } from "./runtime";

export function isNativeApp() {
  if (typeof window === "undefined") return false;
  const cap = (window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor;
  return !!cap?.isNativePlatform?.();
}

type BleChar = { uuid: string; properties?: { notify?: boolean; read?: boolean } };
type BleService = { uuid: string; characteristics?: BleChar[] };

type BleClientApi = {
  initialize: (opts?: { androidNeverForLocation?: boolean }) => Promise<void>;
  requestLEScan: (
    opts: { services?: string[]; optionalServices?: string[]; allowDuplicates?: boolean },
    cb: (result: { device: { deviceId: string; name?: string } }) => void,
  ) => Promise<void>;
  stopLEScan: () => Promise<void>;
  connect: (deviceId: string, onDisconnect?: (id: string) => void) => Promise<void>;
  disconnect: (deviceId: string) => Promise<void>;
  getServices: (deviceId: string) => Promise<BleService[]>;
  startNotifications: (
    deviceId: string,
    service: string,
    characteristic: string,
    cb: (value: DataView) => void,
  ) => Promise<void>;
  stopNotifications: (deviceId: string, service: string, characteristic: string) => Promise<void>;
  read: (deviceId: string, service: string, characteristic: string) => Promise<DataView>;
  requestConnectionPriority?: (deviceId: string, priority: number) => Promise<void>;
};

async function loadBle(): Promise<BleClientApi> {
  const mod = await import("@capacitor-community/bluetooth-le");
  return mod.BleClient as unknown as BleClientApi;
}

function norm(u: string) {
  return u.toLowerCase();
}

function findChar(services: BleService[], charUuid: string, preferService?: string) {
  const want = norm(charUuid);
  const prefer = preferService ? norm(preferService) : "";
  let fallback: { service: string; char: string } | null = null;
  for (const s of services) {
    for (const c of s.characteristics ?? []) {
      if (norm(c.uuid) !== want) continue;
      const hit = { service: s.uuid, char: c.uuid };
      if (!prefer || norm(s.uuid) === prefer) return hit;
      fallback = hit;
    }
  }
  return fallback;
}

function hasService(services: BleService[], uuid: string) {
  const want = norm(uuid);
  return services.some((s) => norm(s.uuid) === want);
}

export async function scanNativeBikes(ms = 8000) {
  const BleClient = await loadBle();
  await BleClient.initialize({ androidNeverForLocation: true });
  const found = new Map<string, { id: string; name: string }>();
  await BleClient.requestLEScan({ allowDuplicates: false }, (result) => {
    const id = result.device.deviceId;
    const name = result.device.name || "BLE device";
    found.set(id, { id, name });
  });
  await new Promise((r) => setTimeout(r, ms));
  await BleClient.stopLEScan().catch(() => undefined);
  return [...found.values()].sort((a, b) => a.name.localeCompare(b.name));
}

async function listen(
  BleClient: BleClientApi,
  deviceId: string,
  service: string,
  char: string,
  parse: (v: DataView) => ReturnType<typeof parseIndoorBikeData>,
) {
  try {
    await BleClient.startNotifications(deviceId, service, char, (value) => {
      pushBikeSample(parse(bufferToView(value)));
    });
    return true;
  } catch {
    return false;
  }
}

async function listenWithRetry(
  BleClient: BleClientApi,
  deviceId: string,
  service: string,
  char: string,
  parse: (v: DataView) => ReturnType<typeof parseIndoorBikeData>,
) {
  if (await listen(BleClient, deviceId, service, char, parse)) return true;
  await new Promise((r) => setTimeout(r, 400));
  return listen(BleClient, deviceId, service, char, parse);
}

export async function connectNativeBike(deviceId: string, name: string) {
  const BleClient = await loadBle();
  await BleClient.initialize({ androidNeverForLocation: true });
  await BleClient.connect(deviceId, () => setLinkedBike(null));
  try {
    await BleClient.requestConnectionPriority?.(deviceId, 1);
  } catch {
    /* optional */
  }

  let services: BleService[] = [];
  try {
    services = await BleClient.getServices(deviceId);
  } catch {
    services = [];
  }

  const ftmsChar = findChar(services, INDOOR_BIKE_DATA, FTMS);
  const hrChar = findChar(services, HR_MEASUREMENT, HR_SERVICE);
  const batChar = findChar(services, BATTERY_LEVEL, BATTERY_SERVICE);
  const cpsChar = findChar(services, CPS_MEASUREMENT, CPS);

  const ftmsOk = await listenWithRetry(
    BleClient,
    deviceId,
    ftmsChar?.service ?? FTMS,
    ftmsChar?.char ?? INDOOR_BIKE_DATA,
    parseIndoorBikeData,
  );

  const hrOk = await listenWithRetry(
    BleClient,
    deviceId,
    hrChar?.service ?? HR_SERVICE,
    hrChar?.char ?? HR_MEASUREMENT,
    parseHeartRate,
  );

  const batOk = await listenWithRetry(
    BleClient,
    deviceId,
    batChar?.service ?? BATTERY_SERVICE,
    batChar?.char ?? BATTERY_LEVEL,
    parseBattery,
  );

  if (!ftmsOk) {
    await listenWithRetry(
      BleClient,
      deviceId,
      cpsChar?.service ?? CPS,
      cpsChar?.char ?? CPS_MEASUREMENT,
      parseCyclingPower,
    );
  }

  try {
    const bat = await BleClient.read(deviceId, batChar?.service ?? BATTERY_SERVICE, batChar?.char ?? BATTERY_LEVEL);
    pushBikeSample(parseBattery(bufferToView(bat)));
  } catch {
    /* notify-only on some firmwares */
  }

  // 0x2A37 is READ + NOTIFY on FS-583ADC. Read the rest value (often 0 bpm) immediately.
  try {
    const hr = await BleClient.read(deviceId, hrChar?.service ?? HR_SERVICE, hrChar?.char ?? HR_MEASUREMENT);
    pushBikeSample(parseHeartRate(bufferToView(hr)));
  } catch {
    /* still subscribed via notify */
  }

  const hasHr = hrOk || !!hrChar || hasService(services, HR_SERVICE);
  const hasBattery = batOk || !!batChar || hasService(services, BATTERY_SERVICE);

  const stop = () => {
    void BleClient.stopNotifications(deviceId, ftmsChar?.service ?? FTMS, ftmsChar?.char ?? INDOOR_BIKE_DATA).catch(
      () => undefined,
    );
    void BleClient.stopNotifications(deviceId, hrChar?.service ?? HR_SERVICE, hrChar?.char ?? HR_MEASUREMENT).catch(
      () => undefined,
    );
    void BleClient.stopNotifications(
      deviceId,
      batChar?.service ?? BATTERY_SERVICE,
      batChar?.char ?? BATTERY_LEVEL,
    ).catch(() => undefined);
    void BleClient.disconnect(deviceId).catch(() => undefined);
  };

  setLinkedBike({ id: deviceId, name, kind: "native", hasHr, hasBattery }, stop);
  return { id: deviceId, name, hasHr, hasBattery };
}

export async function connectNativeHr(deviceId: string, name: string) {
  const BleClient = await loadBle();
  await BleClient.initialize({ androidNeverForLocation: true });
  await BleClient.connect(deviceId, () => setLinkedStrap(null));
  let services: BleService[] = [];
  try {
    services = await BleClient.getServices(deviceId);
  } catch {
    services = [];
  }
  const hrChar = findChar(services, HR_MEASUREMENT, HR_SERVICE);
  const ok = await listenWithRetry(
    BleClient,
    deviceId,
    hrChar?.service ?? HR_SERVICE,
    hrChar?.char ?? HR_MEASUREMENT,
    parseHeartRate,
  );
  if (!ok) {
    await BleClient.disconnect(deviceId).catch(() => undefined);
    throw new Error("That device has no Heart Rate Measurement characteristic (0x2A37).");
  }
  const stop = () => {
    void BleClient.stopNotifications(deviceId, hrChar?.service ?? HR_SERVICE, hrChar?.char ?? HR_MEASUREMENT).catch(
      () => undefined,
    );
    void BleClient.disconnect(deviceId).catch(() => undefined);
  };
  setLinkedStrap({ id: deviceId, name, kind: "native", hasHr: true }, stop);
  return { id: deviceId, name, hasHr: true };
}
