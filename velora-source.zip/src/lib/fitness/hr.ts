import type { TelemetrySample, UserProfile, Workout } from "./types";
import { hrZones, zoneForHr } from "./zones";

const HR_MIN = 30;

export function hasHr(sample: { heartRate?: number }) {
  return (sample.heartRate ?? 0) >= HR_MIN;
}

export function hrSamples(series: TelemetrySample[]) {
  return series.filter(hasHr);
}

function mean(xs: number[]) {
  if (!xs.length) return 0;
  return xs.reduce((a, b) => a + b, 0) / xs.length;
}

export interface HrRideAnalysis {
  captured: boolean;
  sampleCount: number;
  coveragePct: number;
  avg: number;
  max: number;
  min: number;
  timeInZone: [number, number, number, number, number];
  timeInZonePct: [number, number, number, number, number];
  trimp: number;
  driftPct: number | null;
  decouplingPct: number | null;
  note: string;
}

export function analyzeHrRide(series: TelemetrySample[], profile: UserProfile): HrRideAnalysis {
  const hz = hrZones(profile);
  const withHr = hrSamples(series);
  const empty: HrRideAnalysis = {
    captured: false,
    sampleCount: 0,
    coveragePct: 0,
    avg: 0,
    max: 0,
    min: 0,
    timeInZone: [0, 0, 0, 0, 0],
    timeInZonePct: [0, 0, 0, 0, 0],
    trimp: 0,
    driftPct: null,
    decouplingPct: null,
    note: "No heart-rate samples yet. The RPM600 has Heart Rate Measurement (0x180D / 0x2A37) — connecting the bike enables it, same as battery. Hold the pulse grips. A chest strap is optional.",
  };
  if (withHr.length < 5) return empty;

  const hrs = withHr.map((s) => s.heartRate);
  const dt =
    series.length > 1
      ? Math.max(1, (series[series.length - 1].t - series[0].t) / (series.length - 1))
      : 5;
  const zones: [number, number, number, number, number] = [0, 0, 0, 0, 0];
  let trimp = 0;
  const canTrimp = profile.maxHr >= 80 && profile.restingHr >= 30;
  const hrr = Math.max(40, profile.maxHr - profile.restingHr);
  for (const s of withHr) {
    const zid = zoneForHr(s.heartRate, hz);
    if (zid >= 1) zones[zid - 1] += dt;
    if (canTrimp) {
      const frac = Math.max(0, Math.min(1, (s.heartRate - profile.restingHr) / hrr));
      trimp += (dt / 60) * frac * 0.64 * Math.exp(1.92 * frac);
    }
  }
  const totalZ = zones.reduce((a, b) => a + b, 0);
  const pct = (totalZ
    ? zones.map((z) => Math.round((z / totalZ) * 1000) / 10)
    : [0, 0, 0, 0, 0]) as HrRideAnalysis["timeInZonePct"];

  const third = Math.max(3, Math.floor(withHr.length / 3));
  const first = withHr.slice(0, third);
  const last = withHr.slice(-third);
  const p1 = mean(first.map((s) => s.power).filter((pw) => pw > 20));
  const p2 = mean(last.map((s) => s.power).filter((pw) => pw > 20));
  const h1 = mean(first.map((s) => s.heartRate));
  const h2 = mean(last.map((s) => s.heartRate));
  const driftPct = h1 > 0 ? Math.round(((h2 - h1) / h1) * 1000) / 10 : null;
  let decouplingPct: number | null = null;
  if (p1 > 20 && p2 > 20 && h1 > 0) {
    const r1 = h1 / p1;
    const r2 = h2 / p2;
    decouplingPct = Math.round(((r2 - r1) / r1) * 1000) / 10;
  }

  let note = `${withHr.length} HR samples · ${Math.round((withHr.length / Math.max(1, series.length)) * 100)}% of the ride.`;
  if (!canTrimp) {
    note += " TRIMP needs resting HR and max HR in Profile — not computed.";
  }
  if (profile.maxHr < 80) {
    note += " Zone time not classified until max HR is set.";
  }
  if (decouplingPct != null && decouplingPct > 5) {
    note += ` Aerobic decoupling ${decouplingPct > 0 ? "+" : ""}${decouplingPct}% — heart rate rose relative to watts in the second half.`;
  } else if (decouplingPct != null && decouplingPct < -3) {
    note += " Heart rate settled while power held — a good aerobic sign.";
  } else if (driftPct != null && Math.abs(driftPct) <= 3) {
    note += " Cardiac drift is small; the effort was controlled.";
  }

  return {
    captured: true,
    sampleCount: withHr.length,
    coveragePct: Math.round((withHr.length / Math.max(1, series.length)) * 100),
    avg: Math.round(mean(hrs)),
    max: Math.round(Math.max(...hrs)),
    min: Math.round(Math.min(...hrs)),
    timeInZone: zones,
    timeInZonePct: pct,
    trimp: Math.round(trimp),
    driftPct,
    decouplingPct,
    note,
  };
}

export function analyzeHrBlock(workouts: Workout[], profile: UserProfile) {
  const rides = workouts.filter((w) => w.summary.hrCaptured || w.series.some((s) => s.heartRate >= 30));
  const empty = {
    rides: 0,
    avg: 0,
    max: 0,
    timeInZone: [0, 0, 0, 0, 0] as [number, number, number, number, number],
    timeInZonePct: [0, 0, 0, 0, 0] as [number, number, number, number, number],
    trimp: 0,
    note: "No rides with captured heart rate yet.",
  };
  if (!rides.length) return empty;
  const zones: [number, number, number, number, number] = [0, 0, 0, 0, 0];
  let trimp = 0;
  let max = 0;
  let avgAcc = 0;
  let counted = 0;
  for (const w of rides) {
    const a = analyzeHrRide(w.series, profile);
    if (!a.captured) continue;
    counted += 1;
    avgAcc += a.avg;
    max = Math.max(max, a.max);
    trimp += a.trimp;
    for (let i = 0; i < 5; i++) zones[i] += a.timeInZone[i];
  }
  if (!counted) return empty;
  const total = zones.reduce((a, b) => a + b, 0);
  return {
    rides: counted,
    avg: Math.round(avgAcc / counted),
    max,
    timeInZone: zones,
    timeInZonePct: (total
      ? zones.map((z) => Math.round((z / total) * 1000) / 10)
      : [0, 0, 0, 0, 0]) as [number, number, number, number, number],
    trimp: Math.round(trimp),
    note: `${counted} of ${workouts.length} rides include heart rate.`,
  };
}
