import type { Sex } from "./types";

export function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

export function nid() {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }
  return `id_${Math.random().toString(36).slice(2)}_${Date.now().toString(36)}`;
}

export function pad(n: number, w = 2) {
  return String(Math.floor(n)).padStart(w, "0");
}

export function formatTime(totalSec: number) {
  const s = Math.max(0, Math.floor(totalSec));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h > 0) return `${h}:${pad(m)}:${pad(sec)}`;
  return `${pad(m)}:${pad(sec)}`;
}

export function formatClock(iso: string) {
  const d = new Date(iso);
  return d.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" });
}

export function formatDate(iso: string, opts?: Intl.DateTimeFormatOptions) {
  return new Date(iso).toLocaleDateString(
    undefined,
    opts ?? { weekday: "short", month: "short", day: "numeric" },
  );
}

export function formatDateLong(iso: string) {
  return new Date(iso).toLocaleDateString(undefined, {
    weekday: "long",
    month: "long",
    day: "numeric",
  });
}

export function todayKey(d = new Date()) {
  const y = d.getFullYear();
  const m = pad(d.getMonth() + 1);
  const day = pad(d.getDate());
  return `${y}-${m}-${day}`;
}

export function daysAgoKey(days: number) {
  const d = new Date();
  d.setHours(12, 0, 0, 0);
  d.setDate(d.getDate() - days);
  return todayKey(d);
}

export function isoDaysAgo(days: number, hour = 7, minute = 12) {
  const d = new Date();
  d.setDate(d.getDate() - days);
  d.setHours(hour, minute, 0, 0);
  return d.toISOString();
}

export function greeting(now = new Date()) {
  const h = now.getHours();
  if (h < 5) return "Late night";
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  if (h < 21) return "Good evening";
  return "Good night";
}

export function formatKg(n: number, digits = 1) {
  return `${n.toFixed(digits)} kg`;
}

export function formatKm(n: number, digits = 1) {
  return `${n.toFixed(digits)} km`;
}

export function formatWatts(n: number) {
  return `${Math.round(n)} W`;
}

export function bmi(heightCm: number, weightKg: number) {
  const m = heightCm / 100;
  if (m <= 0) return 0;
  return weightKg / (m * m);
}

export function bmiLabel(value: number) {
  if (value <= 0) return "—";
  if (value < 18.5) return "Underweight";
  if (value < 25) return "Healthy range";
  if (value < 30) return "Overweight";
  return "Obese range";
}

export function ageFromDob(dob: string) {
  if (!dob) return 0;
  const d = new Date(dob);
  if (Number.isNaN(d.getTime())) return 0;
  const now = new Date();
  let age = now.getFullYear() - d.getFullYear();
  const m = now.getMonth() - d.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < d.getDate())) age -= 1;
  return age;
}

export function estimateMaxHr(age: number, sex: Sex) {
  if (age <= 0) return 0;
  const base = 208 - 0.7 * age;
  return Math.round(sex === "female" ? base + 2 : base);
}

export function ftpFromLevel(
  level: "beginner" | "intermediate" | "advanced",
  weightKg: number,
) {
  if (weightKg < 30) return 0;
  const wkg = level === "beginner" ? 1.8 : level === "advanced" ? 3.3 : 2.45;
  return Math.round(wkg * weightKg);
}

export function percent(n: number, digits = 0) {
  return `${n.toFixed(digits)}%`;
}

export function signedPct(n: number) {
  const v = n * 100;
  const abs = Math.abs(v).toFixed(1);
  return `${v >= 0 ? "+" : "−"}${abs}%`;
}

export function compact(n: number) {
  if (n >= 1000) return `${(n / 1000).toFixed(n >= 10000 ? 0 : 1)}k`;
  return String(Math.round(n));
}
