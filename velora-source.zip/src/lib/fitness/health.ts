import { Capacitor, registerPlugin } from "@capacitor/core";
import type { DailyActivity, UserProfile, Workout } from "./types";

interface VeloraHealthPlugin {
  getStatus(): Promise<{
    available: boolean;
    sdk: string;
    reason: string;
  }>;
  requestAccess(): Promise<{ granted: boolean; detail: string }>;
  sync(payload: {
    workouts: Array<{
      id: string;
      name: string;
      startMs: number;
      endMs: number;
      calories: number;
      distanceM: number;
      avgHr: number;
      maxHr: number;
      hr: Array<{ tMs: number; bpm: number }>;
    }>;
    steps: Array<{ date: string; count: number }>;
    weightKg: number;
  }): Promise<{
    ok: boolean;
    written: number;
    stepsRead: number;
    stepsDays?: Array<{ date: string; count: number }>;
    detail: string;
  }>;
}

const VeloraHealth = registerPlugin<VeloraHealthPlugin>("VeloraHealth", {
  web: () => ({
    getStatus: async () => ({
      available: false,
      sdk: "web",
      reason: "Health Connect only exists on Android. No Google account is involved.",
    }),
    requestAccess: async () => ({
      granted: false,
      detail: "Install the Velora APK. Health Connect is a phone database, not Gmail.",
    }),
    sync: async () => ({
      ok: false,
      written: 0,
      stepsRead: 0,
      stepsDays: [],
      detail: "Web preview cannot reach Health Connect.",
    }),
  }),
});

export function healthIsNative() {
  return Capacitor.isNativePlatform();
}

export async function healthStatus() {
  try {
    return await VeloraHealth.getStatus();
  } catch {
    return {
      available: false,
      sdk: "missing",
      reason: "Health Connect plugin is not on this build.",
    };
  }
}

export async function healthRequest() {
  try {
    return await VeloraHealth.requestAccess();
  } catch (e) {
    return {
      granted: false,
      detail: e instanceof Error ? e.message : "Could not open Health Connect",
    };
  }
}

export async function healthPush(opts: {
  workouts: Workout[];
  activity: DailyActivity[];
  profile: UserProfile;
}) {
  const recent = [...opts.workouts]
    .sort((a, b) => +new Date(b.startTime) - +new Date(a.startTime))
    .slice(0, 12);
  const payload = {
    workouts: recent.map((w) => ({
      id: w.id,
      name: w.name,
      startMs: +new Date(w.startTime),
      endMs: +new Date(w.endTime),
      calories: w.summary.calories,
      distanceM: Math.round(w.summary.distanceKm * 1000),
      avgHr: w.summary.avgHeartRate,
      maxHr: w.summary.maxHeartRate,
      hr: w.summary.hrCaptured
        ? w.series
            .filter((s) => s.heartRate >= 30)
            .filter((_, i) => i % 8 === 0)
            .map((s) => ({ tMs: +new Date(w.startTime) + s.t * 1000, bpm: s.heartRate }))
        : [],
    })),
    steps: opts.activity.slice(-7).map((d) => ({ date: d.date, count: d.steps })),
    weightKg: opts.profile.weightKg,
  };
  try {
    return await VeloraHealth.sync(payload);
  } catch (e) {
    return {
      ok: false,
      written: 0,
      stepsRead: 0,
      stepsDays: [],
      detail: e instanceof Error ? e.message : "Health sync failed",
    };
  }
}
