import type { UserProfile } from "./types";

export interface HrZone {
  id: 1 | 2 | 3 | 4 | 5;
  name: string;
  lo: number;
  hi: number;
}

export interface PowerZone {
  id: 1 | 2 | 3 | 4 | 5 | 6 | 7;
  name: string;
  lo: number;
  hi: number;
}

export function hrZones(profile: UserProfile): HrZone[] {
  const max = profile.maxHr;
  if (max < 80) {
    return [
      { id: 1, name: "Recovery", lo: 0, hi: 0 },
      { id: 2, name: "Endurance", lo: 0, hi: 0 },
      { id: 3, name: "Tempo", lo: 0, hi: 0 },
      { id: 4, name: "Threshold", lo: 0, hi: 0 },
      { id: 5, name: "VO2", lo: 0, hi: 0 },
    ];
  }
  const bounds = [0.5, 0.6, 0.7, 0.8, 0.9, 1.0].map((p) => Math.round(max * p));
  return [
    { id: 1, name: "Recovery", lo: bounds[0], hi: bounds[1] - 1 },
    { id: 2, name: "Endurance", lo: bounds[1], hi: bounds[2] - 1 },
    { id: 3, name: "Tempo", lo: bounds[2], hi: bounds[3] - 1 },
    { id: 4, name: "Threshold", lo: bounds[3], hi: bounds[4] - 1 },
    { id: 5, name: "VO2", lo: bounds[4], hi: bounds[5] },
  ];
}

export function powerZones(ftp: number): PowerZone[] {
  if (ftp <= 0) {
    return [
      { id: 1, name: "Active recovery", lo: 0, hi: 0 },
      { id: 2, name: "Endurance", lo: 0, hi: 0 },
      { id: 3, name: "Tempo", lo: 0, hi: 0 },
      { id: 4, name: "Threshold", lo: 0, hi: 0 },
      { id: 5, name: "VO2 max", lo: 0, hi: 0 },
      { id: 6, name: "Anaerobic", lo: 0, hi: 0 },
      { id: 7, name: "Neuromuscular", lo: 0, hi: 0 },
    ];
  }
  const pct = (p: number) => Math.round(ftp * p);
  return [
    { id: 1, name: "Active recovery", lo: 0, hi: pct(0.55) },
    { id: 2, name: "Endurance", lo: pct(0.56), hi: pct(0.75) },
    { id: 3, name: "Tempo", lo: pct(0.76), hi: pct(0.9) },
    { id: 4, name: "Threshold", lo: pct(0.91), hi: pct(1.05) },
    { id: 5, name: "VO2 max", lo: pct(1.06), hi: pct(1.2) },
    { id: 6, name: "Anaerobic", lo: pct(1.21), hi: pct(1.5) },
    { id: 7, name: "Neuromuscular", lo: pct(1.51), hi: 2000 },
  ];
}

export function zonesReady(zones: { lo: number; hi: number }[]) {
  return zones.some((z) => z.hi > 0);
}

/** 0 = unzoned (no max HR). Never dumps samples into Z5 as a default. */
export function zoneForHr(hr: number, zones: HrZone[]) {
  if (!hr || !zonesReady(zones)) return 0;
  for (const z of zones) {
    if (hr >= z.lo && hr <= z.hi) return z.id;
  }
  return hr < zones[0].lo ? 1 : 5;
}

/** 0 = unzoned (no FTP). Never dumps watts into Z7 as a default. */
export function zoneForPower(watts: number, zones: PowerZone[]) {
  if (!zonesReady(zones)) return 0;
  for (const z of zones) {
    if (watts >= z.lo && watts <= z.hi) return z.id;
  }
  return watts < 0 ? 1 : 7;
}

export const HR_ZONE_COLORS = [
  "#6B7C72",
  "#7EC8C0",
  "#8FCB9B",
  "#D4B483",
  "#E07A6A",
] as const;

export const POWER_ZONE_COLORS = [
  "#6B7280",
  "#7EC8C0",
  "#8FCB9B",
  "#D4B483",
  "#E07A6A",
  "#C08497",
  "#A1A1AA",
] as const;
