import type { PersonalRecord, TelemetrySample, UserProfile, Workout, WorkoutPlan } from "./types";
import { hasHr } from "./hr";
import { powerCurve } from "./analytics";
import { LIBRARY, scalePlanToFtp } from "./workouts";

function mean(xs: number[]) {
  if (!xs.length) return 0;
  return xs.reduce((a, b) => a + b, 0) / xs.length;
}

function stdev(xs: number[]) {
  if (xs.length < 2) return 0;
  const m = mean(xs);
  return Math.sqrt(mean(xs.map((x) => (x - m) ** 2)));
}

export function seriesDt(series: TelemetrySample[]) {
  if (series.length < 2) return 1;
  return Math.max(1, (series[series.length - 1].t - series[0].t) / (series.length - 1));
}

export function seriesDuration(series: TelemetrySample[]) {
  if (series.length < 2) return series[0]?.t ?? 0;
  return Math.max(0, series[series.length - 1].t - series[0].t);
}

/** Mechanical work from instantaneous watts. Independent of FTMS calorie field. */
export function workKj(series: TelemetrySample[]) {
  if (!series.length) return 0;
  const dt = seriesDt(series);
  let j = 0;
  for (const s of series) j += Math.max(0, s.power) * dt;
  return j / 1000;
}

export interface RidePhysics {
  vi: number;
  workKj: number;
  kjPerHour: number;
  wPerKg: number;
  npPerKg: number;
  coastSec: number;
  coastPct: number;
  sweetCadenceSec: number;
  sweetCadencePct: number;
  cadenceAtPeak: number;
  cadenceNearFtp: number;
}

export function ridePhysics(workout: Workout, weightKg: number, ftp: number): RidePhysics {
  const series = workout.series;
  const s = workout.summary;
  const kj = workKj(series);
  const hours = Math.max(s.durationSec, 1) / 3600;
  const dt = seriesDt(series);
  let coast = 0;
  let sweet = 0;
  let peakCad = 0;
  let peakW = -1;
  const nearFtp: number[] = [];
  for (const p of series) {
    if (p.power < 15) coast += dt;
    if (p.cadence >= 80 && p.cadence <= 95 && p.power >= 15) sweet += dt;
    if (p.power > peakW) {
      peakW = p.power;
      peakCad = p.cadence;
    }
    if (ftp > 0 && p.power >= ftp * 0.95 && p.power <= ftp * 1.05 && p.cadence > 0) {
      nearFtp.push(p.cadence);
    }
  }
  const kg = weightKg >= 30 ? weightKg : 0;
  return {
    vi: s.avgPower > 0 ? Math.round((s.np / s.avgPower) * 100) / 100 : 0,
    workKj: Math.round(kj),
    kjPerHour: Math.round(kj / hours),
    wPerKg: kg ? Math.round((s.avgPower / kg) * 100) / 100 : 0,
    npPerKg: kg ? Math.round((s.np / kg) * 100) / 100 : 0,
    coastSec: Math.round(coast),
    coastPct: s.durationSec ? Math.round((coast / s.durationSec) * 1000) / 10 : 0,
    sweetCadenceSec: Math.round(sweet),
    sweetCadencePct: s.durationSec ? Math.round((sweet / s.durationSec) * 1000) / 10 : 0,
    cadenceAtPeak: Math.round(peakCad),
    cadenceNearFtp: nearFtp.length ? Math.round(mean(nearFtp)) : 0,
  };
}

export interface CadenceBin {
  label: string;
  lo: number;
  hi: number;
  sec: number;
}

export function cadenceHistogram(series: TelemetrySample[]): CadenceBin[] {
  const bins: CadenceBin[] = [
    { label: "<60", lo: 0, hi: 60, sec: 0 },
    { label: "60–70", lo: 60, hi: 70, sec: 0 },
    { label: "70–80", lo: 70, hi: 80, sec: 0 },
    { label: "80–90", lo: 80, hi: 90, sec: 0 },
    { label: "90–100", lo: 90, hi: 100, sec: 0 },
    { label: "100–110", lo: 100, hi: 110, sec: 0 },
    { label: "110+", lo: 110, hi: 300, sec: 0 },
  ];
  if (!series.length) return bins;
  const dt = seriesDt(series);
  for (const s of series) {
    if (s.power < 15 && s.cadence < 20) continue;
    const bin = bins.find((b) => s.cadence >= b.lo && s.cadence < b.hi) ?? bins[bins.length - 1];
    bin.sec += dt;
  }
  return bins;
}

export interface SplitBest {
  meters: number;
  sec: number;
  watts: number;
}

export function fastestSplit(series: TelemetrySample[], meters: number): SplitBest | null {
  if (series.length < 4) return null;
  let best = Infinity;
  let bestW = 0;
  let j = 0;
  for (let i = 0; i < series.length; i++) {
    const startD = series[i].distance;
    if (startD < 0) continue;
    while (j < series.length && series[j].distance - startD < meters) j++;
    if (j >= series.length) break;
    const sec = series[j].t - series[i].t;
    if (sec < 8) continue;
    if (sec < best) {
      best = sec;
      let sum = 0;
      let n = 0;
      for (let k = i; k <= j; k++) {
        sum += series[k].power;
        n++;
      }
      bestW = n ? sum / n : 0;
    }
  }
  if (!Number.isFinite(best) || best === Infinity) return null;
  return { meters, sec: Math.round(best), watts: Math.round(bestW) };
}

/** 1-minute HR drop only if a real cooldown exists in the file (power falls off). */
export function recoveryHr1min(series: TelemetrySample[]): number | null {
  const withHr = series.filter(hasHr);
  if (withHr.length < 8) return null;
  let lastWork = -1;
  for (let i = withHr.length - 1; i >= 0; i--) {
    if (withHr[i].power >= 40) {
      lastWork = i;
      break;
    }
  }
  if (lastWork < 0) return null;
  const t0 = withHr[lastWork].t;
  const later = withHr.filter((s) => s.t >= t0 + 50 && s.t <= t0 + 80);
  if (!later.length) return null;
  const drop = withHr[lastWork].heartRate - mean(later.map((s) => s.heartRate));
  if (drop < 0) return 0;
  return Math.round(drop);
}

export function efficiencyFactor(np: number, avgHr: number) {
  if (avgHr < 30 || np <= 0) return 0;
  return Math.round((np / avgHr) * 100) / 100;
}

/** HR while riding at 91–105% FTP. Estimate, not a lab LTHR. */
export function estimateLthr(workouts: Workout[], ftp: number) {
  if (ftp <= 0) return 0;
  const hrs: number[] = [];
  for (const w of workouts) {
    for (const s of w.series) {
      if (!hasHr(s)) continue;
      if (s.power >= ftp * 0.91 && s.power <= ftp * 1.05) hrs.push(s.heartRate);
    }
  }
  if (hrs.length < 36) return 0;
  return Math.round(mean(hrs));
}

export const MMP_WINDOWS = [
  { key: "1s", sec: 1 },
  { key: "5s", sec: 5 },
  { key: "10s", sec: 10 },
  { key: "30s", sec: 30 },
  { key: "1min", sec: 60 },
  { key: "3min", sec: 180 },
  { key: "5min", sec: 300 },
  { key: "12min", sec: 720 },
  { key: "20min", sec: 1200 },
] as const;

export function allTimeMmp(workouts: Workout[]) {
  const best = MMP_WINDOWS.map((w) => ({ key: w.key, sec: w.sec, watts: 0, rideId: "", date: "" }));
  for (const ride of workouts) {
    const dur = ride.summary.durationSec;
    const curve = powerCurve(ride.series);
    for (const c of curve) {
      if (dur + 1 < c.sec || c.watts <= 0) continue;
      const slot = best.find((b) => b.sec === c.sec);
      if (slot && c.watts > slot.watts) {
        slot.watts = c.watts;
        slot.rideId = ride.id;
        slot.date = ride.startTime;
      }
    }
  }
  return best;
}

export function eftpFromMmp(mmp: { sec: number; watts: number }[]) {
  const twenty = mmp.find((m) => m.sec === 1200);
  if (!twenty || twenty.watts < 40) return 0;
  return Math.round(twenty.watts * 0.95);
}

/**
 * 2-parameter CP model: P(t) = CP + W′/t
 * Uses 3/5/12/20 min MMP when those windows were actually ridden.
 */
export function criticalPower(mmp: { sec: number; watts: number }[]) {
  const usable = mmp.filter((m) => m.sec >= 180 && m.sec <= 1200 && m.watts >= 40);
  if (usable.length < 3) return { cp: 0, wPrime: 0 };
  const xs = usable.map((p) => 1 / p.sec);
  const ys = usable.map((p) => p.watts);
  const n = xs.length;
  const mx = mean(xs);
  const my = mean(ys);
  let num = 0;
  let den = 0;
  for (let i = 0; i < n; i++) {
    num += (xs[i] - mx) * (ys[i] - my);
    den += (xs[i] - mx) ** 2;
  }
  if (den === 0) return { cp: 0, wPrime: 0 };
  const wPrime = num / den;
  const cp = my - wPrime * mx;
  if (cp < 40 || cp > 600 || wPrime < 1000 || wPrime > 40000) return { cp: 0, wPrime: 0 };
  return { cp: Math.round(cp), wPrime: Math.round(wPrime) };
}

export function intensityDistribution(zonePower: number[]) {
  const total = zonePower.reduce((a, b) => a + b, 0);
  if (total < 30) {
    return {
      lowPct: 0,
      midPct: 0,
      highPct: 0,
      label: "—" as const,
    };
  }
  const low = (zonePower[0] ?? 0) + (zonePower[1] ?? 0);
  const mid = zonePower[2] ?? 0;
  const high = zonePower.slice(3).reduce((a, b) => a + b, 0);
  const lowPct = Math.round((low / total) * 1000) / 10;
  const midPct = Math.round((mid / total) * 1000) / 10;
  const highPct = Math.round((high / total) * 1000) / 10;
  let label: "polarized" | "pyramidal" | "threshold" | "sweet-spot" = "pyramidal";
  if (lowPct >= 80 && highPct >= 10) label = "polarized";
  else if (highPct >= 25 && midPct < 20) label = "threshold";
  else if (midPct >= 30) label = "sweet-spot";
  return { lowPct, midPct, highPct, label };
}

export function blockZonePower(workouts: Workout[]) {
  const z = [0, 0, 0, 0, 0, 0, 0];
  for (const w of workouts) {
    w.summary.zonePower.forEach((s, i) => {
      z[i] += s;
    });
  }
  return z;
}

export interface ComplianceRow {
  label: string;
  durationSec: number;
  avgPower: number;
  targetMin?: number;
  targetMax?: number;
  inRangePct: number | null;
}

export function findPlan(workout: Workout, custom: WorkoutPlan[]): WorkoutPlan | undefined {
  const all = [...LIBRARY, ...custom];
  return all.find((p) => p.id === workout.planId) ?? all.find((p) => p.name === workout.name);
}

export function intervalCompliance(
  workout: Workout,
  plan: WorkoutPlan | undefined,
  ftp: number,
): { rows: ComplianceRow[]; overallPct: number | null } | null {
  if (!plan || plan.kind === "free" || !plan.intervals.length) return null;
  const scaled = scalePlanToFtp(plan, ftp);
  const series = workout.series;
  let t = 0;
  const rows: ComplianceRow[] = [];
  const pcts: number[] = [];
  for (const iv of scaled.intervals) {
    const samples = series.filter((s) => s.t >= t && s.t < t + iv.durationSec);
    t += iv.durationSec;
    const avgPower = samples.length ? Math.round(mean(samples.map((s) => s.power))) : 0;
    const target = iv.targetPower;
    let inRangePct: number | null = null;
    if (target && samples.length) {
      const hit = samples.filter((s) => s.power >= target.min && s.power <= target.max).length;
      inRangePct = Math.round((hit / samples.length) * 1000) / 10;
      pcts.push(inRangePct);
    }
    rows.push({
      label: iv.label || iv.type,
      durationSec: iv.durationSec,
      avgPower,
      targetMin: target?.min,
      targetMax: target?.max,
      inRangePct,
    });
  }
  return {
    rows,
    overallPct: pcts.length ? Math.round(mean(pcts) * 10) / 10 : null,
  };
}

export function fosterMonotony(dailyTss: number[]) {
  if (dailyTss.length < 4) return { monotony: 0, strain: 0 };
  const m = mean(dailyTss);
  const sd = stdev(dailyTss);
  if (m <= 0) return { monotony: 0, strain: 0 };
  const monotony = sd > 0 ? m / sd : 0;
  const strain = monotony * dailyTss.reduce((a, b) => a + b, 0);
  return {
    monotony: Math.round(monotony * 10) / 10,
    strain: Math.round(strain),
  };
}

export function rampRate(ctlNow: number, ctlWeekAgo: number) {
  return Math.round((ctlNow - ctlWeekAgo) * 10) / 10;
}

export function weeklyTss(workouts: Workout[], weeks = 4) {
  const now = Date.now();
  const out: { label: string; tss: number; rides: number; hours: number; kj: number }[] = [];
  for (let w = weeks - 1; w >= 0; w--) {
    const start = now - (w + 1) * 7 * 86400000;
    const end = now - w * 7 * 86400000;
    const set = workouts.filter((x) => {
      const t = +new Date(x.startTime);
      return t >= start && t < end;
    });
    out.push({
      label: `W${weeks - w}`,
      tss: Math.round(set.reduce((a, x) => a + x.summary.tss, 0)),
      rides: set.length,
      hours: Math.round((set.reduce((a, x) => a + x.summary.durationSec, 0) / 3600) * 10) / 10,
      kj: Math.round(set.reduce((a, x) => a + workKj(x.series), 0)),
    });
  }
  return out;
}

export function ytdTotals(workouts: Workout[]) {
  const year = new Date().getFullYear();
  const set = workouts.filter((w) => new Date(w.startTime).getFullYear() === year);
  const hours = set.reduce((a, w) => a + w.summary.durationSec, 0) / 3600;
  return {
    rides: set.length,
    hours: Math.round(hours * 10) / 10,
    km: Math.round(set.reduce((a, w) => a + w.summary.distanceKm, 0) * 10) / 10,
    tss: Math.round(set.reduce((a, w) => a + w.summary.tss, 0)),
    kj: Math.round(set.reduce((a, w) => a + workKj(w.series), 0)),
    kcal: Math.round(set.reduce((a, w) => a + w.summary.calories, 0)),
  };
}

export function downsample(series: TelemetrySample[], max = 80) {
  if (series.length <= max) return series;
  const step = Math.ceil(series.length / max);
  return series.filter((_, i) => i % step === 0);
}

export interface RideCompare {
  a: Workout;
  b: Workout;
  rows: { label: string; a: string; b: string; better: "a" | "b" | "—" }[];
}

export function compareRides(a: Workout, b: Workout, profile: UserProfile): RideCompare {
  const pa = ridePhysics(a, profile.weightKg, profile.ftp);
  const pb = ridePhysics(b, profile.weightKg, profile.ftp);
  const cell = (
    label: string,
    av: number,
    bv: number,
    unit: string,
    higherBetter: boolean,
    digits = 0,
  ) => {
    const fmt = (n: number) => (digits ? n.toFixed(digits) : String(Math.round(n)));
    let better: "a" | "b" | "—" = "—";
    if (av !== bv) {
      if (higherBetter) better = av > bv ? "a" : "b";
      else better = av < bv ? "a" : "b";
    }
    return { label, a: av ? `${fmt(av)} ${unit}` : "—", b: bv ? `${fmt(bv)} ${unit}` : "—", better };
  };
  return {
    a,
    b,
    rows: [
      cell("Duration", a.summary.durationSec, b.summary.durationSec, "s", true),
      cell("Distance", a.summary.distanceKm, b.summary.distanceKm, "km", true, 1),
      cell("Avg power", a.summary.avgPower, b.summary.avgPower, "W", true),
      cell("NP", a.summary.np, b.summary.np, "W", true),
      cell("IF", a.summary.if_, b.summary.if_, "", true, 2),
      cell("TSS", a.summary.tss, b.summary.tss, "", true),
      cell("VI", pa.vi, pb.vi, "", false, 2),
      cell("Work", pa.workKj, pb.workKj, "kJ", true),
      cell("W/kg", pa.wPerKg, pb.wPerKg, "", true, 2),
      cell("Avg HR", a.summary.avgHeartRate, b.summary.avgHeartRate, "bpm", false),
      cell("EF", efficiencyFactor(a.summary.np, a.summary.avgHeartRate), efficiencyFactor(b.summary.np, b.summary.avgHeartRate), "", true, 2),
      cell("Cadence", a.summary.avgCadence, b.summary.avgCadence, "rpm", true),
      cell("kcal", a.summary.calories, b.summary.calories, "", true),
    ],
  };
}

export function extraRecords(workout: Workout, existing: PersonalRecord[]): PersonalRecord[] {
  const phy = ridePhysics(workout, 0, 0);
  const candidates: Omit<PersonalRecord, "id" | "previous">[] = [];
  if (phy.workKj > 0) {
    candidates.push({
      metric: "work_kj",
      label: "Most work",
      value: phy.workKj,
      unit: "kJ",
      workoutId: workout.id,
      date: workout.startTime,
    });
  }
  const k1 = fastestSplit(workout.series, 1000);
  if (k1) {
    candidates.push({
      metric: "fastest_1km",
      label: "Fastest 1 km",
      value: k1.sec,
      unit: "s",
      workoutId: workout.id,
      date: workout.startTime,
    });
  }
  const k5 = fastestSplit(workout.series, 5000);
  if (k5) {
    candidates.push({
      metric: "fastest_5km",
      label: "Fastest 5 km",
      value: k5.sec,
      unit: "s",
      workoutId: workout.id,
      date: workout.startTime,
    });
  }
  const next: PersonalRecord[] = [];
  for (const c of candidates) {
    const prev = existing.find((p) => p.metric === c.metric);
    const better = c.metric.startsWith("fastest_")
      ? !prev || c.value < prev.value - 0.05
      : !prev || c.value > prev.value + 0.05;
    if (better) {
      next.push({
        id: `${c.metric}_${workout.id}`,
        ...c,
        previous: prev?.value,
      });
    }
  }
  return next;
}

export function weeklyEf(workouts: Workout[]) {
  return workouts
    .filter((w) => w.summary.hrCaptured && w.summary.np > 0)
    .slice(-8)
    .map((w) => ({
      t: w.startTime.slice(5, 10),
      v: efficiencyFactor(w.summary.np, w.summary.avgHeartRate),
    }))
    .filter((d) => d.v > 0);
}
