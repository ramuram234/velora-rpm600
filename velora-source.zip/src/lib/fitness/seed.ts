import type { DeviceInfo, Goals, UserProfile } from "./types";

/** Empty profile — filled in onboarding. Nothing here is telemetry. */
export const DEFAULT_PROFILE: UserProfile = {
  name: "",
  sex: "male",
  dob: "",
  heightCm: 0,
  weightKg: 0,
  fitnessLevel: "intermediate",
  restingHr: 0,
  maxHr: 0,
  ftp: 0,
  ftpEstimated: true,
  units: "metric",
};

export const DEFAULT_GOALS: Goals = {
  targetWeightKg: 0,
  weeklyWorkouts: 3,
  dailySteps: 8000,
  focus: "endurance",
};

/** Hardware identity from the RPM600 GATT dump — not a live sample. */
export const RPM600: DeviceInfo = {
  name: "FS-583ADC",
  manufacturer: "JIANJIA",
  model: "JJ-BLE",
  hardware: "1.0",
  software: "1.0",
  batteryPercent: 0,
  resistanceMode: "manual",
};
