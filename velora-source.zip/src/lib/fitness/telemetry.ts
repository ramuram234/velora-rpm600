import type { CoachingCue, LiveSession, TelemetrySample, UserProfile } from "./types";
import { intervalAt } from "./workouts";

export function tickSession(
  session: LiveSession,
  dt: number,
  _profile: UserProfile,
  live?: {
    power?: number;
    cadence?: number;
    speed?: number;
    distanceM?: number;
    heartRate?: number;
    calories?: number;
    battery?: number;
  } | null,
): { session: LiveSession; cue: CoachingCue | null } {
  const elapsed = session.elapsedSec + dt;
  const loc = intervalAt(session.plan, elapsed);
  const prev = session.telemetry;
  const streaming = !!(live && (live.power != null || live.cadence != null || live.speed != null));

  if (!streaming) {
    let events = session.events;
    if (loc.index !== session.intervalIndex) {
      events = [
        ...events,
        { t: elapsed, kind: "interval" as const, text: loc.interval.label ?? loc.interval.type },
      ];
    }
    return {
      session: {
        ...session,
        elapsedSec: elapsed,
        intervalIndex: loc.index,
        events,
        source: "waiting",
        lastCue: session.series.length
          ? "Bike signal lost — last watts held"
          : "Waiting for Indoor Bike Data.",
        lastCueAt: session.lastCueAt,
      },
      cue: null,
    };
  }

  const power = Math.max(0, live!.power ?? 0);
  const cadence = live!.cadence ?? 0;
  const speed = live!.speed ?? 0;
  const hrPacket = live!.heartRate != null && live!.heartRate >= 0 && live!.heartRate <= 240;
  const liveHr = hrPacket && live!.heartRate! >= 30;
  const heartRate = hrPacket ? live!.heartRate! : 0;

  let origin = session.bleOrigin ?? {};
  if (live!.distanceM != null && origin.distance == null) {
    origin = { ...origin, distance: live!.distanceM };
  }
  if (live!.calories != null && origin.calories == null) {
    origin = { ...origin, calories: live!.calories };
  }

  let distance = prev.distance;
  if (live!.distanceM != null && origin.distance != null) {
    distance = Math.max(0, live!.distanceM - origin.distance);
  } else if (speed > 0) {
    distance = prev.distance + (speed / 3.6) * dt;
  }

  let kcal = prev.calories;
  if (live!.calories != null && origin.calories != null) {
    kcal = Math.max(0, live!.calories - origin.calories);
  } else if (power > 0) {
    // ACSM indoor: ~3.6 kcal per kJ of mechanical work (24% efficiency).
    kcal = prev.calories + power * dt * 0.001;
  }

  const battery = live!.battery != null ? live!.battery : session.battery;

  const sample: TelemetrySample = {
    t: elapsed,
    power: Math.round(power),
    cadence: Math.round(cadence * 10) / 10,
    speed: Math.round(speed * 10) / 10,
    distance,
    heartRate: Math.round(heartRate),
    calories: kcal,
    resistance: session.resistance,
    battery,
  };

  const series = session.series;
  const lastStored = series[series.length - 1];
  const nextSeries =
    !lastStored || elapsed - lastStored.t >= 1
      ? series.length > 5400
        ? [...series.slice(-5200), sample]
        : [...series, sample]
      : series;

  let events = session.events;
  if (loc.index !== session.intervalIndex) {
    events = [
      ...events,
      {
        t: elapsed,
        kind: "interval" as const,
        text: loc.interval.label ?? loc.interval.type,
      },
    ];
  }

  let cue: CoachingCue | null = null;
  const target = loc.interval.targetPower;
  const sinceCue = elapsed - session.lastCueAt;
  const moving = power > 0 || cadence > 0;
  if (target && moving && sinceCue > 8) {
    if (power < target.min - 8) {
      cue = { text: "Increase resistance", speak: true, urgency: "action" };
    } else if (power > target.max + 12) {
      cue = { text: "Ease off slightly and settle", speak: true, urgency: "action" };
    } else if (sinceCue > 28) {
      cue = { text: "You're on target. Hold.", speak: true, urgency: "success" };
    }
  }
  if (loc.remaining <= 31 && loc.remaining > 29 && sinceCue > 4) {
    cue = { text: "Thirty seconds remaining", speak: true, urgency: "info" };
  }
  if (loc.index !== session.intervalIndex) {
    const label = loc.interval.label ?? loc.interval.type;
    if (loc.interval.type === "recovery") {
      cue = { text: "Recovery begins now. Soft pedal.", speak: true, urgency: "info" };
    } else if (loc.interval.type === "cooldown") {
      cue = { text: "Cooldown. Spin it out.", speak: true, urgency: "info" };
    } else if (loc.interval.type === "warmup") {
      cue = { text: "Warm-up. Build in gradually.", speak: true, urgency: "info" };
    } else {
      cue = { text: `${label}. Find the watt window.`, speak: true, urgency: "action" };
    }
  }

  const next: LiveSession = {
    ...session,
    elapsedSec: elapsed,
    intervalIndex: loc.index,
    telemetry: sample,
    series: nextSeries,
    events,
    battery,
    lastCue: cue?.text ?? session.lastCue,
    lastCueAt: cue ? elapsed : session.lastCueAt,
    source: "ble",
    hrSource: liveHr || hrPacket
      ? session.hrSource === "strap"
        ? "strap"
        : "ble"
      : session.hrSource === "strap"
        ? "strap"
        : session.hrSource === "ble"
          ? "ble"
          : "none",
    bleOrigin: origin,
  };
  return { session: next, cue };
}
