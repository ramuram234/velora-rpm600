import { Capacitor, registerPlugin } from "@capacitor/core";

export type CoachSource = "nano" | "prompt-api" | "cloud" | "local";

interface VeloraAiPlugin {
  getAvailability(): Promise<{
    available: boolean;
    status: string;
    engine: string;
  }>;
  prompt(opts: { prompt: string; system?: string }): Promise<{
    ok: boolean;
    text?: string;
    error?: string;
  }>;
}

const VeloraAi = registerPlugin<VeloraAiPlugin>("VeloraAi", {
  web: () => ({
    getAvailability: async () => ({ available: false, status: "web", engine: "none" }),
    prompt: async () => ({ ok: false, error: "Gemini Nano is Android-only" }),
  }),
});

type LanguageModelCtor = {
  availability?: () => Promise<string>;
  create?: (opts?: { expectedInputs?: { type: string }[] }) => Promise<{
    prompt: (text: string) => Promise<string>;
    destroy?: () => void;
  }>;
};

function languageModel(): LanguageModelCtor | null {
  const g = globalThis as unknown as {
    LanguageModel?: LanguageModelCtor;
    ai?: { languageModel?: LanguageModelCtor };
  };
  return g.LanguageModel ?? g.ai?.languageModel ?? null;
}

export async function nanoAvailability(): Promise<{
  available: boolean;
  engine: string;
  status: string;
}> {
  if (Capacitor.isNativePlatform()) {
    try {
      return await VeloraAi.getAvailability();
    } catch {
      return { available: false, engine: "none", status: "plugin-missing" };
    }
  }
  const lm = languageModel();
  if (lm?.availability) {
    try {
      const status = await lm.availability();
      return { available: status === "available" || status === "readily", engine: "prompt-api", status };
    } catch {
      /* ignore */
    }
  }
  return { available: false, engine: "none", status: "unavailable" };
}

export async function askNano(system: string, user: string): Promise<{
  ok: boolean;
  text?: string;
  error?: string;
  source: CoachSource;
}> {
  const packed = `${system}\n\n${user}`;
  if (Capacitor.isNativePlatform()) {
    try {
      const res = await VeloraAi.prompt({ prompt: packed, system });
      if (res.ok && res.text) return { ok: true, text: res.text, source: "nano" };
      return { ok: false, error: res.error ?? "Gemini Nano unavailable", source: "nano" };
    } catch (e) {
      return { ok: false, error: e instanceof Error ? e.message : "Nano failed", source: "nano" };
    }
  }
  const lm = languageModel();
  if (lm?.create) {
    try {
      const session = await lm.create();
      const text = (await session.prompt(packed)).trim();
      session.destroy?.();
      if (text) return { ok: true, text, source: "prompt-api" };
    } catch {
      /* fall through */
    }
  }
  return { ok: false, error: "On-device model not present", source: "local" };
}
