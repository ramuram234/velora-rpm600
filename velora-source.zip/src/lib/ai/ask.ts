import type { CoachMode } from "./coach";
import { localAsk } from "./local-coach";
import { askNano } from "./nano";
import { useFitnessStore } from "@/lib/fitness/store";

export type { CoachMode };
export type CoachResult =
  | { ok: true; text: string; source: "nano" | "prompt-api" | "cloud" | "local" }
  | { ok: false; error: string; source: "nano" | "prompt-api" | "cloud" | "local" };

const RULES =
  "Never invent telemetry, rides, FTP, heart rate, steps, CTL, ATL, or TSB. If the context says those are missing, say so. Do not fill empty history with examples.";

const SYSTEM = {
  workout: `You are Velora, a cycling coach for an RPM600 indoor bike (FTMS, JIANJIA, MANUAL resistance knob — the app cannot turn the knob; it coaches the rider to).
${RULES}
If FTP is not set, do not return JSON — tell the rider to enter FTP or complete the 20-minute test.
Otherwise return ONLY valid JSON with this shape:
{"name":"string","description":"string","kind":"endurance|tempo|threshold|hiit|recovery|ftp|custom","intervals":[{"duration":seconds,"type":"warmup|endurance|tempo|threshold|interval|recovery|cooldown","targetPower":[minWatts,maxWatts],"label":"string"}]}
Rules: 4–12 intervals, total 12–75 minutes, warmup first, cooldown last, watt targets from the rider FTP in context. No markdown.`,
  chat: `You are Velora, a precise indoor-cycling coach for an RPM600 (manual resistance). Use only the provided context. Be concise, specific, and practical. ${RULES} BMI is a screening number, not body composition. Resistance is a physical knob — cue "increase resistance" rather than sending commands. 2–4 short paragraphs max, or a tight bullet list. No emoji.`,
  insight: `You are Velora. Give 3 concrete coaching takeaways from the ride. Mention heart-rate only if it was captured. ${RULES} No emoji.`,
};

export async function askCoach(args: {
  data: { prompt: string; context: string; mode: CoachMode };
}): Promise<CoachResult> {
  const { prompt, context, mode } = args.data;
  const system = SYSTEM[mode] ?? SYSTEM.chat;
  const user = `${context}\n\nRequest:\n${prompt}`;

  const nano = await askNano(system, user);
  if (nano.ok && nano.text) return { ok: true, text: nano.text, source: nano.source };

  if (import.meta.env.VITE_NATIVE !== "1") {
    try {
      const { askCoach: fn } = await import("./coach");
      const res = await fn(args);
      if (res.ok) return { ok: true, text: res.text, source: "cloud" };
    } catch {
      /* fall through to local */
    }
  }

  const local = localAsk(prompt, mode, useFitnessStore.getState());
  return local;
}
