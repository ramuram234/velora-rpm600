import type { FitnessState } from "@/lib/fitness/store";
import { trainingLoadSeries, trainingStatus, trendDelta } from "@/lib/fitness/analytics";
import { bmi } from "@/lib/fitness/format";
import { allTimeMmp, eftpFromMmp, ridePhysics } from "@/lib/fitness/advanced";
import { weightPlan } from "@/lib/fitness/goals-engine";

export function coachContext(s: FitnessState) {
  const recent = [...s.workouts].slice(-8).reverse();
  const load = trainingLoadSeries(s.workouts);
  const status = trainingStatus(load);
  const today = s.activity.find((d) => d.date === new Date().toISOString().slice(0, 10));
  const b = bmi(s.profile.heightCm, s.profile.weightKg);
  const plan = weightPlan(s.profile, s.goals, s.workouts, s.activity);
  const last = recent[0];
  const phy = last ? ridePhysics(last, s.profile.weightKg, s.profile.ftp) : null;
  const eftp = eftpFromMmp(allTimeMmp(s.workouts));
  return [
    `Rider: ${s.profile.name || "unnamed"}, ${s.profile.sex}. FTP ${s.profile.ftp > 0 ? `${s.profile.ftp} W${s.profile.ftpEstimated ? " (estimate)" : ""}` : "not set"}. Rest HR ${s.profile.restingHr || "not set"}, max HR ${s.profile.maxHr || "not set"}.`,
    s.profile.heightCm && s.profile.weightKg
      ? `Body: ${s.profile.heightCm} cm, ${s.profile.weightKg} kg, BMI ${b.toFixed(1)} (screening only). Target weight ${s.goals.targetWeightKg || "not set"} kg.${plan ? ` ${plan.note}` : ""}`
      : "Body metrics not fully entered.",
    `Goals: ${s.goals.weeklyWorkouts} rides/week, ${s.goals.dailySteps} steps/day, focus ${s.goals.focus}.`,
    `Device: RPM600 FS-583ADC (JIANJIA JJ-BLE), resistance MANUAL. Bike ${s.connection}. Battery ${s.deviceBattery > 0 ? `${Math.round(s.deviceBattery)}%` : "unknown"}. Bike HR service ${s.bikeHasHr ? "on" : "not confirmed"}${s.deviceHr >= 30 ? `, live ${s.deviceHr} bpm` : ""}. Chest strap: ${s.hrConnection === "connected" ? s.hrDeviceName : "not paired"}.`,
    s.workouts.length
      ? `Training from completed rides only: status ${status.label}, CTL ${status.ctl}, ATL ${status.atl}, TSB ${status.tsb}. Power trend ${s.workouts.length >= 4 ? `${Math.round(trendDelta(s.workouts) * 1000) / 10}%` : "needs 4 rides"}.${eftp ? ` eFTP ${eftp} W (best 20min × 0.95).` : ""}${phy ? ` Last VI ${phy.vi}, work ${phy.workKj} kJ${phy.wPerKg ? `, ${phy.wPerKg} W/kg` : ""}.` : ""}`
      : "No rides on file. CTL/ATL/TSB are 0. Do not invent a training history, watts, HR, steps, or CTL.",
    today
      ? `Today: ${today.steps ? `${today.steps} steps from Health Connect` : "steps not synced"}, cycling ${Math.round(today.cycleMin)} min / ${today.cycleKm} km / ${Math.round(today.cycleKcal)} kcal.`
      : "Today: no activity yet.",
    `Recent rides: ${recent
      .map(
        (w) =>
          `${w.startTime.slice(0, 10)} ${w.name} ${Math.round(w.summary.durationSec / 60)}min avg ${w.summary.avgPower}W NP ${w.summary.np}W HR ${w.summary.hrCaptured ? w.summary.avgHeartRate : "none"} TSS ${w.summary.tss}`,
      )
      .join(" | ") || "none"}`,
    `PRs: ${s.records.length ? s.records.slice(0, 8).map((r) => `${r.label} ${r.value}${r.unit}`).join("; ") : "none"}`,
  ].join("\n");
}
