import type { CoachMode } from "./coach";
import { trainingLoadSeries, trainingStatus, trendDelta } from "@/lib/fitness/analytics";
import { analyzeHrBlock, analyzeHrRide } from "@/lib/fitness/hr";
import { weightPlan } from "@/lib/fitness/goals-engine";
import type { FitnessState } from "@/lib/fitness/store";
import { LIBRARY, makePlan, scalePlanToFtp } from "@/lib/fitness/workouts";
import type { WorkoutKind, WorkoutPlan } from "@/lib/fitness/types";

function pickKind(prompt: string, status: string, focus: string): WorkoutKind {
  const p = prompt.toLowerCase();
  if (/ftp|test/.test(p)) return "ftp";
  if (/recover|easy|rest/.test(p)) return "recovery";
  if (/hiit|vo2|30\/30|interval/.test(p)) return "hiit";
  if (/threshold|sweet/.test(p)) return "threshold";
  if (/tempo/.test(p)) return "tempo";
  if (/endurance|z2|zone 2|base/.test(p)) return "endurance";
  if (status === "overreaching") return "recovery";
  if (status === "fresh" || status === "peaking") return focus === "ftp" ? "threshold" : "tempo";
  if (focus === "endurance") return "endurance";
  if (focus === "weight") return "endurance";
  return "endurance";
}

function planFor(kind: WorkoutKind, ftp: number, prompt: string): WorkoutPlan {
  const named = LIBRARY.find((p) => p.kind === kind && p.kind !== "free") ?? LIBRARY[1];
  const minutes = prompt.match(/(\d+)\s*(min|minute)/i);
  const scaled = scalePlanToFtp(named, ftp);
  if (!minutes) return { ...scaled, source: "ai" };
  const want = Math.max(12, Math.min(75, Number(minutes[1]))) * 60;
  const k = want / Math.max(60, scaled.durationSec);
  const intervals = scaled.intervals.map((iv) => ({
    ...iv,
    durationSec: Math.max(20, Math.round(iv.durationSec * k)),
  }));
  return makePlan(scaled.name, scaled.description, scaled.kind, intervals, "ai");
}

export function localAsk(
  prompt: string,
  mode: CoachMode,
  state: FitnessState,
): { ok: true; text: string; source: "local" } {
  const rides = state.workouts.length;
  const ftp = state.profile.ftp;
  const load = trainingLoadSeries(state.workouts);
  const status = trainingStatus(load);
  const last = [...state.workouts].sort((a, b) => +new Date(b.startTime) - +new Date(a.startTime))[0];
  const trend = trendDelta(state.workouts);
  const hrBlock = analyzeHrBlock(state.workouts, state.profile);
  const plan = weightPlan(state.profile, state.goals, state.workouts, state.activity);
  const p = prompt.toLowerCase();

  if (mode === "workout" || /build|generate|create|session|workout/.test(p)) {
    if (ftp <= 0) {
      return {
        ok: true,
        source: "local",
        text: "No FTP on file. I will not invent watt targets. Enter a known FTP in Profile, or complete the 20-minute test after pairing the bike.",
      };
    }
    const kind = pickKind(prompt, rides ? status.label : "untrained", state.goals.focus);
    const plan = planFor(kind, ftp, prompt);
    const json = {
      name: plan.name,
      description: plan.description,
      kind: plan.kind,
      intervals: plan.intervals.map((iv) => ({
        duration: iv.durationSec,
        type: iv.type,
        targetPower: iv.targetPower ? [iv.targetPower.min, iv.targetPower.max] : undefined,
        label: iv.label,
      })),
    };
    return { ok: true, source: "local", text: JSON.stringify(json) };
  }

  if (!rides) {
    return {
      ok: true,
      source: "local",
      text: [
        "No rides on file. CTL, ATL, and TSB start at 0. I will not invent a training history.",
        ftp > 0
          ? `FTP is ${ftp} W${state.profile.ftpEstimated ? " (entered as an estimate)" : ""}. Watt windows will use that once you ride.`
          : "FTP is not set. Structured sessions stay without watt targets until you type one or finish the 20-minute test.",
        hrBlock.rides
          ? ""
          : "Heart rate is captured from the bike’s Heart Rate Measurement (0x180D / 0x2A37) when you connect FS-583ADC — same as battery. Hold the pulse grips. Indoor Bike Data has no HR field.",
        "Pair the RPM600 on Devices, start a free ride, and finish at least 10 seconds with live FTMS. Then I can coach from your file.",
      ]
        .filter(Boolean)
        .join("\n\n"),
    };
  }

  if (mode === "insight" && last) {
    const hr = analyzeHrRide(last.series, state.profile);
    const lines = [
      `${last.name}: ${Math.round(last.summary.durationSec / 60)} min, ${last.summary.avgPower} W avg, NP ${last.summary.np} W, IF ${last.summary.if_}, ${last.summary.tss} TSS.`,
      hr.captured
        ? `Heart rate captured (${hr.coveragePct}% of samples): avg ${hr.avg} bpm, max ${hr.max}, TRIMP ${hr.trimp}. ${hr.note}`
        : "No heart-rate capture on this ride. Hold the pulse grips so 0x2A37 can stream BPM, or pair a chest strap.",
      last.summary.if_ > 0.95
        ? "This was a hard day. Next session should be endurance or recovery unless you are specifically stacking load."
        : last.summary.if_ < 0.7
          ? "Aerobic work. Repeatable tomorrow if the legs feel quiet."
          : "Solid tempo-range stimulus. Keep the next hard day at least 48 hours out if TSB is falling.",
      `Form (TSB) is ${status.tsb}. Status: ${status.label}. From completed rides only.`,
    ];
    return { ok: true, source: "local", text: lines.join("\n\n") };
  }

  const today = pickKind("today", status.label, state.goals.focus);
  const rec = LIBRARY.find((x) => x.kind === today) ?? LIBRARY[1];
  const hrLine = hrBlock.rides
    ? `Heart rate is on ${hrBlock.rides} rides (avg ${hrBlock.avg} bpm, max ${hrBlock.max}). Zone mix is Z1 ${hrBlock.timeInZonePct[0]}% · Z2 ${hrBlock.timeInZonePct[1]}% · Z3 ${hrBlock.timeInZonePct[2]}% · Z4 ${hrBlock.timeInZonePct[3]}% · Z5 ${hrBlock.timeInZonePct[4]}%.`
    : "Heart rate is not being captured yet. Connect the RPM600 — it already has Heart Rate Measurement (0x180D). Hold the grips while you ride.";

  let body: string;
  if (/overreach|fatigue|recover|form|tsb/.test(p)) {
    body = [
      `CTL ${status.ctl} (fitness), ATL ${status.atl} (fatigue), TSB ${status.tsb} (form). Label: ${status.label}. Banister from your completed rides, starting at 0.`,
      status.label === "overreaching"
        ? "Fatigue is ahead of fitness. Ride easy or take the day. Do not add VO2."
        : status.label === "fresh" || status.label === "peaking"
          ? "You have form in the bank. A threshold or short VO2 session is appropriate if the legs agree."
          : "Load is productive. Keep the current mix; do not stack two hard days.",
      hrLine,
    ].join("\n\n");
  } else if (/hr|heart/.test(p)) {
    body = [
      hrLine,
      last ? analyzeHrRide(last.series, state.profile).note : "No last ride to inspect.",
      state.profile.maxHr >= 80
        ? "Zones use the max HR in Profile."
        : "Max HR is not set, so zone time is not classified. Enter a tested max, or a Tanaka estimate, in Profile.",
    ].join("\n\n");
  } else if (/weight|fat|kcal|calor|diet/.test(p)) {
    body = plan
      ? [
          plan.note,
          "Z2 indoor rides add active calories from the bike. Velora does not log meals.",
          last ? `Last ride ${Math.round(last.summary.calories)} kcal from FTMS/ACSM.` : "No rides yet to count.",
        ].join("\n\n")
      : "Set current weight and a target weight in Profile (e.g. 65 kg). I will not invent a diet.";
  } else if (/ftp|power|trend/.test(p)) {
    body = [
      ftp > 0
        ? `FTP is ${ftp} W${state.profile.ftpEstimated ? " (estimate until a 20-min test)" : ""}. Four-week power trend ${rides >= 4 ? `${Math.round(trend * 1000) / 10}%` : "needs at least 4 rides"}.`
        : "FTP is not set. I will not invent one.",
      last ? `Last ride NP ${last.summary.np} W, IF ${last.summary.if_}.` : "No rides on file.",
      "The RPM600 reports instantaneous power on FTMS. Resistance is a physical knob — raise watts by turning it, not from the phone.",
    ].join("\n\n");
  } else {
    body = [
      `Today’s call from your file: ${rec.name} (${Math.round(rec.durationSec / 60)} min ${rec.kind}). Status ${status.label}, TSB ${status.tsb}.`,
      rec.description,
      hrLine,
      ftp > 0
        ? "Ask me to build that session if you want it on the start list."
        : "Set FTP before I can attach watt windows to that session.",
    ].join("\n\n");
  }

  return { ok: true, source: "local", text: body };
}
