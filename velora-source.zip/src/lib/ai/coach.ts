import { createServerFn } from "@tanstack/react-start";

export type CoachMode = "chat" | "workout" | "insight";

export const askCoach = createServerFn({ method: "POST" })
  .validator((input: { prompt: string; context: string; mode: CoachMode }) => input)
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "AI is not available in this environment" };

    const system =
      data.mode === "workout"
        ? `You are Velora, a cycling coach for an RPM600 indoor bike (FTMS, JIANJIA, MANUAL resistance knob — the app cannot turn the knob; it coaches the rider to).
Never invent telemetry, rides, FTP, heart rate, steps, or training load. If FTP is not set, do not return JSON — tell the rider to enter FTP or complete the 20-minute test.
Otherwise return ONLY valid JSON with this shape:
{"name":"string","description":"string","kind":"endurance|tempo|threshold|hiit|recovery|ftp|custom","intervals":[{"duration":seconds,"type":"warmup|endurance|tempo|threshold|interval|recovery|cooldown","targetPower":[minWatts,maxWatts],"label":"string"}]}
Rules: 4–12 intervals, total 12–75 minutes, warmup first, cooldown last, watt targets realistic for the rider FTP in context. No markdown.`
        : `You are Velora, a precise indoor-cycling coach for an RPM600 (manual resistance). Use only the provided context. Be concise, specific, and practical. Never invent telemetry, rides, FTP, heart rate, steps, CTL, ATL, or TSB. BMI is a screening number, not body composition. Resistance is a physical knob — cue "increase resistance" rather than sending commands. 2–4 short paragraphs max, or a tight bullet list. No emoji.`;

    try {
      const res = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "grok-4.5",
          temperature: data.mode === "workout" ? 0.4 : 0.6,
          max_tokens: data.mode === "workout" ? 700 : 500,
          messages: [
            { role: "system", content: system },
            {
              role: "user",
              content: `${data.context}\n\nRequest:\n${data.prompt}`,
            },
          ],
        }),
      });
      if (!res.ok) {
        return { ok: false as const, error: `Coach is unavailable (${res.status})` };
      }
      const body = (await res.json()) as {
        choices?: { message?: { content?: string } }[];
      };
      const text = body.choices?.[0]?.message?.content?.trim() ?? "";
      if (!text) return { ok: false as const, error: "Empty coach response" };
      return { ok: true as const, text };
    } catch {
      return { ok: false as const, error: "Could not reach the coach" };
    }
  });
