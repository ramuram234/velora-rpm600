import { useEffect } from "react";
import { useFitnessStore } from "@/lib/fitness/store";

export function SessionLoop() {
  const status = useFitnessStore((s) => s.session?.status);

  useEffect(() => {
    if (status !== "active") return;
    const id = window.setInterval(() => {
      useFitnessStore.getState().tick(0.25);
    }, 250);
    return () => window.clearInterval(id);
  }, [status]);

  return null;
}
