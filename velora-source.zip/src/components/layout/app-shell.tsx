import { Link, Outlet, useRouterState } from "@tanstack/react-router";
import {
  Activity,
  BarChart3,
  Bike,
  Bluetooth,
  History,
  House,
  Settings,
  Sparkles,
  UserRound,
} from "lucide-react";
import { useEffect } from "react";
import { useFitnessStore } from "@/lib/fitness/store";
import { cn } from "@/lib/utils";

const tabs = [
  { to: "/", label: "Home", icon: House },
  { to: "/workout", label: "Workout", icon: Bike },
  { to: "/analytics", label: "Analytics", icon: BarChart3 },
  { to: "/history", label: "History", icon: History },
  { to: "/profile", label: "Profile", icon: UserRound },
] as const;

const side = [
  ...tabs,
  { to: "/activity", label: "Activity", icon: Activity },
  { to: "/coach", label: "Coach", icon: Sparkles },
  { to: "/progress", label: "Progress", icon: BarChart3 },
  { to: "/devices", label: "Devices", icon: Bluetooth },
  { to: "/settings", label: "Settings", icon: Settings },
] as const;

export function AppShell() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const live = pathname.startsWith("/workout/live");
  const connection = useFitnessStore((s) => s.connection);
  const theme = useFitnessStore((s) => s.theme);
  const name = useFitnessStore((s) => s.profile.name);

  useEffect(() => {
    document.documentElement.classList.toggle("light", theme === "light");
  }, [theme]);

  if (live) return <Outlet />;

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <aside className="fixed inset-y-0 left-0 z-20 hidden w-56 flex-col border-r border-line bg-surface/80 px-3 py-5 lg:flex">
        <Link to="/" className="mb-8 px-2">
          <div className="font-display text-lg font-medium tracking-display">VELORA</div>
          <div className="text-[11px] uppercase tracking-wide text-subtle">RPM600 OS</div>
        </Link>
        <nav className="flex flex-1 flex-col gap-0.5">
          {side.map((item) => {
            const Icon = item.icon;
            const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex h-11 items-center gap-3 rounded-lg px-3 text-sm transition-[background-color,color] duration-150",
                  active ? "bg-surface-2 text-fg" : "text-muted hover:bg-surface-2 hover:text-fg",
                )}
              >
                <Icon className="size-4" strokeWidth={1.75} />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="mt-4 rounded-lg bg-surface-2 px-3 py-2.5 shadow-[var(--shadow-border)]">
          <div className="text-xs text-subtle">Rider</div>
          <div className="text-sm font-medium">{name || "Rider"}</div>
          <div className="mt-1 text-xs text-accent">
            {connection === "connected" ? "Bike live" : "Bike offline"}
          </div>
        </div>
      </aside>

      <div className="lg:pl-56">
        <main className="mx-auto min-h-dvh w-full max-w-5xl px-4 pb-24 pt-5 sm:px-6 lg:pb-10 lg:pt-8">
          <Outlet />
        </main>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-20 border-t border-line bg-bg/92 pb-[env(safe-area-inset-bottom)] backdrop-blur-md lg:hidden">
        <div className="mx-auto grid max-w-lg grid-cols-5 px-1 pt-1">
          {tabs.map((item) => {
            const Icon = item.icon;
            const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex h-14 flex-col items-center justify-center gap-1 text-[11px] transition-colors duration-150",
                  active ? "text-fg" : "text-subtle",
                )}
              >
                <Icon className="size-5" strokeWidth={active ? 2 : 1.6} />
                {item.label}
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
