import { ChevronRight, Download } from "lucide-react";
import { useState } from "react";
import { Button, buttonVariants } from "@/components/ui/button";
import { Badge, Input, Label, Select } from "@/components/ui/primitives";
import { ageFromDob, bmi, bmiLabel, estimateMaxHr, ftpFromLevel } from "@/lib/fitness/format";
import { DEFAULT_GOALS, DEFAULT_PROFILE, RPM600 } from "@/lib/fitness/seed";
import { useFitnessStore } from "@/lib/fitness/store";
import type { FitnessLevel, Goals, Sex, UserProfile } from "@/lib/fitness/types";

export function Welcome() {
  const complete = useFitnessStore((s) => s.completeOnboarding);
  const connect = useFitnessStore((s) => s.connectDevice);
  const connection = useFitnessStore((s) => s.connection);
  const bleError = useFitnessStore((s) => s.bleError);
  const [step, setStep] = useState(0);
  const [profile, setProfile] = useState<UserProfile>(DEFAULT_PROFILE);
  const [goals, setGoals] = useState<Goals>(DEFAULT_GOALS);
  const [err, setErr] = useState<string | null>(null);

  const b = bmi(profile.heightCm, profile.weightKg);
  const tanaka = estimateMaxHr(ageFromDob(profile.dob), profile.sex);

  function patch(p: Partial<UserProfile>) {
    setProfile((cur) => ({ ...cur, ...p }));
  }

  function goNext() {
    setErr(null);
    if (step === 1) {
      if (!profile.name.trim()) return setErr("Enter your name.");
      if (profile.heightCm < 120 || profile.heightCm > 230) return setErr("Height looks off.");
      if (profile.weightKg < 35 || profile.weightKg > 250) return setErr("Weight looks off.");
    }
    if (step < 3) setStep((s) => s + 1);
    else complete(profile, { ...goals, targetWeightKg: goals.targetWeightKg || 0 });
  }

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <div className="mx-auto flex min-h-dvh max-w-md flex-col px-5 py-8">
        <div className="mb-8 flex items-center justify-between text-xs uppercase tracking-wide text-subtle">
          <span>Velora</span>
          <span>{step + 1} / 4</span>
        </div>

        {step === 0 ? (
          <div className="stagger-in flex flex-1 flex-col justify-center">
            <p className="text-xs uppercase tracking-[0.22em] text-accent">RPM600 companion</p>
            <h1 className="mt-4 font-display text-4xl font-medium leading-tight tracking-display">
              Only what the bike
              <br />
              actually sends.
            </h1>
            <p className="mt-4 max-w-sm text-muted">
              No sample history. No simulated watts. Rides and heart rate come from the bike
              (FTMS + Heart Rate Measurement). Steps come from Health Connect — or they stay empty.
            </p>
          </div>
        ) : null}

        {step === 1 ? (
          <div className="stagger-in flex flex-1 flex-col gap-4">
            <h1 className="font-display text-3xl font-medium tracking-display">You</h1>
            <p className="text-sm text-muted">Stored only on this device. Used for zones and calories.</p>
            <div className="grid gap-3">
              <div>
                <Label htmlFor="name">Name</Label>
                <Input id="name" className="mt-1.5" placeholder="Your name" value={profile.name} onChange={(e) => patch({ name: e.target.value })} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="sex">Sex</Label>
                  <Select id="sex" className="mt-1.5" value={profile.sex} onChange={(e) => patch({ sex: e.target.value as Sex })}>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="dob">Date of birth (optional)</Label>
                  <Input id="dob" type="date" className="mt-1.5" value={profile.dob} onChange={(e) => patch({ dob: e.target.value })} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="h">Height (cm)</Label>
                  <Input id="h" type="number" className="mt-1.5" placeholder="cm" value={profile.heightCm || ""} onChange={(e) => patch({ heightCm: Number(e.target.value) })} />
                </div>
                <div>
                  <Label htmlFor="w">Weight (kg)</Label>
                  <Input id="w" type="number" step="0.1" className="mt-1.5" placeholder="kg" value={profile.weightKg || ""} onChange={(e) => patch({ weightKg: Number(e.target.value) })} />
                </div>
              </div>
              {b > 0 ? (
                <div className="rounded-lg bg-surface-2 px-3 py-3 shadow-[var(--shadow-border)]">
                  <div className="text-xs uppercase tracking-wide text-subtle">BMI screening</div>
                  <div className="mt-1 font-display text-2xl tabular">{b.toFixed(1)}</div>
                  <div className="text-sm text-muted">{bmiLabel(b)} — not body composition.</div>
                </div>
              ) : null}
            </div>
          </div>
        ) : null}

        {step === 2 ? (
          <div className="stagger-in flex flex-1 flex-col gap-4">
            <h1 className="font-display text-3xl font-medium tracking-display">Training</h1>
            <p className="text-sm text-muted">
              Leave FTP and max HR at 0 if you do not know them. Estimates are only written if you tap the buttons.
            </p>
            <div>
              <Label>Fitness level</Label>
              <div className="mt-2 grid grid-cols-3 gap-2">
                {(["beginner", "intermediate", "advanced"] as FitnessLevel[]).map((lvl) => (
                  <button
                    key={lvl}
                    className={`h-11 rounded-lg text-sm capitalize shadow-[var(--shadow-border)] ${
                      profile.fitnessLevel === lvl ? "bg-fg text-bg" : "bg-surface-2 text-muted"
                    }`}
                    onClick={() => patch({ fitnessLevel: lvl })}
                  >
                    {lvl}
                  </button>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>FTP (watts)</Label>
                <Input
                  type="number"
                  className="mt-1.5"
                  value={profile.ftp || ""}
                  onChange={(e) =>
                    setProfile((cur) => ({ ...cur, ftp: Number(e.target.value), ftpEstimated: false }))
                  }
                />
                <button
                  type="button"
                  className="mt-1 text-left text-[11px] text-accent"
                  onClick={() => {
                    const ftp = ftpFromLevel(profile.fitnessLevel, profile.weightKg);
                    if (ftp > 0) setProfile((cur) => ({ ...cur, ftp, ftpEstimated: true }));
                  }}
                >
                  Estimate from level × kg
                </button>
                <p className="mt-1 text-[11px] text-subtle">
                  {profile.ftp
                    ? profile.ftpEstimated
                      ? "Estimate — replace with a 20-min test"
                      : "Manual"
                    : "Blank until you type or estimate"}
                </p>
              </div>
              <div>
                <Label>Max HR</Label>
                <Input
                  type="number"
                  className="mt-1.5"
                  value={profile.maxHr || ""}
                  onChange={(e) => setProfile((cur) => ({ ...cur, maxHr: Number(e.target.value) }))}
                />
                {tanaka > 0 ? (
                  <button
                    type="button"
                    className="mt-1 text-left text-[11px] text-accent"
                    onClick={() => patch({ maxHr: tanaka })}
                  >
                    Use Tanaka {tanaka} bpm
                  </button>
                ) : (
                  <p className="mt-1 text-[11px] text-subtle">Add DOB for Tanaka 208 − 0.7 × age</p>
                )}
              </div>
            </div>
            <div>
              <Label>Resting HR (optional)</Label>
              <Input
                type="number"
                className="mt-1.5"
                placeholder="Leave blank if unknown"
                value={profile.restingHr || ""}
                onChange={(e) => setProfile((cur) => ({ ...cur, restingHr: Number(e.target.value) }))}
              />
            </div>
            <div>
              <Label>Focus</Label>
              <Select className="mt-1.5" value={goals.focus} onChange={(e) => setGoals({ ...goals, focus: e.target.value as Goals["focus"] })}>
                <option value="ftp">Raise FTP</option>
                <option value="endurance">Build endurance</option>
                <option value="weight">Lose weight</option>
                <option value="consistency">Stay consistent</option>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Target weight (kg)</Label>
                <Input
                  type="number"
                  step="0.1"
                  className="mt-1.5"
                  placeholder={profile.weightKg ? String(profile.weightKg) : "kg"}
                  value={goals.targetWeightKg || ""}
                  onChange={(e) => setGoals({ ...goals, targetWeightKg: Number(e.target.value) })}
                />
                {profile.weightKg > 0 && goals.targetWeightKg > 0 ? (
                  <p className="mt-1 text-[11px] text-subtle">
                    {goals.targetWeightKg < profile.weightKg
                      ? `Lose ${(profile.weightKg - goals.targetWeightKg).toFixed(1)} kg`
                      : goals.targetWeightKg > profile.weightKg
                        ? `Gain ${(goals.targetWeightKg - profile.weightKg).toFixed(1)} kg`
                        : "Maintain current weight"}
                  </p>
                ) : (
                  <p className="mt-1 text-[11px] text-subtle">Optional. Example: 65</p>
                )}
              </div>
              <div>
                <Label>Daily step goal</Label>
                <Input type="number" className="mt-1.5" value={goals.dailySteps} onChange={(e) => setGoals({ ...goals, dailySteps: Number(e.target.value) })} />
              </div>
            </div>
            <div>
              <Label>Weekly rides</Label>
              <Input type="number" className="mt-1.5" value={goals.weeklyWorkouts} onChange={(e) => setGoals({ ...goals, weeklyWorkouts: Number(e.target.value) })} />
            </div>
          </div>
        ) : null}

        {step === 3 ? (
          <div className="stagger-in flex flex-1 flex-col">
            <h1 className="font-display text-3xl font-medium tracking-display">Find the bike</h1>
            <p className="mt-2 text-sm text-muted">
              Pair <span className="text-fg">FS-583ADC</span>. You can skip and pair later from Devices — the dashboard stays empty until a real ride.
            </p>
            <div className="mt-8 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">{RPM600.name}</div>
                  <div className="text-xs text-muted">
                    {RPM600.manufacturer} · {RPM600.model}
                  </div>
                </div>
                <Badge tone={connection === "connected" ? "good" : "muted"}>
                  {connection === "connected" ? "Paired" : connection === "connecting" ? "Pairing" : "Not paired"}
                </Badge>
              </div>
              {bleError ? <p className="mt-2 text-sm text-danger">{bleError}</p> : null}
              {connection !== "connected" ? (
                <div className="mt-4 space-y-2">
                  <Button className="w-full" variant="secondary" onClick={() => void connect()}>
                    {connection === "connecting" ? "Waiting for chooser…" : "Pair RPM600"}
                  </Button>
                  <a href="/velora-rpm600.apk" download className={`${buttonVariants({ variant: "ghost" })} w-full`}>
                    <Download className="size-4" />
                    Download Android APK
                  </a>
                </div>
              ) : (
                <p className="mt-4 text-sm text-accent">Linked. Resistance stays a physical knob.</p>
              )}
            </div>
          </div>
        ) : null}

        {err ? <p className="mt-4 text-sm text-danger">{err}</p> : null}

        <div className="mt-8 flex gap-3">
          {step > 0 ? (
            <Button variant="ghost" onClick={() => { setErr(null); setStep((s) => s - 1); }}>
              Back
            </Button>
          ) : null}
          <Button className="flex-1" onClick={goNext}>
            {step === 0 ? "Set up" : step === 3 ? "Open Velora" : "Continue"}
            <ChevronRight className="size-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
