import {
  createRootRoute,
  HeadContent,
  Outlet,
  Scripts,
} from "@tanstack/react-router";
import { type ReactNode, useEffect } from "react";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { SessionLoop } from "@/components/layout/session-loop";
import { useFitnessStore } from "@/lib/fitness/store";
import appCss from "../styles.css?url";

const APP_NAME = "Velora";

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { title: APP_NAME },
      { name: "theme-color", content: "#05080D" },
      {
        name: "description",
        content: "Velora — local-first indoor cycling OS for the RPM600.",
      },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=Outfit:wght@300;400;500;600;700&display=swap",
      },
    ],
  }),
  component: RootDocument,
});

function RootDocument() {
  const inner = (
    <>
      <PreviewHostBridge />
      <AuthProvider>
        <Boot>
          <Outlet />
        </Boot>
      </AuthProvider>
    </>
  );

  if (import.meta.env.VITE_NATIVE === "1") {
    return inner;
  }

  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body className="antialiased">
        {inner}
        <Scripts />
      </body>
    </html>
  );
}

function Boot({ children }: { children: ReactNode }) {
  const theme = useFitnessStore((s) => s.theme);

  useEffect(() => {
    const unsub = useFitnessStore.persist.onFinishHydration(() => {
      useFitnessStore.setState({ hydrated: true });
    });
    void useFitnessStore.persist.rehydrate();
    const t = window.setTimeout(() => {
      if (!useFitnessStore.getState().hydrated) {
        useFitnessStore.setState({ hydrated: true });
      }
    }, 400);
    return () => {
      unsub();
      window.clearTimeout(t);
    };
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("light", theme === "light");
  }, [theme]);

  return (
    <>
      <SessionLoop />
      {children}
    </>
  );
}
