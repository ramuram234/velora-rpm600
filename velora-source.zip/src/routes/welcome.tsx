import { createFileRoute } from "@tanstack/react-router";
import { Welcome } from "@/components/onboarding/welcome";

export const Route = createFileRoute("/welcome")({
  component: Welcome,
});
