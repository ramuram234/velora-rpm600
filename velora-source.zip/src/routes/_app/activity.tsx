import { createFileRoute, Link } from "@tanstack/react-router";
import { MetricBars } from "@/components/charts/spark";
import { Button } from "@/components/ui/button";
import { Card, ProgressBar, SectionTitle, Stat } from "@/components/ui/primitives";
import { todayKey } from "@/lib/fitness/format";
import { useFitnessStore } from "@/lib/fitness/store";

export const Route = createFileRoute("/_app/activity")({
  component: ActivityPage,
});

function ActivityPage() {
  const activity = useFitnessStore((s) => s.activity);
  const goals = useFitnessStore((s) => s.goals);
  const today = activity.find((d) => d.date === todayKey());
  const week = activity.filter((d) => Date.now() - +new Date(d.date) < 8 * 86400000);
  const weekSteps = week.reduce((a, d) => a + d.steps, 0);
  const weekCycle = week.reduce((a, d) => a + d.cycleMin, 0);
  const empty = !activity.length;

  return (
    <div className="stagger-in space-y-6">
      <header>
        <p className="text-sm text-muted">Steps from this phone’s sensor and Health Connect. Cycling from finished rides.</p>
        <h1 className="font-display text-3xl font-medium tracking-display">Activity</h1>
      </header>

      {empty ? (
        <Card className="space-y-3">
          <SectionTitle title="Nothing logged yet" />
          <p className="text-sm text-muted">
            This page stays empty until you finish a ride or sync steps (phone step counter or Health
            Connect). Walking distance is not invented from step count.
          </p>
          <div className="flex gap-2">
            <Link to="/devices">
              <Button variant="secondary">Connect bike</Button>
            </Link>
            <Link to="/settings">
              <Button variant="secondary">Health Connect</Button>
            </Link>
          </div>
        </Card>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3">
            <Card>
              <Stat label="Steps today" value={today?.steps ? today.steps.toLocaleString() : "—"} />
              {goals.dailySteps > 0 && today?.steps ? (
                <ProgressBar className="mt-3" value={(today.steps / goals.dailySteps) * 100} />
              ) : (
                <p className="mt-3 text-xs text-muted">Sync Health Connect to fill steps.</p>
              )}
            </Card>
            <Card>
              <Stat
                label="Cycle kcal today"
                value={today?.cycleKcal ? Math.round(today.cycleKcal) : "—"}
              />
            </Card>
          </div>

          <Card>
            <SectionTitle title="Today split" />
            <div className="grid grid-cols-3 gap-3">
              <div>
                <div className="text-xs uppercase tracking-wide text-subtle">Walking</div>
                <div className="mt-1 font-display text-xl tabular">
                  {today?.steps ? today.steps.toLocaleString() : "—"}
                </div>
                <div className="text-xs text-muted">steps · not estimated km</div>
              </div>
              <div>
                <div className="text-xs uppercase tracking-wide text-subtle">Cycling</div>
                <div className="mt-1 font-display text-xl tabular">{today ? Math.round(today.cycleMin) : "—"} min</div>
                <div className="text-xs text-muted">{today ? `${today.cycleKm.toFixed(1)} km` : "from rides"}</div>
              </div>
              <div>
                <div className="text-xs uppercase tracking-wide text-subtle">Cycle kcal</div>
                <div className="mt-1 font-display text-xl tabular">
                  {today ? Math.round(today.cycleKcal) : "—"}
                </div>
                <div className="text-xs text-muted">from FTMS / ACSM</div>
              </div>
            </div>
          </Card>

          <Card>
            <SectionTitle title="Steps (logged days)" />
            {week.some((d) => d.steps) ? (
              <>
                <MetricBars data={week.map((d) => ({ t: d.date.slice(8), v: d.steps }))} />
                <p className="mt-2 text-xs text-muted">
                  {weekSteps.toLocaleString()} steps · {Math.round(weekCycle)} min cycling
                </p>
              </>
            ) : (
              <p className="text-sm text-muted">No step days yet. Sync Health Connect after installing the APK.</p>
            )}
          </Card>

          <Card>
            <SectionTitle title="Logged days" />
            <MetricBars data={activity.map((d) => ({ t: d.date.slice(8), v: d.steps || d.cycleMin }))} height={140} />
          </Card>
        </>
      )}
    </div>
  );
}
