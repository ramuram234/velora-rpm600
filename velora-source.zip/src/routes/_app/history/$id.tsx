import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/_app/history/$id")({
  beforeLoad: ({ params }) => {
    throw redirect({ to: "/workout/$id", params: { id: params.id } });
  },
  component: () => null,
});
