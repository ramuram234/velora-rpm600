import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/primitives";
import { formatDate, formatTime } from "@/lib/fitness/format";
import { useFitnessStore } from "@/lib/fitness/store";

export const Route = createFileRoute("/_app/history/")({
  component: HistoryList,
});

function HistoryList() {
  const workouts = useFitnessStore((s) => s.workouts);
  const [q, setQ] = useState("");
  const sorted = useMemo(
    () =>
      [...workouts]
        .sort((a, b) => +new Date(b.startTime) - +new Date(a.startTime))
        .filter((w) => w.name.toLowerCase().includes(q.toLowerCase()) || w.kind.includes(q.toLowerCase())),
    [workouts, q],
  );

  const byMonth = new Map<string, typeof sorted>();
  for (const w of sorted) {
    const key = new Date(w.startTime).toLocaleDateString(undefined, { month: "long", year: "numeric" });
    const arr = byMonth.get(key) ?? [];
    arr.push(w);
    byMonth.set(key, arr);
  }

  return (
    <div className="stagger-in space-y-6">
      <header>
        <p className="text-sm text-muted">
          {workouts.length ? `${workouts.length} indoor sessions` : "No indoor sessions yet"}
        </p>
        <h1 className="font-display text-3xl font-medium tracking-display">History</h1>
      </header>
      {workouts.length ? (
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Filter rides"
          className="h-11 w-full rounded-xl bg-surface px-4 text-sm shadow-[var(--shadow-border)] placeholder:text-subtle focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
        />
      ) : null}
      {[...byMonth.entries()].map(([month, list]) => (
        <section key={month}>
          <h2 className="mb-2 text-xs font-medium uppercase tracking-wide text-subtle">{month}</h2>
          <div className="space-y-2">
            {list.map((w) => (
              <Link key={w.id} to="/workout/$id" params={{ id: w.id }} className="block">
                <Card className="flex items-center justify-between gap-3 py-3">
                  <div className="min-w-0">
                    <div className="truncate font-medium">{w.name}</div>
                    <div className="text-xs text-muted">
                      {formatDate(w.startTime)} · {formatTime(w.summary.durationSec)} ·{" "}
                      {w.summary.distanceKm.toFixed(1)} km
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-display tabular text-accent">{w.summary.avgPower} W</div>
                    <div className="text-[11px] text-subtle">{w.summary.tss} TSS</div>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        </section>
      ))}
      {!sorted.length ? (
        <Card className="space-y-3 py-8 text-center">
          <p className="text-muted">
            History stays empty until you finish a ride with live FTMS. Nothing is preloaded.
          </p>
          <Link to="/devices">
            <Button variant="secondary">Connect bike</Button>
          </Link>
        </Card>
      ) : null}
    </div>
  );
}
