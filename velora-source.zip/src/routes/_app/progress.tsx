import { createFileRoute } from "@tanstack/react-router";
import { MetricLine } from "@/components/charts/spark";
import { Badge, Card, ProgressBar, SectionTitle, Stat } from "@/components/ui/primitives";
import { formatDate, formatTime } from "@/lib/fitness/format";
import { allTimeMmp, eftpFromMmp, ytdTotals } from "@/lib/fitness/advanced";
import { weightPlan } from "@/lib/fitness/goals-engine";
import { useFitnessStore } from "@/lib/fitness/store";

export const Route = createFileRoute("/_app/progress")({
  component: ProgressPage,
});

function ProgressPage() {
  const records = useFitnessStore((s) => s.records);
  const achievements = useFitnessStore((s) => s.achievements);
  const body = useFitnessStore((s) => s.bodyHistory);
  const goals = useFitnessStore((s) => s.goals);
  const profile = useFitnessStore((s) => s.profile);
  const workouts = useFitnessStore((s) => s.workouts);
  const activity = useFitnessStore((s) => s.activity);
  const plan = weightPlan(profile, goals, workouts, activity);
  const mmp = allTimeMmp(workouts);
  const eftp = eftpFromMmp(mmp);
  const ytd = ytdTotals(workouts);
  const weightDelta = body.length >= 2 ? body[body.length - 1].weightKg - body[0].weightKg : 0;
  const toGo =
    profile.weightKg > 0 && goals.targetWeightKg > 0 ? profile.weightKg - goals.targetWeightKg : null;
  const startW = body[0]?.weightKg;
  const span = startW && goals.targetWeightKg ? startW - goals.targetWeightKg : 0;

  return (
    <div className="stagger-in space-y-6">
      <header>
        <p className="text-sm text-muted">Records, weight, and marks earned from real rides</p>
        <h1 className="font-display text-3xl font-medium tracking-display">Progress</h1>
      </header>

      <Card>
        <SectionTitle title="Weight" />
        {profile.weightKg > 0 ? (
          <>
            <div className="grid grid-cols-3 gap-3">
              <Stat label="Now" value={profile.weightKg.toFixed(1)} unit="kg" />
              <Stat
                label="Target"
                value={goals.targetWeightKg > 0 ? goals.targetWeightKg.toFixed(1) : "—"}
                unit={goals.targetWeightKg > 0 ? "kg" : undefined}
              />
              <Stat
                label="Change"
                value={body.length >= 2 ? `${weightDelta >= 0 ? "+" : ""}${weightDelta.toFixed(1)}` : "—"}
                unit={body.length >= 2 ? "kg" : undefined}
              />
            </div>
            {span ? (
              <ProgressBar
                className="mt-4"
                value={Math.min(100, Math.max(0, ((startW - profile.weightKg) / span) * 100))}
              />
            ) : null}
            <p className="mt-2 text-xs text-muted">
              {plan ? plan.note : toGo != null ? `${toGo.toFixed(1)} kg to target. ` : "Set a target in Profile. "}
              BMI is a screening number only.
            </p>
            {body.length > 1 ? (
              <div className="mt-4">
                <MetricLine
                  data={body.map((b) => ({ t: formatDate(b.date, { month: "short", day: "numeric" }), v: b.weightKg }))}
                  height={160}
                />
              </div>
            ) : null}
          </>
        ) : (
          <p className="text-sm text-muted">No weight entered. Add it in Profile — it will not be invented.</p>
        )}
      </Card>

      <Card>
        <SectionTitle title="Season" />
        {ytd.rides ? (
          <div className="grid grid-cols-3 gap-3">
            <Stat label="Rides" value={ytd.rides} />
            <Stat label="Hours" value={ytd.hours} />
            <Stat label="TSS" value={ytd.tss} />
            <Stat label="km" value={ytd.km.toFixed(1)} />
            <Stat label="Work" value={ytd.kj || "—"} unit={ytd.kj ? "kJ" : undefined} />
            <Stat label="eFTP" value={eftp || "—"} unit={eftp ? "W" : undefined} hint="Best 20 min × 0.95" />
          </div>
        ) : (
          <p className="text-sm text-muted">Season totals fill after the first saved ride.</p>
        )}
      </Card>

      <Card>
        <SectionTitle title="Personal records" />
        {records.length ? (
          <div className="space-y-2">
            {records.map((r) => (
              <div key={r.metric} className="flex items-center justify-between rounded-lg bg-surface-2 px-3 py-2.5">
                <div>
                  <div className="text-sm">{r.label}</div>
                  <div className="text-xs text-subtle">{formatDate(r.date)}</div>
                </div>
                <div className="font-display tabular text-accent">
                  {r.unit === "s" ? formatTime(r.value) : `${r.value} ${r.unit}`}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-muted">PRs appear after your first saved ride.</p>
        )}
      </Card>

      <Card>
        <SectionTitle title="Achievements" />
        {achievements.length ? (
          <div className="space-y-2">
            {achievements.map((a) => (
              <div key={a.id} className="flex items-start justify-between gap-3 rounded-lg bg-surface-2 px-3 py-2.5">
                <div>
                  <div className="font-medium">{a.title}</div>
                  <div className="text-sm text-muted">{a.detail}</div>
                </div>
                <Badge>{formatDate(a.earnedAt)}</Badge>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-muted">No marks yet. Finishing a real session unlocks the first one.</p>
        )}
      </Card>
    </div>
  );
}
