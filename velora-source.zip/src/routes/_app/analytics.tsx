import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { MetricBars, MetricLine, MetricMultiLine } from "@/components/charts/spark";
import { Button } from "@/components/ui/button";
import { Badge, Card, ProgressBar, SectionTitle, Select, Stat } from "@/components/ui/primitives";
import {
  powerCurve,
  trainingLoadSeries,
  trainingStatus,
  trendDelta,
  weeklyAvgPower,
} from "@/lib/fitness/analytics";
import {
  allTimeMmp,
  blockZonePower,
  cadenceHistogram,
  compareRides,
  criticalPower,
  eftpFromMmp,
  efficiencyFactor,
  estimateLthr,
  fosterMonotony,
  intensityDistribution,
  rampRate,
  recoveryHr1min,
  ridePhysics,
  weeklyEf,
  weeklyTss,
  ytdTotals,
} from "@/lib/fitness/advanced";
import { analyzeHrBlock, analyzeHrRide } from "@/lib/fitness/hr";
import { signedPct } from "@/lib/fitness/format";
import { useFitnessStore } from "@/lib/fitness/store";
import { hrZones, HR_ZONE_COLORS, POWER_ZONE_COLORS, powerZones, zonesReady } from "@/lib/fitness/zones";

export const Route = createFileRoute("/_app/analytics")({
  component: Analytics,
});

const TABS = ["Overview", "Power", "Heart rate", "Cadence", "Load", "Compare"] as const;

function Analytics() {
  const [tab, setTab] = useState<(typeof TABS)[number]>("Overview");
  const workouts = useFitnessStore((s) => s.workouts);
  const profile = useFitnessStore((s) => s.profile);
  const goals = useFitnessStore((s) => s.goals);
  const sorted = useMemo(
    () => [...workouts].sort((a, b) => +new Date(b.startTime) - +new Date(a.startTime)),
    [workouts],
  );
  const last = sorted[0];
  const load = useMemo(() => trainingLoadSeries(workouts), [workouts]);
  const status = trainingStatus(load);
  const weeks = weeklyAvgPower(workouts);
  const delta = trendDelta(workouts);
  const curve = last ? powerCurve(last.series) : [];
  const hz = hrZones(profile);
  const pz = powerZones(profile.ftp);
  const lastHr = last ? analyzeHrRide(last.series, profile) : null;
  const blockHr = analyzeHrBlock(workouts, profile);
  const mmp = useMemo(() => allTimeMmp(workouts), [workouts]);
  const eftp = eftpFromMmp(mmp);
  const cp = criticalPower(mmp);
  const lastPhy = last ? ridePhysics(last, profile.weightKg, profile.ftp) : null;
  const dist = intensityDistribution(blockZonePower(workouts));
  const cadHist = last ? cadenceHistogram(last.series) : [];
  const lthr = estimateLthr(workouts, profile.ftp);
  const recHr = last ? recoveryHr1min(last.series) : null;
  const efSeries = weeklyEf(sorted);
  const weekTss = weeklyTss(workouts);
  const ytd = ytdTotals(workouts);
  const foster = fosterMonotony(load.slice(-7).map((p) => p.tss));
  const ramp = load.length >= 8 ? rampRate(load[load.length - 1].ctl, load[load.length - 8].ctl) : 0;
  const pmc = load.map((p) => ({ t: p.date.slice(5), ctl: p.ctl, atl: p.atl, tsb: p.tsb }));
  const weekRides = workouts.filter((w) => Date.now() - +new Date(w.startTime) < 7 * 86400000).length;
  const [aId, setAId] = useState("");
  const [bId, setBId] = useState("");
  const cmp = useMemo(() => {
    const a = workouts.find((w) => w.id === (aId || sorted[0]?.id));
    const b = workouts.find((w) => w.id === (bId || sorted[1]?.id));
    if (!a || !b || a.id === b.id) return null;
    return compareRides(a, b, profile);
  }, [workouts, aId, bId, sorted, profile]);

  if (!workouts.length) {
    return (
      <div className="stagger-in space-y-6">
        <header>
          <p className="text-sm text-muted">Deterministic engine · not generated</p>
          <h1 className="font-display text-3xl font-medium tracking-display">Analytics</h1>
        </header>
        <Card className="space-y-3">
          <SectionTitle title="No rides to analyse" />
          <p className="text-sm text-muted">
            CTL, ATL, TSS, power curve, cadence, and HR zones stay empty until you finish a session
            on the RPM600. Nothing here is preloaded.
          </p>
          <Link to="/devices">
            <Button variant="secondary">Connect bike</Button>
          </Link>
        </Card>
      </div>
    );
  }

  return (
    <div className="stagger-in space-y-6">
      <header>
        <p className="text-sm text-muted">From completed rides only</p>
        <h1 className="font-display text-3xl font-medium tracking-display">Analytics</h1>
      </header>

      <div className="flex gap-1 overflow-x-auto rounded-xl bg-surface p-1 shadow-[var(--shadow-border)]">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`h-9 shrink-0 rounded-lg px-3 text-xs font-medium transition-[background-color,color] duration-150 ${
              tab === t ? "bg-surface-2 text-fg" : "text-muted"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === "Overview" ? (
        <>
          <Card>
            <div className="flex items-center justify-between">
              <SectionTitle title="Training status" />
              <Badge tone="accent">{status.label}</Badge>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <Stat label="Fitness" value={`${status.fitness}%`} />
              <Stat label="Consistency" value={`${status.consistency}%`} />
              <Stat label="Recovery" value={`${status.recovery}%`} />
            </div>
          </Card>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Card>
              <Stat
                label="FTP"
                value={profile.ftp || "—"}
                unit={profile.ftp ? "W" : undefined}
                accent={!!profile.ftp}
                hint={eftp && profile.ftp ? `eFTP ${eftp} W` : eftp ? `eFTP ${eftp} W from 20 min` : undefined}
              />
            </Card>
            <Card>
              <Stat label="Power trend" value={workouts.length >= 4 ? signedPct(delta) : "—"} hint={workouts.length >= 4 ? undefined : "Need 4 rides"} />
            </Card>
            <Card><Stat label="Rides" value={workouts.length} /></Card>
            <Card><Stat label="Last NP" value={last?.summary.np ?? "—"} unit="W" /></Card>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Card><Stat label="YTD hours" value={ytd.hours} /></Card>
            <Card><Stat label="YTD km" value={ytd.km.toFixed(1)} /></Card>
            <Card><Stat label="YTD TSS" value={ytd.tss} /></Card>
            <Card><Stat label="YTD work" value={ytd.kj || "—"} unit={ytd.kj ? "kJ" : undefined} /></Card>
          </div>
          {lastPhy ? (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Card><Stat label="Last VI" value={lastPhy.vi || "—"} hint="NP ÷ avg" /></Card>
              <Card><Stat label="Last work" value={lastPhy.workKj || "—"} unit={lastPhy.workKj ? "kJ" : undefined} /></Card>
              <Card>
                <Stat
                  label="Last W/kg"
                  value={lastPhy.wPerKg || "—"}
                  hint={lastPhy.wPerKg ? undefined : "Set weight"}
                />
              </Card>
              <Card>
                <Stat
                  label="This week"
                  value={`${weekRides}/${goals.weeklyWorkouts || "—"}`}
                  hint="rides vs goal"
                />
              </Card>
            </div>
          ) : null}
          {weeks.length ? (
            <Card>
              <SectionTitle title="Weekly average power" />
              <MetricBars data={weeks.map((w) => ({ t: w.label, v: w.watts }))} />
            </Card>
          ) : null}
        </>
      ) : null}

      {tab === "Power" ? (
        <>
          <div className="grid grid-cols-3 gap-3">
            <Card><Stat label="Last avg" value={last?.summary.avgPower ?? "—"} unit="W" /></Card>
            <Card><Stat label="Last peak" value={last?.summary.maxPower ?? "—"} unit="W" accent /></Card>
            <Card><Stat label="Last NP" value={last?.summary.np ?? "—"} unit="W" /></Card>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <Card><Stat label="eFTP" value={eftp || "—"} unit={eftp ? "W" : undefined} hint="Best 20 min × 0.95" /></Card>
            <Card><Stat label="CP" value={cp.cp || "—"} unit={cp.cp ? "W" : undefined} hint={cp.cp ? `W′ ${cp.wPrime} J` : "Need 3 MMP durations"} /></Card>
            <Card><Stat label="IF last" value={last?.summary.if_ ? last.summary.if_.toFixed(2) : "—"} /></Card>
          </div>
          {curve.some((c) => c.watts) ? (
            <Card>
              <SectionTitle title="Mean max · last ride" />
              <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
                {curve.filter((c) => c.watts > 0).map((c) => (
                  <div key={c.key} className="rounded-lg bg-surface-2 px-2 py-3 text-center">
                    <div className="font-display text-lg tabular text-accent">{c.watts}</div>
                    <div className="text-[11px] text-subtle">{c.key}</div>
                  </div>
                ))}
              </div>
            </Card>
          ) : null}
          {mmp.some((m) => m.watts) ? (
            <Card>
              <SectionTitle title="All-time mean max" />
              <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
                {mmp.filter((c) => c.watts > 0).map((c) => (
                  <div key={c.key} className="rounded-lg bg-surface-2 px-2 py-3 text-center">
                    <div className="font-display text-lg tabular text-accent">{c.watts}</div>
                    <div className="text-[11px] text-subtle">{c.key}</div>
                    {profile.weightKg >= 30 ? (
                      <div className="text-[10px] text-muted">{(c.watts / profile.weightKg).toFixed(2)} W/kg</div>
                    ) : null}
                  </div>
                ))}
              </div>
            </Card>
          ) : null}
          {profile.ftp > 0 ? (
            <Card>
              <SectionTitle title={`Power zones · ${dist.label}`} />
              <div className="mb-4 grid grid-cols-3 gap-3 text-center">
                <div>
                  <div className="font-display text-xl tabular">{dist.lowPct}%</div>
                  <div className="text-[11px] text-subtle">Z1–Z2</div>
                </div>
                <div>
                  <div className="font-display text-xl tabular">{dist.midPct}%</div>
                  <div className="text-[11px] text-subtle">Z3</div>
                </div>
                <div>
                  <div className="font-display text-xl tabular">{dist.highPct}%</div>
                  <div className="text-[11px] text-subtle">Z4+</div>
                </div>
              </div>
              <div className="space-y-2">
                {pz.map((z, i) => {
                  const total = blockZonePower(workouts).reduce((a, b) => a + b, 0) || 1;
                  const pct = Math.round((blockZonePower(workouts)[i] / total) * 100);
                  return (
                    <div key={z.id}>
                      <div className="mb-1 flex justify-between text-xs">
                        <span className="text-muted">Z{z.id} {z.name}</span>
                        <span className="tabular">{pct}%</span>
                      </div>
                      <div className="h-1.5 overflow-hidden rounded-full" style={{ background: "var(--surface-3)" }}>
                        <div className="h-full" style={{ width: `${pct}%`, background: POWER_ZONE_COLORS[i] }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>
          ) : (
            <Card>
              <p className="text-sm text-muted">Set FTP in Profile to classify Coggan zones and intensity distribution.</p>
            </Card>
          )}
          {weeks.length ? (
            <Card>
              <SectionTitle title="Four-week power" />
              <MetricLine
                data={weeks.map((w) => ({ t: w.label, v: w.watts }))}
                height={200}
              />
              <p className="mt-3 text-sm text-muted">
                {workouts.length >= 4
                  ? `Power change ${signedPct(delta)} across the last month of indoor work.`
                  : "Need four rides before a trend is computed."}
              </p>
            </Card>
          ) : null}
        </>
      ) : null}

      {tab === "Heart rate" ? (
        lastHr && lastHr.captured ? (
          <>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Card><Stat label="Last avg" value={lastHr.avg} unit="bpm" /></Card>
              <Card><Stat label="Last max" value={lastHr.max} unit="bpm" accent /></Card>
              <Card><Stat label="TRIMP" value={lastHr.trimp || "—"} hint={lastHr.trimp ? undefined : "Need rest + max HR"} /></Card>
              <Card><Stat label="Coverage" value={`${lastHr.coveragePct}%`} /></Card>
            </div>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Card>
                <Stat
                  label="Cardiac drift"
                  value={lastHr.driftPct == null ? "—" : `${lastHr.driftPct > 0 ? "+" : ""}${lastHr.driftPct}%`}
                  hint="HR change, first vs last third"
                />
              </Card>
              <Card>
                <Stat
                  label="Aerobic decoupling"
                  value={lastHr.decouplingPct == null ? "—" : `${lastHr.decouplingPct > 0 ? "+" : ""}${lastHr.decouplingPct}%`}
                  hint="HR:watt ratio, first vs last third"
                />
              </Card>
              <Card>
                <Stat
                  label="EF"
                  value={last && last.summary.avgHeartRate >= 30 ? efficiencyFactor(last.summary.np, last.summary.avgHeartRate) : "—"}
                  hint="NP ÷ avg HR"
                />
              </Card>
              <Card>
                <Stat
                  label="1-min drop"
                  value={recHr == null ? "—" : recHr}
                  unit={recHr == null ? undefined : "bpm"}
                  hint={recHr == null ? "Needs a cooldown in the file" : "After last working watts"}
                />
              </Card>
            </div>
            {lthr ? (
              <Card><Stat label="Est. LTHR" value={lthr} unit="bpm" hint="HR while riding 91–105% FTP. Not a lab test." /></Card>
            ) : null}
            <Card>
              <SectionTitle title="Time in zone · last ride" />
              {zonesReady(hz) ? (
                <div className="space-y-3">
                  {hz.map((z, i) => {
                    const pct = lastHr.timeInZonePct[i];
                    return (
                      <div key={z.id}>
                        <div className="mb-1 flex justify-between text-xs">
                          <span className="text-muted">
                            Z{z.id} {z.name} · {z.lo}–{z.hi}
                          </span>
                          <span className="tabular">{pct.toFixed(0)}%</span>
                        </div>
                        <ProgressBar value={pct} />
                        <div
                          className="mt-1 h-1.5 overflow-hidden rounded-full"
                          style={{ background: "var(--surface-3)" }}
                        >
                          <div
                            className="h-full"
                            style={{ width: `${pct}%`, background: HR_ZONE_COLORS[i] }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <p className="text-sm text-muted">Set max HR in Profile to classify zones.</p>
              )}
              <p className="mt-3 text-sm text-muted">{lastHr.note}</p>
            </Card>
            {efSeries.length > 1 ? (
              <Card>
                <SectionTitle title="Efficiency factor" />
                <MetricLine data={efSeries} height={180} />
                <p className="mt-2 text-xs text-muted">Rising EF on similar Z2 work usually means aerobic gain.</p>
              </Card>
            ) : null}
            <Card>
              <SectionTitle title="HR block" />
              <p className="text-sm text-muted">{blockHr.note}</p>
              {blockHr.rides ? (
                <div className="mt-3 grid grid-cols-3 gap-3">
                  <Stat label="Rides with HR" value={blockHr.rides} />
                  <Stat label="Block avg" value={blockHr.avg} unit="bpm" />
                  <Stat label="Block max" value={blockHr.max} unit="bpm" />
                </div>
              ) : null}
            </Card>
          </>
        ) : (
          <Card className="space-y-3">
            <SectionTitle title="No heart rate captured" />
            <p className="text-sm text-muted">
              Indoor Bike Data does not include heart rate. Velora does not estimate HR from watts.
              Connect FS-583ADC and hold the pulse grips (0x180D / 0x2A37).
            </p>
          </Card>
        )
      ) : null}

      {tab === "Cadence" ? (
        last ? (
          <>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Card><Stat label="Avg" value={last.summary.avgCadence} unit="rpm" /></Card>
              <Card><Stat label="Max" value={last.summary.maxCadence} unit="rpm" accent /></Card>
              <Card><Stat label="At peak W" value={lastPhy?.cadenceAtPeak || "—"} unit={lastPhy?.cadenceAtPeak ? "rpm" : undefined} /></Card>
              <Card>
                <Stat
                  label="Near FTP"
                  value={lastPhy?.cadenceNearFtp || "—"}
                  unit={lastPhy?.cadenceNearFtp ? "rpm" : undefined}
                  hint={lastPhy?.cadenceNearFtp ? undefined : "Need FTP + time at FTP"}
                />
              </Card>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Card>
                <Stat label="80–95 rpm" value={lastPhy ? `${lastPhy.sweetCadencePct}%` : "—"} hint="Time in sweet cadence" />
              </Card>
              <Card>
                <Stat label="Coasting" value={lastPhy ? `${lastPhy.coastPct}%` : "—"} hint="Power under 15 W" />
              </Card>
            </div>
            <Card>
              <SectionTitle title="Cadence distribution · last ride" />
              {cadHist.some((b) => b.sec) ? (
                <MetricBars
                  data={cadHist.map((b) => ({ t: b.label, v: Math.round(b.sec / 60) }))}
                  height={180}
                />
              ) : (
                <p className="text-sm text-muted">No pedaling samples on the last ride.</p>
              )}
              <p className="mt-2 text-xs text-muted">Minutes per cadence bin. Coasting (near-zero watts) is excluded.</p>
            </Card>
          </>
        ) : null
      ) : null}

      {tab === "Load" ? (
        <>
          <div className="grid grid-cols-3 gap-3">
            <Card><Stat label="CTL" value={status.ctl.toFixed(1)} hint="Fitness · Banister 42d" /></Card>
            <Card><Stat label="ATL" value={status.atl.toFixed(1)} hint="Fatigue · Banister 7d" /></Card>
            <Card><Stat label="TSB" value={status.tsb.toFixed(1)} hint="Form" accent /></Card>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <Card><Stat label="Ramp" value={`${ramp > 0 ? "+" : ""}${ramp}`} hint="CTL vs 7 days ago" /></Card>
            <Card><Stat label="Monotony" value={foster.monotony || "—"} hint="Foster · 7-day TSS" /></Card>
            <Card><Stat label="Strain" value={foster.strain || "—"} /></Card>
          </div>
          {pmc.length ? (
            <Card>
              <SectionTitle title="Performance manager" />
              <MetricMultiLine
                data={pmc}
                series={[
                  { key: "ctl", color: "#7EC8C0", name: "CTL" },
                  { key: "atl", color: "#E07A6A", name: "ATL" },
                  { key: "tsb", color: "#D4B483", name: "TSB" },
                ]}
                height={220}
              />
              <p className="mt-2 text-xs text-muted">CTL fitness · ATL fatigue · TSB form. Starts at 0 on first ride.</p>
            </Card>
          ) : null}
          {load.length ? (
            <Card>
              <SectionTitle title="Daily TSS" />
              <MetricBars data={load.map((p) => ({ t: p.date.slice(8), v: p.tss }))} height={160} />
            </Card>
          ) : null}
          <Card>
            <SectionTitle title="Weekly TSS" />
            <MetricBars data={weekTss.map((w) => ({ t: w.label, v: w.tss }))} />
            <div className="mt-3 grid grid-cols-4 gap-2 text-center text-xs">
              {weekTss.map((w) => (
                <div key={w.label}>
                  <div className="text-muted">{w.rides} rides</div>
                  <div className="tabular text-subtle">{w.hours} h</div>
                </div>
              ))}
            </div>
            <p className="mt-2 text-xs text-muted">
              Ride-count goal {goals.weeklyWorkouts || "not set"} / week. No invented TSS target.
            </p>
          </Card>
        </>
      ) : null}

      {tab === "Compare" ? (
        workouts.length < 2 ? (
          <Card>
            <p className="text-sm text-muted">Need two finished rides to compare.</p>
          </Card>
        ) : (
          <>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <div className="mb-1 text-xs text-muted">Ride A</div>
                <Select value={aId || sorted[0].id} onChange={(e) => setAId(e.target.value)}>
                  {sorted.map((w) => (
                    <option key={w.id} value={w.id}>
                      {w.name} · {w.startTime.slice(0, 10)}
                    </option>
                  ))}
                </Select>
              </div>
              <div>
                <div className="mb-1 text-xs text-muted">Ride B</div>
                <Select value={bId || sorted[1].id} onChange={(e) => setBId(e.target.value)}>
                  {sorted.map((w) => (
                    <option key={w.id} value={w.id}>
                      {w.name} · {w.startTime.slice(0, 10)}
                    </option>
                  ))}
                </Select>
              </div>
            </div>
            {cmp ? (
              <Card>
                <SectionTitle title={`${cmp.a.name} vs ${cmp.b.name}`} />
                <div className="space-y-2">
                  {cmp.rows.map((r) => (
                    <div key={r.label} className="grid grid-cols-3 items-center gap-2 text-sm">
                      <span className="text-muted">{r.label}</span>
                      <span className={`tabular ${r.better === "a" ? "text-accent" : ""}`}>{r.a}</span>
                      <span className={`tabular ${r.better === "b" ? "text-accent" : ""}`}>{r.b}</span>
                    </div>
                  ))}
                </div>
              </Card>
            ) : (
              <p className="text-sm text-muted">Pick two different rides.</p>
            )}
          </>
        )
      ) : null}
    </div>
  );
}
