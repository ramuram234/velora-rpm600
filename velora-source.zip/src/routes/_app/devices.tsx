import { createFileRoute } from "@tanstack/react-router";
import { Bluetooth, Download, Heart } from "lucide-react";
import { useEffect, useState } from "react";
import { Button, buttonVariants } from "@/components/ui/button";
import { Badge, Card } from "@/components/ui/primitives";
import {
  bleAvailable,
  canUseWebBluetooth,
  isNativeApp,
  looksLikeHr,
  scanBikes,
  type ScannedBike,
} from "@/lib/fitness/ble";
import { RPM600 } from "@/lib/fitness/seed";
import { useFitnessStore } from "@/lib/fitness/store";

export const Route = createFileRoute("/_app/devices")({
  component: DevicesPage,
});

const SERVICES = [
  { id: "0x1826", name: "Fitness Machine", detail: "FTMS Indoor Bike" },
  { id: "0x2AD2", name: "Indoor Bike Data", detail: "Speed, cadence, power, distance — no HR in flags 0x0954" },
  { id: "0x2ACC", name: "Fitness Machine Feature", detail: "Capability flags" },
  { id: "0x2AD6", name: "Supported Resistance Range", detail: "73–91 internal units · knob is still manual" },
  { id: "0x2AD9", name: "Control Point", detail: "Ignored · manual knob" },
  { id: "0x180D", name: "Heart Rate", detail: "0x2A37 Heart Rate Measurement · READ + NOTIFY" },
  { id: "0x2A37", name: "Heart Rate Measurement", detail: "0 bpm at rest, updates while you pedal · nRF: Sensor Contact not supported" },
  { id: "0x180F", name: "Battery", detail: "0x2A19 Battery Level" },
  { id: "0x180A", name: "Device Information", detail: "JIANJIA JJ-BLE" },
];

function DevicesPage() {
  const connection = useFitnessStore((s) => s.connection);
  const battery = useFitnessStore((s) => s.deviceBattery);
  const deviceHr = useFitnessStore((s) => s.deviceHr);
  const bikeHasHr = useFitnessStore((s) => s.bikeHasHr);
  const hrStreaming = useFitnessStore((s) => s.hrStreaming);
  const deviceName = useFitnessStore((s) => s.deviceName);
  const bleError = useFitnessStore((s) => s.bleError);
  const connect = useFitnessStore((s) => s.connectDevice);
  const disconnect = useFitnessStore((s) => s.disconnectDevice);
  const hrConnection = useFitnessStore((s) => s.hrConnection);
  const hrDeviceName = useFitnessStore((s) => s.hrDeviceName);
  const connectHr = useFitnessStore((s) => s.connectHr);
  const disconnectHr = useFitnessStore((s) => s.disconnectHr);
  const [native, setNative] = useState(false);
  const [webBt, setWebBt] = useState(false);
  const [found, setFound] = useState<ScannedBike[]>([]);
  const [scanning, setScanning] = useState(false);

  useEffect(() => {
    setNative(isNativeApp());
    setWebBt(canUseWebBluetooth());
  }, []);

  async function scan() {
    setScanning(true);
    try {
      setFound(await scanBikes());
    } finally {
      setScanning(false);
    }
  }

  const radio = native || webBt;
  const paired = connection === "connected";
  const hrFromBike = paired && (bikeHasHr || hrStreaming);
  const hrPulse = deviceHr >= 30;
  const hrResting = hrStreaming && deviceHr === 0;

  return (
    <div className="stagger-in space-y-6">
      <header>
        <p className="text-sm text-muted">
          {radio
            ? "Live FTMS + Heart Rate link to the RPM600. The app reads watts and BPM; it does not turn the knob."
            : "This preview cannot reach Bluetooth. Install the Android app on your phone, next to the bike."}
        </p>
        <h1 className="font-display text-3xl font-medium tracking-display">Devices</h1>
      </header>

      {!native ? (
        <Card className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="font-medium">Android APK</div>
            <p className="mt-1 text-sm text-muted">
              Sideload Velora on your phone, allow Bluetooth, and pair FS-583ADC. Connecting the bike
              also enables Heart Rate Measurement.
            </p>
          </div>
          <a href="/velora-rpm600.apk" download className={buttonVariants()}>
            <Download className="size-4" />
            Download APK
          </a>
        </Card>
      ) : null}

      <Card>
        <div className="flex items-start gap-3">
          <div className="flex size-12 items-center justify-center rounded-lg bg-surface-2 text-accent">
            <Bluetooth className="size-5" />
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between gap-2">
              <div className="font-medium">{paired ? deviceName || RPM600.name : "Not paired"}</div>
              <Badge tone={paired ? "good" : "muted"}>
                {paired ? "Connected" : connection}
              </Badge>
            </div>
            <p className="mt-1 text-sm text-muted">
              Look for <span className="text-fg">FS-583ADC</span> · {RPM600.manufacturer} {RPM600.model}
            </p>
            <p className="mt-1 text-xs text-subtle">
              Resistance: MANUAL. Indoor Bike Data has power, cadence, speed. Heart rate comes from
              the bike’s own 0x180D service — not from that packet.
            </p>
            <div className="mt-4 grid grid-cols-2 gap-3">
              <div>
                <div className="font-display text-2xl tabular">
                  {hrPulse || hrResting || hrStreaming ? deviceHr : "—"}
                </div>
                <div className="text-xs text-muted">
                  {hrPulse
                    ? "bpm · Heart Rate Measurement"
                    : hrResting || hrStreaming
                      ? "bpm at rest · updates when you pedal"
                      : paired
                        ? bikeHasHr
                          ? "0x2A37 on · waiting for first packet"
                          : "Waiting for Heart Rate service"
                        : "HR unknown until the bike is connected"}
                </div>
              </div>
              <div>
                <div className="font-display text-2xl tabular">{battery > 0 ? `${Math.round(battery)}%` : "—"}</div>
                <div className="text-xs text-muted">
                  {battery > 0 ? "Battery from 0x180F" : "Battery unknown until the bike streams it"}
                </div>
              </div>
            </div>
            {bleError ? <p className="mt-2 text-sm text-danger">{bleError}</p> : null}
            <div className="mt-4 flex flex-wrap gap-2">
              {paired ? (
                <Button variant="secondary" onClick={disconnect}>
                  Disconnect bike
                </Button>
              ) : native ? (
                <Button variant="secondary" disabled={scanning} onClick={() => void scan()}>
                  {scanning ? "Scanning…" : "Scan nearby"}
                </Button>
              ) : webBt ? (
                <>
                  <Button disabled={!bleAvailable()} onClick={() => void connect()}>
                    {connection === "connecting" ? "Pairing…" : "Pair RPM600"}
                  </Button>
                  <Button variant="secondary" onClick={() => void connect({ acceptAll: true })}>
                    All devices
                  </Button>
                </>
              ) : (
                <Button disabled>Bluetooth unavailable here</Button>
              )}
            </div>
          </div>
        </div>
      </Card>

      <Card>
        <div className="flex items-start gap-3">
          <div className="flex size-12 items-center justify-center rounded-lg bg-surface-2 text-accent">
            <Heart className="size-5" />
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between gap-2">
              <div className="font-medium">
                {hrConnection === "connected" ? hrDeviceName || "Chest strap" : "Optional chest strap"}
              </div>
              <Badge tone={hrConnection === "connected" ? "good" : hrFromBike ? "good" : "muted"}>
                {hrConnection === "connected"
                  ? "Strap streaming"
                  : hrFromBike
                    ? "Using bike HR"
                    : "Not needed"}
              </Badge>
            </div>
            <p className="mt-1 text-sm text-muted">
              The RPM600 already has Heart Rate Measurement. Connecting the bike writes CCCD on
              0x2A37, same as Battery Level. Pair a Polar / Wahoo / Coospo strap only if you want
              a chest sensor instead of the handlebar grips.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              {hrConnection === "connected" ? (
                <Button variant="secondary" onClick={disconnectHr}>
                  Disconnect strap
                </Button>
              ) : native ? (
                <Button variant="secondary" disabled={scanning} onClick={() => void scan()}>
                  {scanning ? "Scanning…" : "Scan for a strap"}
                </Button>
              ) : (
                <p className="text-xs text-subtle">Strap pairing is in the Android APK. Bike HR works on connect.</p>
              )}
            </div>
          </div>
        </div>
      </Card>

      {native && found.length ? (
        <ul className="space-y-2">
          {found.map((d) => (
            <li key={d.id}>
              <Card className="flex items-center justify-between gap-3 py-3">
                <div>
                  <div className="text-sm font-medium">{d.name}</div>
                  <div className="text-[11px] text-subtle">
                    {looksLikeHr(d.name) ? "Looks like a chest strap" : "BLE device · use Bike for FS-583ADC"}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="secondary" onClick={() => void connect({ deviceId: d.id, name: d.name })}>
                    Bike
                  </Button>
                  <Button size="sm" variant="secondary" onClick={() => void connectHr({ deviceId: d.id, name: d.name })}>
                    Strap
                  </Button>
                </div>
              </Card>
            </li>
          ))}
        </ul>
      ) : null}

      <div className="space-y-2">
        {SERVICES.map((s) => (
          <Card key={s.id} className="flex items-center justify-between gap-3 py-3">
            <div>
              <div className="text-sm font-medium">{s.name}</div>
              <div className="text-xs text-muted">{s.detail}</div>
            </div>
            <span className="font-mono text-[11px] text-accent">{s.id}</span>
          </Card>
        ))}
      </div>
    </div>
  );
}
