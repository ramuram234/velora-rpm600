import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, Input } from "@/components/ui/primitives";
import { askCoach } from "@/lib/ai/ask";
import { coachContext } from "@/lib/ai/context";
import { useFitnessStore } from "@/lib/fitness/store";
import { validatePlan } from "@/lib/fitness/workouts";

export const Route = createFileRoute("/_app/coach")({
  component: CoachPage,
});

const PRESETS = [
  { label: "What should I ride today?", mode: "chat" as const },
  { label: "Build a 40 min endurance", mode: "workout" as const },
  { label: "Am I overreaching?", mode: "chat" as const },
];

function CoachPage() {
  const chat = useFitnessStore((s) => s.chat);
  const addChat = useFitnessStore((s) => s.addChat);
  const addPlan = useFitnessStore((s) => s.addPlan);
  const customPlans = useFitnessStore((s) => s.customPlans);
  const start = useFitnessStore((s) => s.startWorkout);
  const workouts = useFitnessStore((s) => s.workouts);
  const ftp = useFitnessStore((s) => s.profile.ftp);
  const navigate = useNavigate();
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [source, setSource] = useState<string | null>(null);

  async function send(prompt: string, mode: "chat" | "workout" = "chat") {
    const q = prompt.trim();
    if (!q || busy) return;
    setBusy(true);
    setErr(null);
    addChat("user", q);
    setText("");
    const res = await askCoach({
      data: { prompt: q, context: coachContext(useFitnessStore.getState()), mode },
    });
    setBusy(false);
    if (!res.ok) {
      setErr(res.error);
      addChat("coach", res.error);
      return;
    }
    setSource(res.source);
    if (mode === "workout") {
      const plan = validatePlan(parseJson(res.text));
      if (plan) {
        addPlan(plan);
        addChat(
          "coach",
          `Built “${plan.name}” — ${Math.round(plan.durationSec / 60)} min, ${plan.intervals.length} blocks. It’s in your library.`,
        );
        return;
      }
      addChat("coach", res.text);
      return;
    }
    addChat("coach", res.text);
  }

  return (
    <div className="flex min-h-[70dvh] flex-col">
      <header className="mb-4">
        <p className="text-sm text-muted">
          Gemini Nano on-device when the phone has it. Otherwise a local engine. Live resistance cues
          stay rule-based.
        </p>
        <h1 className="font-display text-3xl font-medium tracking-display">Coach</h1>
        {source ? (
          <p className="mt-1 text-[11px] uppercase tracking-wide text-accent">
            Last reply · {source === "nano" ? "Gemini Nano" : source === "prompt-api" ? "On-device Prompt API" : source === "cloud" ? "Cloud" : "Local engine"}
          </p>
        ) : null}
      </header>

      <div className="mb-4 flex flex-wrap gap-2">
        {PRESETS.map((p) => (
          <button
            key={p.label}
            className="h-9 rounded-full bg-surface px-3 text-xs text-muted shadow-[var(--shadow-border)] hover:text-fg"
            onClick={() => void send(p.label, p.mode)}
          >
            {p.label}
          </button>
        ))}
      </div>

      <div className="flex-1 space-y-3">
        {!chat.length ? (
          <Card>
            <p className="text-sm text-muted">
              {workouts.length
                ? "Ask about today’s load, generate a structured session, or review power trend. Live cues stay rule-based."
                : ftp > 0
                  ? "No rides on file. I will not invent a training history. Pair the bike, or ask me to build a session from your FTP."
                  : "No rides and no FTP. I will not invent watts or a history. Pair the RPM600, or enter FTP in Profile."}
            </p>
          </Card>
        ) : null}
        {chat.map((m) => (
          <div
            key={m.id}
            className={`max-w-[90%] rounded-xl px-3 py-2.5 text-sm leading-relaxed ${
              m.role === "user" ? "ml-auto bg-fg text-bg" : "bg-surface shadow-[var(--shadow-border)]"
            }`}
          >
            <p className="whitespace-pre-wrap">{m.content}</p>
          </div>
        ))}
        {busy ? <p className="text-sm text-subtle">Reading your file…</p> : null}
        {err ? <p className="text-sm text-danger">{err}</p> : null}
      </div>

      <form
        className="sticky bottom-20 mt-4 flex gap-2 bg-bg py-2 lg:bottom-4"
        onSubmit={(e) => {
          e.preventDefault();
          const workout = /create|build|generate|workout|session/i.test(text);
          void send(text, workout ? "workout" : "chat");
        }}
      >
        <Input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Ask the coach"
          disabled={busy}
        />
        <Button type="submit" disabled={busy || !text.trim()}>
          Send
        </Button>
      </form>

      {customPlans[0] ? (
        <Button
          variant="secondary"
          className="mt-2"
          onClick={() => {
            const plan = customPlans[0];
            if (!plan) return;
            if (!start(plan)) {
              void navigate({ to: "/devices" });
              return;
            }
            void navigate({ to: "/workout/live" });
          }}
        >
          Ride latest generated session
        </Button>
      ) : null}
    </div>
  );
}

function parseJson(text: string) {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  const raw = fenced?.[1] ?? text;
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  if (start < 0 || end < 0) return null;
  try {
    return JSON.parse(raw.slice(start, end + 1)) as unknown;
  } catch {
    return null;
  }
}
