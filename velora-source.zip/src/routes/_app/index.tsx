import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowUpRight, Bike, Footprints, Sparkles } from "lucide-react";
import { SvgSpark } from "@/components/charts/spark";
import { Button } from "@/components/ui/button";
import { Badge, Card, ProgressBar, SectionTitle, Stat } from "@/components/ui/primitives";
import { trainingLoadSeries, trainingStatus } from "@/lib/fitness/analytics";
import { compact, formatDate, formatTime, greeting, todayKey } from "@/lib/fitness/format";
import { weightPlan } from "@/lib/fitness/goals-engine";
import { useFitnessStore } from "@/lib/fitness/store";
import { LIBRARY } from "@/lib/fitness/workouts";

export const Route = createFileRoute("/_app/")({
  component: Home,
});

function Home() {
  const profile = useFitnessStore((s) => s.profile);
  const workouts = useFitnessStore((s) => s.workouts);
  const activity = useFitnessStore((s) => s.activity);
  const connection = useFitnessStore((s) => s.connection);
  const goals = useFitnessStore((s) => s.goals);
  const session = useFitnessStore((s) => s.session);
  const start = useFitnessStore((s) => s.startWorkout);
  const bleError = useFitnessStore((s) => s.bleError);
  const navigate = useNavigate();

  const today = activity.find((d) => d.date === todayKey());
  const last = [...workouts].sort((a, b) => +new Date(b.startTime) - +new Date(a.startTime))[0];
  const load = trainingLoadSeries(workouts);
  const status = trainingStatus(load);
  const spark = (last?.series ?? []).filter((_, i) => i % 4 === 0).map((s) => s.power);
  const weekRides = workouts.filter((w) => Date.now() - +new Date(w.startTime) < 7 * 86400000).length;
  const plan = weightPlan(profile, goals, workouts, activity);

  function ride(plan = LIBRARY[0]) {
    if (!start(plan)) {
      void navigate({ to: "/devices" });
      return;
    }
    void navigate({ to: "/workout/live" });
  }

  return (
    <div className="stagger-in space-y-6">
      <header className="flex items-start justify-between gap-4">
        <div>
          <p className="text-sm text-muted">{greeting()}</p>
          <h1 className="font-display text-3xl font-medium tracking-display">{profile.name || "Rider"}</h1>
        </div>
        <Badge tone={connection === "connected" ? "good" : "muted"}>
          {connection === "connected" ? "Bike live" : "Bike offline"}
        </Badge>
      </header>

      {bleError ? <p className="text-sm text-danger">{bleError}</p> : null}

      {session ? (
        <Link to="/workout/live" className="block">
          <Card className="flex items-center justify-between border border-accent/30 bg-surface-2">
            <div>
              <div className="text-xs uppercase tracking-wide text-accent">Session live</div>
              <div className="mt-1 font-medium">{session.plan.name}</div>
              <div className="text-sm text-muted tabular">{formatTime(session.elapsedSec)}</div>
            </div>
            <Button size="sm">Resume</Button>
          </Card>
        </Link>
      ) : null}

      {!workouts.length ? (
        <Card className="space-y-3">
          <SectionTitle title="No rides yet" />
          <p className="text-sm text-muted">
            History, training load, and PRs stay empty until you finish a session on the RPM600.
            Connect the bike, then start a free ride.
          </p>
          <div className="flex gap-2">
            <Link to="/devices" className="flex-1">
              <Button className="w-full" variant="secondary">Connect bike</Button>
            </Link>
            <Button className="flex-1" onClick={() => ride(LIBRARY[0])}>
              Free ride
            </Button>
          </div>
        </Card>
      ) : (
        <Card>
          <div className="flex items-center justify-between">
            <div className="text-xs uppercase tracking-wide text-subtle">Training status</div>
            <Badge tone={status.label === "overreaching" ? "warn" : "accent"}>{status.label}</Badge>
          </div>
          <div className="mt-4 grid grid-cols-3 gap-4">
            <Meter label="Fitness" value={status.fitness} />
            <Meter label="Consistency" value={status.consistency} />
            <Meter label="Recovery" value={status.recovery} />
          </div>
        </Card>
      )}

      <div className="grid grid-cols-2 gap-3">
        <Card>
          <div className="flex items-center gap-2 text-subtle">
            <Footprints className="size-4" />
            <span className="text-xs uppercase tracking-wide">Steps</span>
          </div>
          <div className="mt-2 font-display text-3xl font-medium tabular tracking-tight">
            {today?.steps ? compact(today.steps) : "—"}
          </div>
          <ProgressBar className="mt-3" value={today?.steps && goals.dailySteps ? (today.steps / goals.dailySteps) * 100 : 0} />
          <div className="mt-2 text-xs text-muted">
            {today?.steps ? `Goal ${goals.dailySteps.toLocaleString()}` : "Phone sensor or Health Connect after you sync"}
          </div>
        </Card>
        <Card>
          <div className="flex items-center gap-2 text-subtle">
            <Bike className="size-4" />
            <span className="text-xs uppercase tracking-wide">Active kcal</span>
          </div>
          <div className="mt-2 font-display text-3xl font-medium tabular tracking-tight">
            {today ? Math.round(today.cycleKcal + today.otherKcal) : "—"}
          </div>
          <div className="mt-3 text-xs text-muted">
            {today ? `Cycling ${Math.round(today.cycleKcal)} · Walk ${Math.round(today.otherKcal)}` : "After a ride or sync"}
          </div>
        </Card>
      </div>

      <Card>
        <SectionTitle title="Cycling today" action={<Link to="/activity" className="text-xs text-muted hover:text-fg">Activity</Link>} />
        <div className="grid grid-cols-3 gap-3">
          <Stat label="Time" value={today ? Math.round(today.cycleMin) : "—"} unit={today ? "min" : undefined} />
          <Stat label="Distance" value={today ? today.cycleKm.toFixed(1) : "—"} unit={today ? "km" : undefined} />
          <Stat label="Avg power" value={last && isToday(last.startTime) ? last.summary.avgPower : "—"} unit={last && isToday(last.startTime) ? "W" : undefined} accent />
        </div>
      </Card>

      {plan && plan.direction !== "hold" ? (
        <Card>
          <SectionTitle title="Weight goal" action={<Link to="/progress" className="text-xs text-muted hover:text-fg">Progress</Link>} />
          <div className="grid grid-cols-3 gap-3">
            <Stat label="Now" value={profile.weightKg.toFixed(1)} unit="kg" />
            <Stat label="Target" value={goals.targetWeightKg.toFixed(1)} unit="kg" accent />
            <Stat
              label={plan.direction === "lose" ? "To lose" : "To gain"}
              value={Math.abs(plan.remainingKg).toFixed(1)}
              unit="kg"
            />
          </div>
          <p className="mt-3 text-xs text-muted">{plan.note}</p>
        </Card>
      ) : null}

      {last ? (
        <Card>
          <SectionTitle title="Last ride" action={<span className="text-xs text-muted">{formatDate(last.startTime)}</span>} />
          {spark.length > 1 ? <SvgSpark values={spark} height={88} /> : null}
          <div className="mt-3 grid grid-cols-3 gap-2 text-center">
            <div>
              <div className="font-mono text-sm tabular text-accent">{last.summary.avgPower} W</div>
              <div className="text-[11px] text-subtle">Avg</div>
            </div>
            <div>
              <div className="font-mono text-sm tabular text-accent">{last.summary.np} W</div>
              <div className="text-[11px] text-subtle">NP</div>
            </div>
            <div>
              <div className="font-mono text-sm tabular text-accent">{last.summary.tss}</div>
              <div className="text-[11px] text-subtle">TSS</div>
            </div>
          </div>
        </Card>
      ) : null}

      {workouts.length ? (
        <Card>
          <SectionTitle title="Readiness" action={<span className="text-xs text-muted">{weekRides}/{goals.weeklyWorkouts} rides this week</span>} />
          <p className="text-sm text-muted">
            CTL {status.ctl.toFixed(0)} · ATL {status.atl.toFixed(0)} · TSB {status.tsb > 0 ? "+" : ""}
            {status.tsb.toFixed(1)} from completed rides only.
          </p>
        </Card>
      ) : null}

      <Link to="/coach" className="block">
        <Card className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex size-11 items-center justify-center rounded-lg bg-surface-2 text-accent">
              <Sparkles className="size-5" />
            </div>
            <div>
              <div className="font-medium">AI Coach</div>
              <div className="text-sm text-muted">Uses your file. Won’t invent rides.</div>
            </div>
          </div>
          <ArrowUpRight className="size-4 text-subtle" />
        </Card>
      </Link>

      {last ? (
        <Link to="/workout/$id" params={{ id: last.id }} className="block">
          <Card>
            <SectionTitle title="Latest workout" />
            <div className="flex items-baseline justify-between">
              <div>
                <div className="font-medium">{last.name}</div>
                <div className="text-sm text-muted">{formatDate(last.startTime)}</div>
              </div>
              <div className="text-right">
                <div className="font-display text-2xl tabular text-accent">{last.summary.avgPower} W</div>
                <div className="text-xs text-muted">
                  {formatTime(last.summary.durationSec)} · {last.summary.distanceKm.toFixed(1)} km
                </div>
              </div>
            </div>
          </Card>
        </Link>
      ) : null}

      <div className="flex gap-3">
        <Link to="/workout" className="flex-1">
          <Button className="w-full" variant="secondary">Workouts</Button>
        </Link>
        <Button className="flex-1" onClick={() => ride(LIBRARY[0])}>
          Free ride
        </Button>
      </div>
    </div>
  );
}

function Meter({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <div className="text-xs text-subtle">{label}</div>
      <div className="mt-1 font-display text-xl tabular">{value}%</div>
      <ProgressBar className="mt-2" value={value} />
    </div>
  );
}

function isToday(iso: string) {
  const d = new Date(iso);
  return todayKey(d) === todayKey();
}
