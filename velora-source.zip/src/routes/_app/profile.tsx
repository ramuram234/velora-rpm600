import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Card, Input, Label, SectionTitle, Select, Stat } from "@/components/ui/primitives";
import { ageFromDob, bmi, bmiLabel, estimateMaxHr } from "@/lib/fitness/format";
import { useFitnessStore } from "@/lib/fitness/store";
import { hrZones, powerZones, zonesReady } from "@/lib/fitness/zones";
import type { FitnessLevel, Sex } from "@/lib/fitness/types";

export const Route = createFileRoute("/_app/profile")({
  component: ProfilePage,
});

function ProfilePage() {
  const profile = useFitnessStore((s) => s.profile);
  const goals = useFitnessStore((s) => s.goals);
  const update = useFitnessStore((s) => s.updateProfile);
  const updateGoals = useFitnessStore((s) => s.updateGoals);
  const hz = hrZones(profile);
  const pz = powerZones(profile.ftp);
  const b = bmi(profile.heightCm, profile.weightKg);
  const tanaka = estimateMaxHr(ageFromDob(profile.dob), profile.sex);

  return (
    <div className="stagger-in space-y-6">
      <header className="flex items-end justify-between">
        <div>
          <p className="text-sm text-muted">Local profile · never uploaded</p>
          <h1 className="font-display text-3xl font-medium tracking-display">{profile.name || "Rider"}</h1>
        </div>
        <Link to="/settings" className="text-sm text-muted hover:text-fg">
          Settings
        </Link>
      </header>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Card>
          <Stat
            label="FTP"
            value={profile.ftp || "—"}
            unit={profile.ftp ? "W" : undefined}
            hint={profile.ftp ? (profile.ftpEstimated ? "Estimate" : "Tested / typed") : "Not set"}
            accent={!!profile.ftp}
          />
        </Card>
        <Card>
          <Stat label="Max HR" value={profile.maxHr || "—"} unit={profile.maxHr ? "bpm" : undefined} />
        </Card>
        <Card>
          <Stat label="Rest HR" value={profile.restingHr || "—"} unit={profile.restingHr ? "bpm" : undefined} />
        </Card>
        <Card>
          <Stat label="BMI" value={b > 0 ? b.toFixed(1) : "—"} hint={b > 0 ? bmiLabel(b) : "Need height & weight"} />
        </Card>
      </div>

      <Card className="space-y-3">
        <SectionTitle title="Personal" />
        <div>
          <Label htmlFor="nm">Name</Label>
          <Input id="nm" className="mt-1.5" value={profile.name} onChange={(e) => update({ name: e.target.value })} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Sex</Label>
            <Select className="mt-1.5" value={profile.sex} onChange={(e) => update({ sex: e.target.value as Sex })}>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </Select>
          </div>
          <div>
            <Label>Date of birth</Label>
            <Input type="date" className="mt-1.5" value={profile.dob} onChange={(e) => update({ dob: e.target.value })} />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Height (cm)</Label>
            <Input type="number" className="mt-1.5" value={profile.heightCm || ""} onChange={(e) => update({ heightCm: Number(e.target.value) })} />
          </div>
          <div>
            <Label>Weight (kg)</Label>
            <Input type="number" step="0.1" className="mt-1.5" value={profile.weightKg || ""} onChange={(e) => update({ weightKg: Number(e.target.value) })} />
          </div>
        </div>
        <p className="text-xs text-muted">BMI is a basic screening measure, not a complete body-composition reading.</p>
      </Card>

      <Card className="space-y-3">
        <SectionTitle title="Engine" />
        <div>
          <Label>Fitness level</Label>
          <Select className="mt-1.5" value={profile.fitnessLevel} onChange={(e) => update({ fitnessLevel: e.target.value as FitnessLevel })}>
            <option value="beginner">Beginner</option>
            <option value="intermediate">Intermediate</option>
            <option value="advanced">Advanced</option>
          </Select>
        </div>
        <div className="grid grid-cols-3 gap-3">
          <div>
            <Label>FTP</Label>
            <Input
              type="number"
              className="mt-1.5"
              value={profile.ftp || ""}
              onChange={(e) => update({ ftp: Number(e.target.value), ftpEstimated: false })}
            />
          </div>
          <div>
            <Label>Resting HR</Label>
            <Input
              type="number"
              className="mt-1.5"
              value={profile.restingHr || ""}
              onChange={(e) => update({ restingHr: Number(e.target.value) })}
            />
          </div>
          <div>
            <Label>Max HR</Label>
            <Input
              type="number"
              className="mt-1.5"
              value={profile.maxHr || ""}
              onChange={(e) => update({ maxHr: Number(e.target.value) })}
            />
          </div>
        </div>
        {tanaka > 0 ? (
          <button type="button" className="text-xs text-accent" onClick={() => update({ maxHr: tanaka })}>
            Use Tanaka estimate {tanaka} bpm
          </button>
        ) : null}
        <p className="text-xs text-muted">A 20-minute FTP test writes a new FTP at 95% of the test-block average.</p>
      </Card>

      <Card className="space-y-3">
        <SectionTitle title="Goals" />
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Target weight</Label>
            <Input type="number" step="0.1" className="mt-1.5" value={goals.targetWeightKg || ""} onChange={(e) => updateGoals({ targetWeightKg: Number(e.target.value) })} />
          </div>
          <div>
            <Label>Weekly rides</Label>
            <Input type="number" className="mt-1.5" value={goals.weeklyWorkouts} onChange={(e) => updateGoals({ weeklyWorkouts: Number(e.target.value) })} />
          </div>
          <div>
            <Label>Daily steps</Label>
            <Input type="number" className="mt-1.5" value={goals.dailySteps} onChange={(e) => updateGoals({ dailySteps: Number(e.target.value) })} />
          </div>
          <div>
            <Label>Focus</Label>
            <Select className="mt-1.5" value={goals.focus} onChange={(e) => updateGoals({ focus: e.target.value as typeof goals.focus })}>
              <option value="ftp">Raise FTP</option>
              <option value="endurance">Endurance</option>
              <option value="weight">Weight</option>
              <option value="consistency">Consistency</option>
            </Select>
          </div>
        </div>
      </Card>

      <Card>
        <SectionTitle title="HR zones" />
        {zonesReady(hz) ? (
          <div className="space-y-2 text-sm">
            {hz.map((z) => (
              <div key={z.id} className="flex justify-between">
                <span className="text-muted">Z{z.id} {z.name}</span>
                <span className="tabular">{z.lo}–{z.hi} bpm</span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-muted">Set max HR to build zones. Nothing is inferred until then.</p>
        )}
      </Card>

      <Card>
        <SectionTitle title="Power zones" />
        {zonesReady(pz) ? (
          <div className="space-y-2 text-sm">
            {pz.map((z) => (
              <div key={z.id} className="flex justify-between">
                <span className="text-muted">Z{z.id} {z.name}</span>
                <span className="tabular">{z.lo}–{z.hi === 2000 ? "∞" : z.hi} W</span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-muted">Set FTP to build Coggan power zones. Library workouts stay %-FTP until then.</p>
        )}
      </Card>

      <div className="flex gap-3">
        <Link to="/devices" className="flex-1"><Button variant="secondary" className="w-full">Devices</Button></Link>
        <Link to="/progress" className="flex-1"><Button variant="secondary" className="w-full">Progress</Button></Link>
      </div>
    </div>
  );
}
