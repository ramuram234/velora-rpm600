import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Minus, Pause, Play, Plus, Square } from "lucide-react";
import { useMemo } from "react";
import { SvgSpark } from "@/components/charts/spark";
import { Button } from "@/components/ui/button";
import { formatTime } from "@/lib/fitness/format";
import { useFitnessStore } from "@/lib/fitness/store";
import { intervalAt } from "@/lib/fitness/workouts";
import { hrZones, zoneForHr } from "@/lib/fitness/zones";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_app/workout/live")({
  component: LiveWorkout,
});

function LiveWorkout() {
  const session = useFitnessStore((s) => s.session);
  const profile = useFitnessStore((s) => s.profile);
  const pause = useFitnessStore((s) => s.pauseWorkout);
  const resume = useFitnessStore((s) => s.resumeWorkout);
  const finish = useFitnessStore((s) => s.finishWorkout);
  const setResistance = useFitnessStore((s) => s.setResistance);
  const navigate = useNavigate();

  const spark = useMemo(
    () => (session ? session.series.slice(-90).map((s) => s.power) : []),
    [session],
  );

  if (!session) {
    return (
      <div className="flex min-h-dvh flex-col items-center justify-center bg-bg px-6 text-center">
        <p className="text-muted">No live session.</p>
        <Button className="mt-4" onClick={() => void navigate({ to: "/workout" })}>
          Choose a workout
        </Button>
      </div>
    );
  }

  const tel = session.telemetry;
  const live = session.source === "ble";
  const loc = intervalAt(session.plan, session.elapsedSec);
  const target = loc.interval.targetPower;
  const inRange = live && target ? tel.power >= target.min && tel.power <= target.max : false;
  const hz = hrZones(profile);
  const z = zoneForHr(tel.heartRate, hz);
  const total = session.plan.kind === "free" ? Math.max(session.elapsedSec + 1, 1) : session.plan.durationSec;
  const progress = Math.min(100, (session.elapsedSec / total) * 100);
  const hrLive = tel.heartRate >= 30;
  const hrStreaming = session.hrSource === "ble" || session.hrSource === "strap";
  const waitingGrips = !hrLive && hrStreaming;

  function endRide() {
    const id = finish();
    if (id) void navigate({ to: "/workout/$id", params: { id } });
    else void navigate({ to: "/workout" });
  }

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <div className="mx-auto flex min-h-dvh max-w-lg flex-col px-4 pb-6 pt-4 sm:max-w-2xl">
        <header className="flex items-center justify-between gap-3">
          <div>
            <div className="text-[11px] uppercase tracking-wide text-subtle">{session.plan.name}</div>
            <div className="font-medium">{loc.interval.label ?? loc.interval.type}</div>
          </div>
          <div className="text-right">
            <div className="font-mono text-lg tabular">{formatTime(session.elapsedSec)}</div>
            <div className="text-[11px] text-muted">
              {session.plan.kind === "free" ? "Free ride" : `${formatTime(loc.remaining)} left in block`}
            </div>
          </div>
        </header>

        <div className="mt-3 h-1 overflow-hidden rounded-full bg-surface-3">
          <div className="h-full bg-accent transition-[width] duration-200 ease-out" style={{ width: `${progress}%` }} />
        </div>
        <IntervalTrack plan={session.plan} elapsed={session.elapsedSec} />

        <div className="mt-6 flex flex-1 flex-col items-center justify-center text-center">
          <div className="text-xs uppercase tracking-[0.2em] text-subtle">Power</div>
          <div
            className={cn(
              "font-display font-medium leading-none tracking-display tabular",
              "text-[88px] sm:text-[104px]",
              inRange ? "text-accent" : "text-fg",
            )}
          >
            {live ? tel.power : "—"}
          </div>
          <div className="mt-1 text-sm text-muted">
            {target
              ? `Target ${target.min}–${target.max} W`
              : profile.ftp > 0
                ? "No target · turn the knob"
                : "No FTP · turn the knob"}
          </div>
          {session.lastCue ? (
            <div
              className={cn(
                "mt-4 rounded-full px-4 py-1.5 text-sm",
                inRange ? "bg-accent/15 text-accent" : "bg-warn/15 text-warn",
              )}
            >
              {session.lastCue}
            </div>
          ) : null}
          {live ? (
            <p className="mt-3 text-center text-xs text-accent">
              Live from the bike
              {session.hrSource === "strap"
                ? " · HR from strap"
                : hrLive
                  ? " · HR from bike 0x2A37"
                  : waitingGrips
                    ? " · HR 0 bpm at rest — pedaling updates it"
                    : " · enabling Heart Rate Measurement"}
            </p>
          ) : (
            <p className="mt-3 text-center text-xs text-warn">
              Waiting for Indoor Bike Data. Watts stay blank until FTMS streams.
            </p>
          )}
        </div>

        <div className="grid grid-cols-3 gap-2">
          <Hud
            label="HR"
            value={hrStreaming ? String(tel.heartRate) : "—"}
            unit={hrLive ? (z ? `Z${z}` : "bpm") : hrStreaming ? "rest" : "bpm"}
          />
          <Hud label="Cadence" value={live ? tel.cadence.toFixed(0) : "—"} unit="rpm" />
          <Hud label="Speed" value={live ? tel.speed.toFixed(1) : "—"} unit="km/h" />
          <Hud label="Distance" value={live || tel.distance > 0 ? (tel.distance / 1000).toFixed(2) : "—"} unit="km" />
          <Hud label="Calories" value={live || tel.calories > 0 ? String(Math.round(tel.calories)) : "—"} unit="kcal" />
          <Hud label="Battery" value={tel.battery > 0 ? String(Math.round(tel.battery)) : "—"} unit="%" />
        </div>

        <div className="mt-4 rounded-xl bg-surface px-3 py-3 shadow-[var(--shadow-border)]">
          {spark.length > 1 ? (
            <SvgSpark values={spark} height={72} />
          ) : (
            <p className="py-6 text-center text-xs text-muted">Power trace starts with the first FTMS packet.</p>
          )}
        </div>

        <div className="mt-4 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs uppercase tracking-wide text-subtle">Knob log · not sent by the bike</div>
              <div className="font-display text-3xl tabular">{session.resistance.toFixed(1)}</div>
            </div>
            <div className="flex gap-2">
              <Button size="icon" variant="secondary" onClick={() => setResistance(session.resistance - 0.5)} aria-label="Decrease logged resistance">
                <Minus className="size-4" />
              </Button>
              <Button size="icon" variant="secondary" onClick={() => setResistance(session.resistance + 0.5)} aria-label="Increase logged resistance">
                <Plus className="size-4" />
              </Button>
            </div>
          </div>
          <input
            type="range"
            min={0}
            max={20}
            step={0.5}
            value={session.resistance}
            onChange={(e) => setResistance(Number(e.target.value))}
            className="mt-3 w-full accent-[var(--accent)]"
          />
          <p className="mt-2 text-xs text-muted">
            The RPM600 resistance is a physical knob. This slider only notes the number you set.
          </p>
        </div>

        <div className="mt-4 flex gap-3">
          {session.status === "paused" ? (
            <Button className="flex-1" onClick={resume}>
              <Play className="size-4" />
              Resume
            </Button>
          ) : (
            <Button className="flex-1" variant="secondary" onClick={pause}>
              <Pause className="size-4" />
              Pause
            </Button>
          )}
          <Button variant="danger" onClick={endRide}>
            <Square className="size-4" />
            End
          </Button>
        </div>
      </div>
    </div>
  );
}

function Hud({ label, value, unit }: { label: string; value: string; unit: string }) {
  return (
    <div className="rounded-lg bg-surface px-3 py-2.5 shadow-[var(--shadow-border)]">
      <div className="text-[10px] uppercase tracking-wide text-subtle">{label}</div>
      <div className="font-display text-xl tabular leading-none">
        {value} <span className="text-[11px] text-muted">{unit}</span>
      </div>
    </div>
  );
}

function IntervalTrack({
  plan,
  elapsed,
}: {
  plan: { durationSec: number; intervals: { durationSec: number }[] };
  elapsed: number;
}) {
  return (
    <div className="relative mt-2 flex h-2 overflow-hidden rounded-full bg-surface-3">
      {plan.intervals.map((iv, i) => (
        <div
          key={i}
          className={i % 2 === 0 ? "bg-accent/35" : "bg-accent/18"}
          style={{ flex: iv.durationSec }}
        />
      ))}
      <div
        className="absolute top-0 h-full w-0.5 bg-fg"
        style={{ left: `${Math.min(100, (elapsed / Math.max(1, plan.durationSec)) * 100)}%` }}
      />
    </div>
  );
}
