import { createFileRoute, Link } from "@tanstack/react-router";
import { Trophy } from "lucide-react";
import { useMemo, useState } from "react";
import { MetricMultiLine } from "@/components/charts/spark";
import { Button } from "@/components/ui/button";
import { Badge, Card, SectionTitle, Stat } from "@/components/ui/primitives";
import { askCoach } from "@/lib/ai/ask";
import { coachContext } from "@/lib/ai/context";
import { powerCurve } from "@/lib/fitness/analytics";
import {
  downsample,
  efficiencyFactor,
  fastestSplit,
  findPlan,
  intervalCompliance,
  recoveryHr1min,
  ridePhysics,
} from "@/lib/fitness/advanced";
import { formatDateLong, formatTime } from "@/lib/fitness/format";
import { useFitnessStore } from "@/lib/fitness/store";
import { hrZones, HR_ZONE_COLORS, POWER_ZONE_COLORS, powerZones } from "@/lib/fitness/zones";

export const Route = createFileRoute("/_app/workout/$id")({
  component: WorkoutSummary,
});

function WorkoutSummary() {
  const { id } = Route.useParams();
  const workouts = useFitnessStore((s) => s.workouts);
  const lastNewRecords = useFitnessStore((s) => s.lastNewRecords);
  const allRecords = useFitnessStore((s) => s.records);
  const profile = useFitnessStore((s) => s.profile);
  const customPlans = useFitnessStore((s) => s.customPlans);
  const addInsight = useFitnessStore((s) => s.addInsight);
  const allInsights = useFitnessStore((s) => s.insights);
  const workout = useMemo(() => workouts.find((w) => w.id === id), [workouts, id]);
  const newOnes = useMemo(() => {
    const fresh = lastNewRecords.filter((r) => r.workoutId === id);
    if (fresh.length) return fresh;
    return allRecords.filter((r) => r.workoutId === id && r.date === workout?.startTime);
  }, [lastNewRecords, allRecords, id, workout?.startTime]);
  const insights = useMemo(
    () => allInsights.filter((i) => i.workoutId === id),
    [allInsights, id],
  );
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const series = useMemo(() => {
    if (!workout) return [];
    return downsample(workout.series, 80).map((p) => ({
      t: formatTime(p.t),
      power: p.power,
      hr: p.heartRate >= 30 ? p.heartRate : 0,
      cad: p.cadence,
      spd: p.speed,
    }));
  }, [workout]);

  const curve = useMemo(
    () => (workout ? powerCurve(workout.series) : []),
    [workout],
  );

  if (!workout) {
    return (
      <div className="py-16 text-center text-muted">
        Workout not found.{" "}
        <Link to="/history" className="text-fg underline">
          History
        </Link>
      </div>
    );
  }

  const s = workout.summary;
  const phy = ridePhysics(workout, profile.weightKg, profile.ftp);
  const plan = findPlan(workout, customPlans);
  const compliance = intervalCompliance(workout, plan, profile.ftp);
  const k1 = fastestSplit(workout.series, 1000);
  const k5 = fastestSplit(workout.series, 5000);
  const recHr = recoveryHr1min(workout.series);
  const ef = s.hrCaptured ? efficiencyFactor(s.np, s.avgHeartRate) : 0;
  const hr = hrZones(profile);
  const pz = powerZones(profile.ftp);
  const hrTotal = s.zoneHr.reduce((a, b) => a + b, 0) || 1;
  const pwTotal = s.zonePower.reduce((a, b) => a + b, 0) || 1;

  async function analyze() {
    if (!workout) return;
    setBusy(true);
    setErr(null);
    const state = useFitnessStore.getState();
    const res = await askCoach({
      data: {
        mode: "insight",
        context: coachContext(state),
        prompt: `Analyze this ride: ${workout.name}, ${formatTime(s.durationSec)}, avg ${s.avgPower}W NP ${s.np}W IF ${s.if_} TSS ${s.tss} avg HR ${s.avgHeartRate} max HR ${s.maxHeartRate} cadence ${s.avgCadence}. Give 3 coaching takeaways.`,
      },
    });
    setBusy(false);
    if (!res.ok) {
      setErr(res.error);
      return;
    }
    addInsight({ workoutId: id, title: "Ride insight", body: res.text });
  }

  return (
    <div className="stagger-in space-y-6">
      <header>
        <p className="text-sm text-muted">{formatDateLong(workout.startTime)}</p>
        <h1 className="font-display text-3xl font-medium tracking-display">{workout.name}</h1>
        <div className="mt-2 flex flex-wrap gap-2">
          <Badge>{workout.kind}</Badge>
          <Badge tone="accent">{s.tss} TSS</Badge>
          <Badge>IF {s.if_.toFixed(2)}</Badge>
        </div>
      </header>

      {newOnes.length ? (
        <Card className="flex items-start gap-3">
          <Trophy className="mt-0.5 size-5 text-accent" />
          <div>
            <div className="font-medium">Personal records</div>
            <ul className="mt-1 space-y-1 text-sm text-muted">
              {newOnes.map((r) => (
                <li key={r.id}>
                  {r.label}: {r.value} {r.unit}
                  {r.previous ? ` · was ${r.previous}` : ""}
                </li>
              ))}
            </ul>
          </div>
        </Card>
      ) : null}

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Card><Stat label="Avg power" value={s.avgPower} unit="W" accent /></Card>
        <Card><Stat label="NP" value={s.np} unit="W" /></Card>
        <Card><Stat label="Avg HR" value={s.hrCaptured ? s.avgHeartRate : "—"} unit={s.hrCaptured ? "bpm" : undefined} /></Card>
        <Card><Stat label="Calories" value={s.calories} unit="kcal" /></Card>
        <Card><Stat label="Duration" value={formatTime(s.durationSec)} /></Card>
        <Card><Stat label="Distance" value={s.distanceKm.toFixed(1)} unit="km" /></Card>
        <Card><Stat label="Cadence" value={s.avgCadence} unit="rpm" /></Card>
        <Card><Stat label="Max power" value={s.maxPower} unit="W" /></Card>
        <Card><Stat label="VI" value={phy.vi || "—"} hint="NP ÷ avg" /></Card>
        <Card><Stat label="Work" value={phy.workKj || "—"} unit={phy.workKj ? "kJ" : undefined} /></Card>
        <Card><Stat label="W/kg" value={phy.wPerKg || "—"} hint={phy.wPerKg ? undefined : "Set weight"} /></Card>
        <Card><Stat label="EF" value={ef || "—"} hint={ef ? "NP ÷ HR" : undefined} /></Card>
      </div>

      <Card>
        <SectionTitle title="Power" />
        {series.length > 1 ? (
          <MetricMultiLine
            data={series}
            series={[{ key: "power", color: "#7EC8C0", name: "W" }]}
            height={200}
          />
        ) : (
          <p className="text-sm text-muted">Not enough samples for a chart.</p>
        )}
      </Card>

      {series.length > 1 && s.hrCaptured ? (
        <Card>
          <SectionTitle title="Heart rate" />
          <MetricMultiLine
            data={series}
            series={[{ key: "hr", color: "#E07A6A", name: "bpm" }]}
            height={160}
          />
        </Card>
      ) : null}

      {series.length > 1 ? (
        <Card>
          <SectionTitle title="Cadence" />
          <MetricMultiLine
            data={series}
            series={[{ key: "cad", color: "#D4B483", name: "rpm" }]}
            height={140}
          />
          <div className="mt-3 grid grid-cols-3 gap-3">
            <Stat label="80–95 rpm" value={`${phy.sweetCadencePct}%`} />
            <Stat label="Coasting" value={`${phy.coastPct}%`} />
            <Stat label="At peak W" value={phy.cadenceAtPeak || "—"} unit={phy.cadenceAtPeak ? "rpm" : undefined} />
          </div>
        </Card>
      ) : null}

      <Card>
        <SectionTitle title="Mean max power" />
        <div className="grid grid-cols-4 gap-2 sm:grid-cols-8">
          {curve.filter((c) => c.watts > 0).map((c) => (
            <div key={c.key} className="rounded-lg bg-surface-2 px-2 py-2 text-center">
              <div className="font-mono text-sm tabular text-accent">{c.watts}</div>
              <div className="text-[10px] text-subtle">{c.key}</div>
            </div>
          ))}
        </div>
      </Card>

      {(k1 || k5 || recHr != null) ? (
        <Card>
          <SectionTitle title="Splits & recovery" />
          <div className="grid grid-cols-3 gap-3">
            <Stat label="Fastest 1 km" value={k1 ? formatTime(k1.sec) : "—"} hint={k1 ? `${k1.watts} W` : "Need 1 km in file"} />
            <Stat label="Fastest 5 km" value={k5 ? formatTime(k5.sec) : "—"} hint={k5 ? `${k5.watts} W` : undefined} />
            <Stat label="1-min HR drop" value={recHr == null ? "—" : recHr} unit={recHr == null ? undefined : "bpm"} />
          </div>
        </Card>
      ) : null}

      {compliance ? (
        <Card>
          <SectionTitle title="Vs plan" />
          {compliance.overallPct != null ? (
            <p className="mb-3 text-sm text-muted">
              {compliance.overallPct}% of targeted intervals inside the watt window.
            </p>
          ) : (
            <p className="mb-3 text-sm text-muted">
              Set FTP to score watt-window compliance. Cadence still logged.
            </p>
          )}
          <div className="space-y-2">
            {compliance.rows.map((r, i) => (
              <div key={`${r.label}-${i}`} className="flex items-center justify-between gap-2 text-sm">
                <span className="min-w-0 truncate text-muted">{r.label}</span>
                <span className="tabular">
                  {r.avgPower} W
                  {r.targetMin != null ? ` · ${r.targetMin}–${r.targetMax}` : ""}
                  {r.inRangePct != null ? ` · ${r.inRangePct}%` : ""}
                </span>
              </div>
            ))}
          </div>
        </Card>
      ) : null}

      <Card>
        <SectionTitle title="Heart rate zones" />
        {s.hrCaptured && profile.maxHr >= 80 ? (
          <>
            <div className="flex h-3 overflow-hidden rounded-full">
              {s.zoneHr.map((sec, i) => (
                <div key={i} style={{ flex: sec || 0.0001, background: HR_ZONE_COLORS[i] }} />
              ))}
            </div>
            <div className="mt-3 space-y-2">
              {hr.map((z, i) => (
                <div key={z.id} className="flex items-center gap-3 text-sm">
                  <span className="size-2 rounded-full" style={{ background: HR_ZONE_COLORS[i] }} />
                  <span className="w-24 text-muted">Z{z.id} {z.name}</span>
                  <span className="tabular text-subtle">{z.lo}–{z.hi}</span>
                  <span className="ml-auto tabular">{Math.round((s.zoneHr[i] / hrTotal) * 100)}%</span>
                </div>
              ))}
            </div>
          </>
        ) : (
          <p className="text-sm text-muted">
            {s.hrCaptured
              ? "Set max HR in Profile to classify this ride’s heart-rate zones."
              : "No heart-rate samples on this ride. Connect the bike and hold the pulse grips — Heart Rate Measurement (0x2A37) is on the RPM600, separate from Indoor Bike Data."}
          </p>
        )}
      </Card>

      <Card>
        <SectionTitle title="Power zones" />
        {profile.ftp > 0 ? (
          <>
            <div className="flex h-3 overflow-hidden rounded-full">
              {s.zonePower.map((sec, i) => (
                <div key={i} style={{ flex: sec || 0.0001, background: POWER_ZONE_COLORS[i] }} />
              ))}
            </div>
            <div className="mt-3 space-y-2">
              {pz.map((z, i) => (
                <div key={z.id} className="flex items-center gap-3 text-sm">
                  <span className="size-2 rounded-full" style={{ background: POWER_ZONE_COLORS[i] }} />
                  <span className="w-36 text-muted">Z{z.id} {z.name}</span>
                  <span className="ml-auto tabular">{Math.round((s.zonePower[i] / pwTotal) * 100)}%</span>
                </div>
              ))}
            </div>
          </>
        ) : (
          <p className="text-sm text-muted">Set FTP in Profile to classify this ride’s power zones.</p>
        )}
      </Card>

      <Card>
        <SectionTitle title="Coach" />
        {insights[0] ? (
          <p className="whitespace-pre-wrap text-sm leading-relaxed text-muted">{insights[0].body}</p>
        ) : (
          <p className="text-sm text-muted">Ask for a post-ride read. Uses your summarized telemetry, not the raw database.</p>
        )}
        {err ? <p className="mt-2 text-sm text-danger">{err}</p> : null}
        <Button className="mt-3" variant="secondary" disabled={busy} onClick={() => void analyze()}>
          {busy ? "Reading the file…" : insights[0] ? "Refresh insight" : "Analyze this ride"}
        </Button>
      </Card>
    </div>
  );
}
