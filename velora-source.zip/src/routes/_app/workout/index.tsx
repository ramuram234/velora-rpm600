import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Clock, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge, Card } from "@/components/ui/primitives";
import { formatTime } from "@/lib/fitness/format";
import { LIBRARY } from "@/lib/fitness/workouts";
import { useFitnessStore } from "@/lib/fitness/store";
import type { WorkoutPlan } from "@/lib/fitness/types";

export const Route = createFileRoute("/_app/workout/")({
  component: WorkoutLibrary,
});

function WorkoutLibrary() {
  const custom = useFitnessStore((s) => s.customPlans);
  const ftp = useFitnessStore((s) => s.profile.ftp);
  const ftpEstimated = useFitnessStore((s) => s.profile.ftpEstimated);
  const start = useFitnessStore((s) => s.startWorkout);
  const session = useFitnessStore((s) => s.session);
  const bleError = useFitnessStore((s) => s.bleError);
  const connection = useFitnessStore((s) => s.connection);
  const navigate = useNavigate();
  const plans = [...custom, ...LIBRARY];

  function ride(plan: WorkoutPlan) {
    if (!start(plan)) {
      void navigate({ to: "/devices" });
      return;
    }
    void navigate({ to: "/workout/live" });
  }

  return (
    <div className="stagger-in space-y-6">
      <header>
        <p className="text-sm text-muted">
          {ftp > 0
            ? `Sessions scaled to ${ftp} W FTP${ftpEstimated ? " (estimate)" : ""}`
            : "No FTP set — watt windows stay empty until you enter one or finish the 20-min test"}
        </p>
        <h1 className="font-display text-3xl font-medium tracking-display">Workout</h1>
      </header>

      {connection !== "connected" ? (
        <Card className="space-y-2">
          <p className="text-sm text-muted">
            Pair the RPM600 before a ride. The app will not start a session without the bike, and
            will not fill watts while waiting.
          </p>
          <Button variant="secondary" onClick={() => void navigate({ to: "/devices" })}>
            Open devices
          </Button>
        </Card>
      ) : null}

      {bleError ? <p className="text-sm text-danger">{bleError}</p> : null}

      {session ? (
        <Card className="flex items-center justify-between">
          <div>
            <div className="text-xs uppercase tracking-wide text-accent">In progress</div>
            <div className="font-medium">{session.plan.name}</div>
          </div>
          <Button size="sm" onClick={() => void navigate({ to: "/workout/live" })}>
            Resume
          </Button>
        </Card>
      ) : null}

      <div className="grid gap-3 sm:grid-cols-2">
        {plans.map((plan) => (
          <Card key={plan.id} className="flex flex-col">
            <div className="flex items-start justify-between gap-2">
              <div>
                <div className="font-medium">{plan.name}</div>
                <div className="mt-1 text-sm text-muted">{plan.description}</div>
              </div>
              <Badge tone={plan.source === "ai" ? "accent" : "muted"}>{plan.kind}</Badge>
            </div>
            <div className="mt-4 flex items-center gap-4 text-xs text-subtle">
              <span className="inline-flex items-center gap-1">
                <Clock className="size-3.5" />
                {plan.kind === "free" ? "Open" : formatTime(plan.durationSec)}
              </span>
              <span className="inline-flex items-center gap-1">
                <Zap className="size-3.5" />
                {plan.intervals.length} blocks
              </span>
            </div>
            <IntervalStrip plan={plan} />
            <Button className="mt-4" variant="secondary" onClick={() => ride(plan)}>
              Ride
            </Button>
          </Card>
        ))}
      </div>
    </div>
  );
}

function IntervalStrip({ plan }: { plan: WorkoutPlan }) {
  const max = Math.max(
    ...plan.intervals.map((i) => i.targetFtpPct?.max ?? 0),
    0.01,
  );
  return (
    <div className="mt-3 flex h-8 overflow-hidden rounded-md bg-surface-2">
      {plan.intervals.map((iv, i) => {
        const h = iv.targetFtpPct ? (iv.targetFtpPct.max / max) * 100 : 18;
        return (
          <div
            key={i}
            className="relative flex items-end"
            style={{ flex: iv.durationSec }}
            title={iv.label}
          >
            <div className="w-full rounded-sm bg-accent/70" style={{ height: `${Math.max(18, h)}%` }} />
          </div>
        );
      })}
    </div>
  );
}
