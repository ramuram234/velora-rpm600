import type { ReactNode } from "react";
import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Button, buttonVariants } from "@/components/ui/button";
import { Card } from "@/components/ui/primitives";
import { nanoAvailability } from "@/lib/ai/nano";
import { formatClock, formatDate } from "@/lib/fitness/format";
import { healthIsNative, healthStatus } from "@/lib/fitness/health";
import { useFitnessStore } from "@/lib/fitness/store";

export const Route = createFileRoute("/_app/settings")({
  component: SettingsPage,
});

function SettingsPage() {
  const theme = useFitnessStore((s) => s.theme);
  const voice = useFitnessStore((s) => s.voiceEnabled);
  const health = useFitnessStore((s) => s.healthSyncEnabled);
  const last = useFitnessStore((s) => s.lastHealthSync);
  const healthDetail = useFitnessStore((s) => s.healthDetail);
  const historyNotice = useFitnessStore((s) => s.historyNotice);
  const workouts = useFitnessStore((s) => s.workouts);
  const setTheme = useFitnessStore((s) => s.setTheme);
  const setVoice = useFitnessStore((s) => s.setVoice);
  const sync = useFitnessStore((s) => s.syncHealth);
  const setHealth = useFitnessStore((s) => s.setHealthSync);
  const clear = useFitnessStore((s) => s.clearHistory);
  const [ai, setAi] = useState("Checking on-device model…");
  const [hc, setHc] = useState("Checking Health Connect…");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    void nanoAvailability().then((a) => {
      if (a.available) setAi(`Gemini Nano ready · ${a.engine} (${a.status})`);
      else setAi("Gemini Nano not on this phone. Coach falls back to the on-device rule engine — still local, no account.");
    });
    void healthStatus().then((s) => {
      setHc(
        s.available
          ? "Health Connect is on this phone. Sync writes rides, HR, steps, and weight on-device. No Gmail. No Google login."
          : s.reason,
      );
    });
  }, []);

  return (
    <div className="stagger-in space-y-6">
      <header>
        <p className="text-sm text-muted">Local preferences</p>
        <h1 className="font-display text-3xl font-medium tracking-display">Settings</h1>
      </header>

      <Card className="divide-y divide-line">
        <Row label="Theme" hint="AMOLED dark or paper light">
          <button
            className="h-9 rounded-full bg-surface-2 px-3 text-sm"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          >
            {theme === "dark" ? "Dark" : "Light"}
          </button>
        </Row>
        <Row label="Voice coach" hint="On-device speech for live cues, not an LLM">
          <Toggle on={voice} onChange={setVoice} />
        </Row>
      </Card>

      <Card className="space-y-3">
        <div className="font-medium">Health Connect</div>
        <p className="text-sm text-muted">{hc}</p>
        <p className="text-sm text-muted">
          This is the Android health store on the phone. After a ride, Velora writes stationary
          cycling, distance, calories, and heart rate. Steps come from this phone’s sensor and from
          other apps already in Health Connect. You never sign in with Gmail.
        </p>
        <div className="flex flex-wrap gap-2">
          <Button
            disabled={busy}
            onClick={() => {
              setBusy(true);
              void sync().finally(() => setBusy(false));
            }}
          >
            {health ? "Sync now" : "Connect Health"}
          </Button>
          {health ? (
            <Button variant="secondary" onClick={() => setHealth(false)}>
              Pause
            </Button>
          ) : null}
        </div>
        {last ? (
          <p className="text-xs text-muted">
            Last sync {formatDate(last)} {formatClock(last)}.
          </p>
        ) : null}
        {healthDetail ? <p className="text-xs text-subtle">{healthDetail}</p> : null}
        {!healthIsNative() ? (
          <p className="text-xs text-warn">
            This preview cannot reach Health Connect. Install the APK, then tap Connect Health.
          </p>
        ) : null}
        <Link to="/privacy" className="block text-xs text-muted hover:text-fg">
          Health privacy note
        </Link>
      </Card>

      <Card className="space-y-3">
        <div className="font-medium">Android app</div>
        <p className="text-sm text-muted">
          Debug APK for the RPM600. Allow install from this source, grant Bluetooth, then pair
          FS-583ADC. Play Protect may warn because it is not from the Play Store.
        </p>
        <a href="/velora-rpm600.apk" download className={buttonVariants({ variant: "secondary" })}>
          Download Velora APK
        </a>
      </Card>

      <Card className="space-y-3">
        <div className="font-medium">AI coach</div>
        <p className="text-sm text-muted">{ai}</p>
        <p className="text-sm text-muted">
          Order: Gemini Nano on-device (AICore) → Chrome Prompt API → local coaching engine. Ride
          data never leaves the phone unless you are in the web studio and cloud is available.
        </p>
        <Link to="/coach">
          <Button variant="secondary">Open coach</Button>
        </Link>
      </Card>

      <Card className="space-y-3">
        <div className="font-medium">Ride history</div>
        <p className="text-sm text-muted">
          {workouts.length
            ? `${workouts.length} rides stored on this phone. Clear deletes them. Nothing is refilled.`
            : "No rides stored. Finished sessions from the bike appear here — nothing is preloaded."}
        </p>
        <Button variant="danger" onClick={clear} disabled={!workouts.length}>
          Clear all rides
        </Button>
        {historyNotice ? <p className="text-xs text-accent">{historyNotice}</p> : null}
      </Card>

      <Link to="/devices" className="block text-sm text-muted hover:text-fg">
        Device & BLE services
      </Link>
    </div>
  );
}

function Row({
  label,
  hint,
  children,
}: {
  label: string;
  hint: string;
  children: ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-4 py-3 first:pt-0 last:pb-0">
      <div>
        <div className="text-sm">{label}</div>
        <div className="text-xs text-muted">{hint}</div>
      </div>
      {children}
    </div>
  );
}

function Toggle({ on, onChange }: { on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      role="switch"
      aria-checked={on}
      onClick={() => onChange(!on)}
      className={`relative h-7 w-11 rounded-full transition-[background-color] duration-150 ${
        on ? "bg-accent" : "bg-surface-3"
      }`}
    >
      <span
        className={`absolute top-0.5 size-6 rounded-full bg-fg transition-transform duration-150 ${
          on ? "translate-x-4" : "translate-x-0.5"
        }`}
      />
    </button>
  );
}
