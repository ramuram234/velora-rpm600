import { createFileRoute, Link } from "@tanstack/react-router";
import { Card } from "@/components/ui/primitives";

export const Route = createFileRoute("/privacy")({
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <div className="mx-auto min-h-dvh max-w-lg bg-bg px-5 py-10 text-fg">
      <p className="text-sm text-muted">Velora</p>
      <h1 className="font-display text-3xl font-medium tracking-display">Health privacy</h1>
      <Card className="mt-6 space-y-3 text-sm leading-relaxed text-muted">
        <p>
          Velora is local-first. Rides, heart rate, steps, and body metrics live on this phone. There
          is no Velora account and no Gmail sign-in.
        </p>
        <p>
          <strong className="text-fg">Health Connect</strong> is Android’s on-device health store. If
          you allow it, Velora writes indoor bike sessions, heart-rate samples, distance, calories,
          and weight into that store, and may read steps. Other apps you already approved (a watch,
          a health app) can then see that data. Revoke access any time in Health Connect settings.
        </p>
        <p>
          Granting Health Connect permission is not a Google login. It does not open Gmail. It does
          not upload your rides to Velora servers. Indoor rides are written as stationary cycling so
          they appear in the Health Connect journal.
        </p>
        <p>
          Heart rate is captured from the bike’s BLE Heart Rate service (0x180D / 0x2A37) when you
          connect FS-583ADC, or from a chest strap you pair. The RPM600 Indoor Bike Data packet does
          not include HR. Velora does not estimate heart rate from watts.
        </p>
        <p>
          On-device coaching uses Gemini Nano through Android AICore when the phone has it. Otherwise
          a local rule engine runs. Ride files stay on the device.
        </p>
      </Card>
      <Link to="/settings" className="mt-6 inline-block text-sm text-accent">
        Back to settings
      </Link>
    </div>
  );
}
