import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/layout/app-shell";
import { Welcome } from "@/components/onboarding/welcome";
import { useFitnessStore } from "@/lib/fitness/store";

export const Route = createFileRoute("/_app")({
  component: AppGate,
});

function AppGate() {
  const onboarding = useFitnessStore((s) => s.onboardingComplete);
  if (!onboarding) return <Welcome />;
  return <AppShell />;
}
