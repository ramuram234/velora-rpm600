package com.velora.rpm600

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.util.TypedValue
import android.widget.ScrollView
import android.widget.TextView

class PrivacyActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = TextView(this).apply {
            setTextColor(Color.parseColor("#E8EEF5"))
            setBackgroundColor(Color.parseColor("#05080D"))
            setPadding(48, 64, 48, 64)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setText(
                """
Velora health privacy

Velora is local-first. Rides, heart rate, steps, and body metrics live on this phone. There is no Velora account and no Gmail sign-in.

Health Connect is Android’s on-device health store. If you allow it, Velora writes indoor bike sessions, heart-rate samples, distance, calories, and weight into that store, and may read steps. Other apps you already approved can then see that data. Revoke access any time in Health Connect settings.

Granting Health Connect permission is not a Google login. It does not open Gmail. It does not upload your rides.

Heart rate is captured only from a BLE Heart Rate service you pair. The RPM600 Indoor Bike Data packet does not include HR.
                """.trimIndent()
            )
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#05080D"))
            addView(text)
        }
        setContentView(scroll)
    }
}
