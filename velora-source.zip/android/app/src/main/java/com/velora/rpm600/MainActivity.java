package com.velora.rpm600;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(VeloraAiPlugin.class);
        registerPlugin(VeloraHealthPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
