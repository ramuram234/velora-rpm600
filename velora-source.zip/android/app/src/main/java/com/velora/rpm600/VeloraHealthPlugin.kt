package com.velora.rpm600

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import androidx.activity.result.ActivityResult
import androidx.core.content.ContextCompat
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.records.TotalCaloriesBurnedRecord
import androidx.health.connect.client.records.WeightRecord
import androidx.health.connect.client.records.metadata.Device
import androidx.health.connect.client.records.metadata.Metadata
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.time.TimeRangeFilter
import androidx.health.connect.client.units.Energy
import androidx.health.connect.client.units.Length
import androidx.health.connect.client.units.Mass
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.ActivityCallback
import com.getcapacitor.annotation.CapacitorPlugin
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

@CapacitorPlugin(name = "VeloraHealth")
class VeloraHealthPlugin : Plugin() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val permissions = setOf(
        HealthPermission.getWritePermission(ExerciseSessionRecord::class),
        HealthPermission.getWritePermission(HeartRateRecord::class),
        HealthPermission.getWritePermission(DistanceRecord::class),
        HealthPermission.getWritePermission(TotalCaloriesBurnedRecord::class),
        HealthPermission.getWritePermission(ActiveCaloriesBurnedRecord::class),
        HealthPermission.getWritePermission(WeightRecord::class),
        HealthPermission.getWritePermission(StepsRecord::class),
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(ExerciseSessionRecord::class),
    )

    private fun bikeMeta(clientId: String): Metadata {
        return Metadata(
            "",
            androidx.health.connect.client.records.metadata.DataOrigin(context.packageName),
            Instant.now(),
            clientId,
            1L,
            Device("JIANJIA", "FS-583ADC", Device.TYPE_UNKNOWN),
            Metadata.RECORDING_METHOD_ACTIVELY_RECORDED,
        )
    }

    private fun phoneMeta(clientId: String): Metadata {
        return Metadata(
            "",
            androidx.health.connect.client.records.metadata.DataOrigin(context.packageName),
            Instant.now(),
            clientId,
            1L,
            Device("Velora", "phone", Device.TYPE_PHONE),
            Metadata.RECORDING_METHOD_AUTOMATICALLY_RECORDED,
        )
    }

    @PluginMethod
    fun getStatus(call: PluginCall) {
        val ret = JSObject()
        val status = HealthConnectClient.getSdkStatus(context)
        when (status) {
            HealthConnectClient.SDK_AVAILABLE -> {
                ret.put("available", true)
                ret.put("sdk", "available")
                ret.put("reason", "Health Connect is on this phone. No Google account is required.")
            }
            HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED -> {
                ret.put("available", false)
                ret.put("sdk", "update")
                ret.put("reason", "Health Connect needs an update from Play Store. Still no Gmail sign-in.")
            }
            else -> {
                ret.put("available", false)
                ret.put("sdk", "missing")
                ret.put("reason", "Health Connect is not installed. It is an Android health store, not Gmail.")
            }
        }
        call.resolve(ret)
    }

    @PluginMethod
    fun requestAccess(call: PluginCall) {
        val status = HealthConnectClient.getSdkStatus(context)
        if (status != HealthConnectClient.SDK_AVAILABLE) {
            val ret = JSObject()
            ret.put("granted", false)
            ret.put("detail", "Health Connect is not available on this phone.")
            call.resolve(ret)
            return
        }
        requestActivityRecognition()
        val act = activity
        if (act == null) {
            call.reject("no activity")
            return
        }
        scope.launch {
            try {
                val client = HealthConnectClient.getOrCreate(context)
                val granted = client.permissionController.getGrantedPermissions()
                if (granted.containsAll(permissions)) {
                    val ret = JSObject()
                    ret.put("granted", true)
                    ret.put("detail", "Health Connect already granted.")
                    call.resolve(ret)
                    return@launch
                }
                withContext(Dispatchers.Main) {
                    val contract = PermissionController.createRequestPermissionResultContract()
                    val intent: Intent = contract.createIntent(act, permissions)
                    startActivityForResult(call, intent, "onPerms")
                }
            } catch (e: Exception) {
                val ret = JSObject()
                ret.put("granted", false)
                ret.put("detail", e.message ?: "Could not open Health Connect")
                call.resolve(ret)
            }
        }
    }

    @ActivityCallback
    private fun onPerms(call: PluginCall, result: ActivityResult) {
        scope.launch {
            val ret = JSObject()
            try {
                val client = HealthConnectClient.getOrCreate(context)
                val granted = client.permissionController.getGrantedPermissions()
                val writeEx = HealthPermission.getWritePermission(ExerciseSessionRecord::class)
                val ok = granted.contains(writeEx) || granted.containsAll(permissions)
                ret.put("granted", ok)
                ret.put(
                    "detail",
                    if (ok) "Health Connect can receive indoor rides."
                    else "Exercise write was not granted. Open Health Connect and allow Velora to write Exercise.",
                )
            } catch (e: Exception) {
                ret.put("granted", false)
                ret.put("detail", e.message ?: "Permission check failed")
            }
            call.resolve(ret)
        }
    }

    @PluginMethod
    fun sync(call: PluginCall) {
        val status = HealthConnectClient.getSdkStatus(context)
        if (status != HealthConnectClient.SDK_AVAILABLE) {
            val ret = JSObject()
            ret.put("ok", false)
            ret.put("written", 0)
            ret.put("stepsRead", 0)
            ret.put("detail", "Health Connect is not available.")
            call.resolve(ret)
            return
        }
        requestActivityRecognition()
        scope.launch {
            val ret = JSObject()
            try {
                val client = HealthConnectClient.getOrCreate(context)
                val granted = client.permissionController.getGrantedPermissions()
                val zone = ZoneId.systemDefault()
                var written = 0
                val errors = mutableListOf<String>()

                val canWriteEx = granted.contains(HealthPermission.getWritePermission(ExerciseSessionRecord::class))
                val canWriteHr = granted.contains(HealthPermission.getWritePermission(HeartRateRecord::class))
                val canWriteDist = granted.contains(HealthPermission.getWritePermission(DistanceRecord::class))
                val canWriteKcal = granted.contains(HealthPermission.getWritePermission(TotalCaloriesBurnedRecord::class))
                val canWriteActive = granted.contains(HealthPermission.getWritePermission(ActiveCaloriesBurnedRecord::class))
                val canWriteWeight = granted.contains(HealthPermission.getWritePermission(WeightRecord::class))
                val canWriteSteps = granted.contains(HealthPermission.getWritePermission(StepsRecord::class))
                val canReadSteps = granted.contains(HealthPermission.getReadPermission(StepsRecord::class))

                if (!canWriteEx) {
                    ret.put("ok", false)
                    ret.put("written", 0)
                    ret.put("stepsRead", 0)
                    ret.put("detail", "Grant Velora permission to write Exercise in Health Connect.")
                    call.resolve(ret)
                    return@launch
                }

                val workouts = call.getArray("workouts") ?: JSONArray()
                for (i in 0 until workouts.length()) {
                    val w = workouts.getJSONObject(i)
                    val id = w.optString("id", "ride-$i")
                    val start = Instant.ofEpochMilli(w.optLong("startMs"))
                    val end = Instant.ofEpochMilli(w.optLong("endMs"))
                    if (!end.isAfter(start)) continue
                    val startOff = zone.rules.getOffset(start)
                    val endOff = zone.rules.getOffset(end)
                    val batch = mutableListOf<androidx.health.connect.client.records.Record>()
                    batch.add(
                        ExerciseSessionRecord(
                            startTime = start,
                            startZoneOffset = startOff,
                            endTime = end,
                            endZoneOffset = endOff,
                            exerciseType = ExerciseSessionRecord.EXERCISE_TYPE_BIKING_STATIONARY,
                            title = w.optString("name", "Indoor cycling"),
                            notes = "RPM600 indoor bike · Velora",
                            metadata = bikeMeta("velora-ex-$id"),
                        ),
                    )
                    val dist = w.optDouble("distanceM", 0.0)
                    if (canWriteDist && dist > 1) {
                        batch.add(
                            DistanceRecord(
                                startTime = start,
                                startZoneOffset = startOff,
                                endTime = end,
                                endZoneOffset = endOff,
                                distance = Length.meters(dist),
                                metadata = bikeMeta("velora-dist-$id"),
                            ),
                        )
                    }
                    val kcal = w.optDouble("calories", 0.0)
                    if (kcal > 1) {
                        if (canWriteKcal) {
                            batch.add(
                                TotalCaloriesBurnedRecord(
                                    startTime = start,
                                    startZoneOffset = startOff,
                                    endTime = end,
                                    endZoneOffset = endOff,
                                    energy = Energy.kilocalories(kcal),
                                    metadata = bikeMeta("velora-kcal-$id"),
                                ),
                            )
                        }
                        if (canWriteActive) {
                            batch.add(
                                ActiveCaloriesBurnedRecord(
                                    startTime = start,
                                    startZoneOffset = startOff,
                                    endTime = end,
                                    endZoneOffset = endOff,
                                    energy = Energy.kilocalories(kcal),
                                    metadata = bikeMeta("velora-active-$id"),
                                ),
                            )
                        }
                    }
                    val hrArr = w.optJSONArray("hr")
                    if (canWriteHr && hrArr != null && hrArr.length() > 0) {
                        val samples = ArrayList<HeartRateRecord.Sample>()
                        for (h in 0 until hrArr.length()) {
                            val row = hrArr.getJSONObject(h)
                            val bpm = row.optLong("bpm")
                            if (bpm < 30) continue
                            val t = Instant.ofEpochMilli(row.optLong("tMs"))
                            if (t.isBefore(start) || !t.isBefore(end)) continue
                            samples.add(HeartRateRecord.Sample(time = t, beatsPerMinute = bpm))
                        }
                        if (samples.size >= 2) {
                            batch.add(
                                HeartRateRecord(
                                    startTime = start,
                                    startZoneOffset = startOff,
                                    endTime = end,
                                    endZoneOffset = endOff,
                                    samples = samples,
                                    metadata = bikeMeta("velora-hr-$id"),
                                ),
                            )
                        }
                    }
                    try {
                        client.insertRecords(batch)
                        written += batch.size
                    } catch (e: Exception) {
                        errors.add(e.message ?: "ride $id")
                    }
                }

                val weight = if (call.hasOption("weightKg")) call.getDouble("weightKg") else null
                if (canWriteWeight && weight != null && weight > 20) {
                    try {
                        val now = Instant.now()
                        client.insertRecords(
                            listOf(
                                WeightRecord(
                                    time = now,
                                    zoneOffset = zone.rules.getOffset(now),
                                    weight = Mass.kilograms(weight),
                                    metadata = phoneMeta("velora-weight"),
                                ),
                            ),
                        )
                        written += 1
                    } catch (e: Exception) {
                        errors.add(e.message ?: "weight")
                    }
                }

                val phoneToday = readPhoneStepsToday()
                if (canWriteSteps && phoneToday > 0) {
                    try {
                        val startDay = LocalDate.now(zone).atStartOfDay(zone).toInstant()
                        val now = Instant.now()
                        if (now.isAfter(startDay)) {
                            client.insertRecords(
                                listOf(
                                    StepsRecord(
                                        startTime = startDay,
                                        startZoneOffset = zone.rules.getOffset(startDay),
                                        endTime = now,
                                        endZoneOffset = zone.rules.getOffset(now),
                                        count = phoneToday,
                                        metadata = phoneMeta("velora-steps-${LocalDate.now(zone)}"),
                                    ),
                                ),
                            )
                            written += 1
                        }
                    } catch (e: Exception) {
                        errors.add(e.message ?: "steps write")
                    }
                }

                val stepsDays = JSArray()
                var todaySteps = phoneToday
                if (canReadSteps) {
                    for (d in 0..6) {
                        val day = LocalDate.now(zone).minusDays(d.toLong())
                        val start = day.atStartOfDay(zone).toInstant()
                        val end = day.plusDays(1).atStartOfDay(zone).toInstant()
                        try {
                            val agg = client.aggregate(
                                AggregateRequest(
                                    metrics = setOf(StepsRecord.COUNT_TOTAL),
                                    timeRangeFilter = TimeRangeFilter.between(start, end),
                                ),
                            )
                            val count = agg[StepsRecord.COUNT_TOTAL] ?: 0L
                            if (d == 0 && count > todaySteps) todaySteps = count
                            if (count > 0) {
                                val row = JSObject()
                                row.put("date", day.toString())
                                row.put("count", count)
                                stepsDays.put(row)
                            }
                        } catch (_: Exception) {
                        }
                    }
                }
                if (phoneToday > 0 && stepsDays.length() == 0) {
                    val row = JSObject()
                    row.put("date", LocalDate.now(zone).toString())
                    row.put("count", phoneToday)
                    stepsDays.put(row)
                }

                val detail = buildString {
                    append("Wrote $written Health Connect records")
                    if (written > 0) append(" (stationary cycling + calories")
                    if (phoneToday > 0) append(", phone steps $phoneToday")
                    if (written > 0) append(")")
                    append(". Nothing uploaded.")
                    if (errors.isNotEmpty()) append(" Partial errors: ${errors.take(2).joinToString("; ")}")
                }
                ret.put("ok", written > 0 || todaySteps > 0)
                ret.put("written", written)
                ret.put("stepsRead", todaySteps)
                ret.put("stepsDays", stepsDays)
                ret.put("detail", detail)
            } catch (e: Exception) {
                ret.put("ok", false)
                ret.put("written", 0)
                ret.put("stepsRead", 0)
                ret.put("detail", e.message ?: "Health sync failed")
            }
            call.resolve(ret)
        }
    }

    private fun requestActivityRecognition() {
        if (Build.VERSION.SDK_INT < 29) return
        val act = activity ?: return
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACTIVITY_RECOGNITION)
            == PackageManager.PERMISSION_GRANTED
        ) return
        act.runOnUiThread {
            act.requestPermissions(arrayOf(Manifest.permission.ACTIVITY_RECOGNITION), 7102)
        }
    }

    /** TYPE_STEP_COUNTER is cumulative since boot. Baseline is stored per calendar day. */
    private fun readPhoneStepsToday(): Long {
        if (Build.VERSION.SDK_INT >= 29 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACTIVITY_RECOGNITION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return 0
        }
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) ?: return 0
        var reading = -1L
        val latch = CountDownLatch(1)
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                if (event.sensor.type != Sensor.TYPE_STEP_COUNTER) return
                reading = event.values[0].toLong()
                sm.unregisterListener(this)
                latch.countDown()
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_NORMAL)
        latch.await(1200, TimeUnit.MILLISECONDS)
        sm.unregisterListener(listener)
        if (reading < 0) return 0

        val prefs = context.getSharedPreferences("velora_steps", Context.MODE_PRIVATE)
        val today = LocalDate.now(ZoneId.systemDefault()).toString()
        val storedDay = prefs.getString("day", "")
        val storedBase = prefs.getLong("base", -1L)
        val base = if (storedDay == today && storedBase >= 0 && storedBase <= reading) {
            storedBase
        } else {
            prefs.edit().putString("day", today).putLong("base", reading).apply()
            reading
        }
        return (reading - base).coerceAtLeast(0)
    }
}
