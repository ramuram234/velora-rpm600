package com.velora.rpm600

import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import java.util.concurrent.Executors

@CapacitorPlugin(name = "VeloraAi")
class VeloraAiPlugin : Plugin() {
    private val io = Executors.newSingleThreadExecutor()

    @PluginMethod
    fun getAvailability(call: PluginCall) {
        io.execute {
            val ret = JSObject()
            try {
                val client = nanoClient()
                ret.put("available", client != null)
                ret.put("engine", if (client != null) "gemini-nano" else "none")
                ret.put("status", if (client != null) "present" else "not-on-this-device")
            } catch (e: Throwable) {
                ret.put("available", false)
                ret.put("engine", "none")
                ret.put("status", e.message ?: "unavailable")
            }
            call.resolve(ret)
        }
    }

    @PluginMethod
    fun prompt(call: PluginCall) {
        val prompt = call.getString("prompt")
        if (prompt.isNullOrBlank()) {
            call.reject("missing prompt")
            return
        }
        io.execute {
            val ret = JSObject()
            try {
                val client = nanoClient() ?: throw IllegalStateException(
                    "Gemini Nano is not on this phone. Pixel 9/10 and some 2025–26 flagships with AICore. Coach will use the local engine."
                )
                val text = generate(client, prompt)
                if (text.isNullOrBlank()) {
                    ret.put("ok", false)
                    ret.put("error", "Empty Nano response")
                } else {
                    ret.put("ok", true)
                    ret.put("text", text)
                }
            } catch (e: Throwable) {
                ret.put("ok", false)
                ret.put("error", e.message ?: "Gemini Nano failed")
            }
            call.resolve(ret)
        }
    }

    private fun nanoClient(): Any? {
        return try {
            val cls = Class.forName("com.google.mlkit.genai.prompt.Generation")
            val method = cls.methods.firstOrNull { it.name == "getClient" && it.parameterCount == 0 }
            method?.invoke(null)
        } catch (_: Throwable) {
            null
        }
    }

    private fun generate(client: Any, prompt: String): String? {
        val method = client.javaClass.methods.firstOrNull {
            it.name == "generateContent" && it.parameterCount == 1
        } ?: return null
        var result = method.invoke(client, prompt)
        result = unwrap(result)
        return extractText(result)
    }

    private fun unwrap(value: Any?): Any? {
        if (value == null) return null
        return try {
            val await = value.javaClass.methods.firstOrNull { it.name == "get" && it.parameterCount == 0 }
            if (await != null) await.invoke(value) else value
        } catch (_: Throwable) {
            value
        }
    }

    private fun extractText(result: Any?): String? {
        if (result == null) return null
        if (result is CharSequence) return result.toString()
        for (name in listOf("getText", "getResponse", "text")) {
            try {
                val m = result.javaClass.methods.firstOrNull { it.name == name && it.parameterCount == 0 }
                val v = m?.invoke(result)
                if (v is CharSequence && v.isNotBlank()) return v.toString()
            } catch (_: Throwable) {
            }
        }
        return result.toString().takeIf { it.isNotBlank() && !it.startsWith(result.javaClass.name) }
    }
}
