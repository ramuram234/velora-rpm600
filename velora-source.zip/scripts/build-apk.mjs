#!/usr/bin/env node
import { execSync } from "node:child_process";
import { copyFileSync, existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const env = {
  ...process.env,
  JAVA_HOME: process.env.JAVA_HOME || "/usr/lib/jvm/java-17-openjdk-amd64",
  ANDROID_HOME: process.env.ANDROID_HOME || "/tmp/android-sdk",
  ANDROID_SDK_ROOT: process.env.ANDROID_SDK_ROOT || process.env.ANDROID_HOME || "/tmp/android-sdk",
};

function run(cmd, cwd = root) {
  console.log(`[apk] ${cmd}`);
  execSync(cmd, { cwd, env, stdio: "inherit" });
}

if (!existsSync(resolve(env.ANDROID_HOME, "platforms/android-35"))) {
  console.error("[apk] Android SDK not found. Expected platforms/android-35 under ANDROID_HOME.");
  process.exit(1);
}

run("npx vite build --config vite.native.config.ts");

const localProps = resolve(root, "android/local.properties");
const sdkDir = env.ANDROID_HOME.replace(/\\/g, "/");
if (!existsSync(resolve(root, "android"))) {
  run("npx cap add android");
}
writeFileSync(localProps, `sdk.dir=${sdkDir}\n`);
run("npx cap sync android");

const gradle = resolve(root, "android/gradlew");
run(`${gradle} :app:assembleDebug --no-daemon`, resolve(root, "android"));

const built = resolve(root, "android/app/build/outputs/apk/debug/app-debug.apk");
if (!existsSync(built)) {
  console.error("[apk] debug APK missing");
  process.exit(1);
}

mkdirSync(resolve(root, "public"), { recursive: true });
mkdirSync(resolve(root, "artifacts"), { recursive: true });

function copyApk(dest) {
  try {
    copyFileSync(built, dest);
  } catch {
    writeFileSync(dest, readFileSync(built));
  }
}

copyApk(resolve(root, "public/velora-rpm600.apk"));
copyApk(resolve(root, "artifacts/velora-rpm600.apk"));
console.log("[apk] wrote public/velora-rpm600.apk and artifacts/velora-rpm600.apk");
