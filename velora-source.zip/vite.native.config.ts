import path from "node:path";
import { defineConfig } from "vite";
import viteReact from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  root: path.resolve("native-web"),
  base: "./",
  envDir: path.resolve("."),
  define: {
    "import.meta.env.VITE_NATIVE": JSON.stringify("1"),
  },
  plugins: [tailwindcss(), viteReact()],
  resolve: {
    alias: { "@": path.resolve("src") },
  },
  build: {
    outDir: path.resolve("native-www"),
    emptyOutDir: true,
    sourcemap: false,
  },
});
