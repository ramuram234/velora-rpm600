import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.velora.rpm600",
  appName: "Velora",
  webDir: "native-www",
  android: {
    path: "android",
  },
  plugins: {
    BluetoothLe: {
      displayStrings: {
        scanning: "Scanning for RPM600…",
        cancel: "Cancel",
        availableDevices: "Nearby bikes",
        noDeviceFound: "No bike found",
      },
    },
  },
};

export default config;
